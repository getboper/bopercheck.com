import { sendApologyEmail } from './emailOutreach';

interface ErrorEvent {
  userId?: string;
  guestId?: string;
  email?: string;
  errorType: 'cache_error' | 'api_failure' | 'timeout' | 'system_error';
  userAgent?: string;
  searchQuery?: string;
  timestamp: Date;
}

// Track recent errors to avoid spam
const recentErrorEmails = new Map<string, number>();
const EMAIL_COOLDOWN = 24 * 60 * 60 * 1000; // 24 hours

export async function handleAutomaticErrorOutreach(error: ErrorEvent) {
  try {
    // Determine recipient email
    let recipientEmail = error.email;
    let firstName = 'Valued Customer';
    
    // For now, we'll work with the provided email in the error event
    // Database schema integration will be added once schema is updated
    
    if (!recipientEmail) {
      console.log('No email found for automatic outreach');
      return false;
    }
    
    // Check cooldown to prevent spam
    const lastEmailTime = recentErrorEmails.get(recipientEmail);
    const now = Date.now();
    
    if (lastEmailTime && (now - lastEmailTime) < EMAIL_COOLDOWN) {
      console.log(`Email cooldown active for ${recipientEmail}`);
      return false;
    }
    
    // Only send for significant errors that affect user experience
    const significantErrors = ['cache_error', 'api_failure', 'timeout'];
    if (!significantErrors.includes(error.errorType)) {
      return false;
    }
    
    // Send automatic apology email
    const emailSent = await sendApologyEmail({
      email: recipientEmail,
      firstName,
      searchQuery: error.searchQuery || 'your recent search',
      lastVisit: new Date().toISOString().split('T')[0]
    });
    
    if (emailSent) {
      recentErrorEmails.set(recipientEmail, now);
      console.log(`Automatic apology email sent to ${recipientEmail} for ${error.errorType}`);
      
      // Log the automatic outreach for admin monitoring
      await logAutomaticOutreach(recipientEmail, error.errorType, error.searchQuery);
      
      return true;
    }
    
    return false;
  } catch (err) {
    console.error('Error in automatic email outreach:', err);
    return false;
  }
}

// Log automatic outreach events for admin tracking
async function logAutomaticOutreach(email: string, errorType: string, searchQuery?: string) {
  try {
    // You could create a separate table for outreach logs
    console.log(`AUTOMATIC_OUTREACH: ${email} - ${errorType} - ${searchQuery || 'N/A'} at ${new Date().toISOString()}`);
  } catch (error) {
    console.error('Failed to log automatic outreach:', error);
  }
}

// Function to be called when cache errors occur
export async function handleCacheError(userId?: string, guestId?: string, searchQuery?: string, userAgent?: string) {
  await handleAutomaticErrorOutreach({
    userId,
    guestId,
    errorType: 'cache_error',
    searchQuery,
    userAgent,
    timestamp: new Date()
  });
}

// Function to be called when API failures occur
export async function handleAPIFailure(userId?: string, guestId?: string, searchQuery?: string, email?: string) {
  await handleAutomaticErrorOutreach({
    userId,
    guestId,
    email,
    errorType: 'api_failure',
    searchQuery,
    timestamp: new Date()
  });
}

// Function to be called when timeouts occur
export async function handleTimeout(userId?: string, guestId?: string, searchQuery?: string, email?: string) {
  await handleAutomaticErrorOutreach({
    userId,
    guestId,
    email,
    errorType: 'timeout',
    searchQuery,
    timestamp: new Date()
  });
}

// Bulk outreach for users who experienced errors in the last 24 hours
export async function sendBulkErrorApologies(errorType: 'cache_error' | 'api_failure' | 'timeout' = 'cache_error') {
  try {
    // For demonstration, send test emails to a few sample addresses
    const testUsers = [
      { email: 'test@example.com', firstName: 'Test User', searchQuery: 'mountain bike' },
      { email: 'demo@example.com', firstName: 'Demo User', searchQuery: 'laptop' }
    ];
    
    let sentCount = 0;
    
    for (const user of testUsers) {
      // Check if we haven't already sent an email to this user
      const lastEmailTime = recentErrorEmails.get(user.email);
      if (!lastEmailTime || (Date.now() - lastEmailTime) >= EMAIL_COOLDOWN) {
        
        const success = await sendApologyEmail({
          email: user.email,
          firstName: user.firstName || 'Valued Customer',
          searchQuery: user.searchQuery || 'recent search',
          lastVisit: new Date().toISOString().split('T')[0]
        });
        
        if (success) {
          sentCount++;
          recentErrorEmails.set(user.email, Date.now());
          // Add delay to respect rate limits
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }
    }
    
    console.log(`Bulk error apologies sent to ${sentCount} users for ${errorType}`);
    return { sent: sentCount, total: testUsers.length };
    
  } catch (error) {
    console.error('Error in bulk error apologies:', error);
    return { sent: 0, total: 0, error: String(error) };
  }
}

// Cleanup old email cooldown entries
setInterval(() => {
  const now = Date.now();
  const entries = Array.from(recentErrorEmails.entries());
  for (const [email, timestamp] of entries) {
    if (now - timestamp > EMAIL_COOLDOWN) {
      recentErrorEmails.delete(email);
    }
  }
}, 60 * 60 * 1000); // Clean up every hour