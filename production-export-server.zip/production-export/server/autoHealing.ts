import { notifySystemHealth } from './errorNotifications';

interface HealingAction {
  errorPattern: string;
  description: string;
  action: () => Promise<boolean>;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

class AutoHealingSystem {
  private static instance: AutoHealingSystem;
  private healingActions: HealingAction[] = [];
  private isHealing = false;
  private healingHistory: Array<{
    timestamp: Date;
    error: string;
    action: string;
    success: boolean;
  }> = [];

  constructor() {
    this.initializeHealingActions();
  }

  static getInstance(): AutoHealingSystem {
    if (!AutoHealingSystem.instance) {
      AutoHealingSystem.instance = new AutoHealingSystem();
    }
    return AutoHealingSystem.instance;
  }

  private initializeHealingActions(): void {
    this.healingActions = [
      {
        errorPattern: 'Method is not a valid HTTP token',
        description: 'Trigger system restart for header validation fix',
        action: this.restartSystem.bind(this),
        severity: 'high'
      },
      {
        errorPattern: 'JSON parsing failed',
        description: 'Clear caches and restart to reload JSON handlers',
        action: this.clearCachesAndRestart.bind(this),
        severity: 'medium'
      },
      {
        errorPattern: 'Analysis failed',
        description: 'Reset AI service connections and restart',
        action: this.resetAIAndRestart.bind(this),
        severity: 'high'
      },
      {
        errorPattern: 'Database connection',
        description: 'Reset database pool and restart system',
        action: this.resetDatabaseAndRestart.bind(this),
        severity: 'critical'
      }
    ];
  }

  public async attemptAutoHealing(errorMessage: string, errorContext: any): Promise<boolean> {
    if (this.isHealing) {
      console.log('Auto-healing already in progress');
      return false;
    }

    this.isHealing = true;
    console.log('Auto-healing initiated for:', errorMessage);

    try {
      const matchingAction = this.healingActions.find(action => 
        errorMessage.toLowerCase().includes(action.errorPattern.toLowerCase())
      );

      if (!matchingAction) {
        console.log('No auto-healing action found for this error');
        return false;
      }

      console.log('Applying healing action:', matchingAction.description);
      
      const success = await matchingAction.action();
      
      this.healingHistory.push({
        timestamp: new Date(),
        error: errorMessage,
        action: matchingAction.description,
        success
      });

      if (success) {
        await notifySystemHealth(
          'Auto-Healing System',
          'recovered',
          {
            error: errorMessage,
            action: matchingAction.description,
            timestamp: new Date().toISOString()
          }
        );
      } else {
        await notifySystemHealth(
          'Auto-Healing System',
          'failed',
          {
            error: errorMessage,
            action: matchingAction.description,
            timestamp: new Date().toISOString()
          }
        );
      }

      return success;
    } catch (healingError) {
      console.error('Auto-healing system error:', healingError);
      return false;
    } finally {
      this.isHealing = false;
    }
  }

  private async restartSystem(): Promise<boolean> {
    try {
      console.log('Triggering system restart to fix header validation...');
      
      // Notify about restart
      await notifySystemHealth(
        'Auto-Healing',
        'restarting',
        { reason: 'HTTP token validation fix' }
      );
      
      // Schedule restart
      setTimeout(() => {
        process.exit(0);
      }, 1000);
      
      return true;
    } catch (error) {
      console.error('Failed to restart system:', error);
      return false;
    }
  }

  private async clearCachesAndRestart(): Promise<boolean> {
    try {
      console.log('Clearing caches and restarting...');
      
      // Force garbage collection if available
      if (global.gc) {
        global.gc();
      }
      
      // Schedule restart
      setTimeout(() => {
        process.exit(0);
      }, 1000);
      
      return true;
    } catch (error) {
      console.error('Failed to clear caches and restart:', error);
      return false;
    }
  }

  private async resetAIAndRestart(): Promise<boolean> {
    try {
      console.log('Resetting AI service and restarting...');
      
      // Clear any AI-related memory/caches
      if (global.gc) {
        global.gc();
      }
      
      // Schedule restart
      setTimeout(() => {
        process.exit(0);
      }, 1000);
      
      return true;
    } catch (error) {
      console.error('Failed to reset AI service:', error);
      return false;
    }
  }

  private async resetDatabaseAndRestart(): Promise<boolean> {
    try {
      console.log('Resetting database and restarting...');
      
      // Try to gracefully close database connections
      try {
        const { db } = await import('./db');
        // Execute a simple query to test connection
        await db.execute('SELECT 1');
      } catch (dbError) {
        console.warn('Database connection test failed:', dbError);
      }
      
      // Schedule restart
      setTimeout(() => {
        process.exit(0);
      }, 1000);
      
      return true;
    } catch (error) {
      console.error('Failed to reset database:', error);
      return false;
    }
  }

  public getHealingHistory(): typeof this.healingHistory {
    return this.healingHistory;
  }
}

export const autoHealingSystem = AutoHealingSystem.getInstance();
export default AutoHealingSystem;