import type { Express } from "express";

export function registerAdminDirectAccess(app: Express): void {
  // Direct admin dashboard access with embedded authentication
  app.get("/admin-live", async (req, res) => {
    try {
      // Auto-authenticate admin user
      (req.session as any).adminUser = {
        email: "njpards1@gmail.com",
        role: "admin",
        authenticatedAt: new Date().toISOString()
      };

      // Serve the admin dashboard page directly
      res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoperCheck Admin Dashboard - Live</title>
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="robots" content="noindex, nofollow">
    <style>
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif; }
        .loading { display: flex; align-items: center; justify-content: center; height: 100vh; background: #f9fafb; }
        .spinner { width: 40px; height: 40px; border: 4px solid #e5e7eb; border-top: 4px solid #10b981; border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
    <script>
        // Auto-redirect to main dashboard after authentication
        setTimeout(() => {
            window.location.href = '/admin';
        }, 1000);
    </script>
</head>
<body>
    <div class="loading">
        <div class="spinner"></div>
    </div>
    <script>
        console.log('Admin session authenticated, redirecting to dashboard...');
    </script>
</body>
</html>
      `);
    } catch (error) {
      console.error('Admin direct access error:', error);
      res.status(500).send('Admin access failed');
    }
  });

  // Permanent admin session endpoint
  app.get("/admin-direct", async (req, res) => {
    try {
      // Set permanent admin session
      (req.session as any).adminUser = {
        email: "njpards1@gmail.com",
        role: "admin",
        authenticatedAt: new Date().toISOString(),
        permanent: true
      };

      // Return JSON confirmation
      res.json({
        success: true,
        message: 'Admin session established',
        dashboardUrl: '/admin',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ success: false, message: 'Authentication failed' });
    }
  });
}