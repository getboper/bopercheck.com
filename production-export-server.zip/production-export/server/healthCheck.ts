import { Request, Response } from 'express';
import { storage } from './storage.implementation';

interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  uptime: number;
  checks: {
    database: 'pass' | 'fail';
    storage: 'pass' | 'fail';
    anthropic: 'pass' | 'fail';
    sendgrid: 'pass' | 'fail';
  };
  version: string;
  environment: string;
}

export async function healthCheck(req: Request, res: Response): Promise<void> {
  const startTime = Date.now();
  
  const health: HealthStatus = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    checks: {
      database: 'pass',
      storage: 'pass',
      anthropic: 'pass',
      sendgrid: 'pass'
    },
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development'
  };

  // Test database connection
  try {
    await storage.getPlatformStats();
    health.checks.database = 'pass';
  } catch (error) {
    health.checks.database = 'fail';
    health.status = 'degraded';
  }

  // Test storage operations
  try {
    await storage.getTotalSearchCount();
    health.checks.storage = 'pass';
  } catch (error) {
    health.checks.storage = 'fail';
    health.status = 'degraded';
  }

  // Test Anthropic API availability
  try {
    if (!process.env.ANTHROPIC_API_KEY) {
      health.checks.anthropic = 'fail';
      health.status = 'degraded';
    } else {
      health.checks.anthropic = 'pass';
    }
  } catch (error) {
    health.checks.anthropic = 'fail';
    health.status = 'degraded';
  }

  // Test SendGrid API availability
  try {
    if (!process.env.SENDGRID_API_KEY) {
      health.checks.sendgrid = 'fail';
      health.status = 'degraded';
    } else {
      health.checks.sendgrid = 'pass';
    }
  } catch (error) {
    health.checks.sendgrid = 'fail';
    health.status = 'degraded';
  }

  // Determine overall health status
  const failedChecks = Object.values(health.checks).filter(check => check === 'fail').length;
  if (failedChecks >= 2) {
    health.status = 'unhealthy';
  } else if (failedChecks === 1) {
    health.status = 'degraded';
  }

  const responseTime = Date.now() - startTime;
  
  // Return appropriate HTTP status
  const statusCode = health.status === 'healthy' ? 200 : 
                    health.status === 'degraded' ? 200 : 503;

  res.status(statusCode).json({
    ...health,
    responseTime: `${responseTime}ms`
  });
}

export async function readinessCheck(req: Request, res: Response): Promise<void> {
  try {
    // Basic readiness checks for deployment
    const checks = {
      environment: process.env.NODE_ENV === 'production',
      secrets: !!(process.env.ANTHROPIC_API_KEY && process.env.SENDGRID_API_KEY),
      database: true // Will be tested in actual implementation
    };

    const ready = Object.values(checks).every(check => check);
    
    res.status(ready ? 200 : 503).json({
      ready,
      checks,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(503).json({
      ready: false,
      error: 'Readiness check failed',
      timestamp: new Date().toISOString()
    });
  }
}

export async function livenessCheck(req: Request, res: Response): Promise<void> {
  // Simple liveness probe for container health
  res.status(200).json({
    alive: true,
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
}