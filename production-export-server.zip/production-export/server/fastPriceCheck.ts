// REMOVED: Fast local supplier system - No fake listings allowed
// Only authentic business data from verified sources will be displayed
export function generateFastLocalSuppliers(query: string, location: string = 'UK') {
  return {
    localSuppliers: [],
    secondHandOptions: [],
    pricing: null,
    advertiseHereCTA: {
      show: true,
      message: `Missing from these results? Get featured in ${location} ${query} searches`,
      action: "List Your Business",
      targetService: query,
      targetLocation: location
    }
  };
}