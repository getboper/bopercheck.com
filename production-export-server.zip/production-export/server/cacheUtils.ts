import type { Request, Response, NextFunction } from 'express';

// Middleware to prevent caching and force fresh content
export function noCacheMiddleware(req: Request, res: Response, next: NextFunction) {
  // Set multiple cache-prevention headers
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', 'Thu, 01 Jan 1970 00:00:00 GMT');
  res.setHeader('Last-Modified', new Date().toUTCString());
  
  // Remove ETag to prevent conditional requests
  res.removeHeader('ETag');
  
  // Add timestamp to force freshness
  res.setHeader('X-Timestamp', Date.now().toString());
  
  next();
}

// Middleware specifically for HTML pages to combat cached error pages
export function htmlNoCacheMiddleware(req: Request, res: Response, next: NextFunction) {
  // Apply no-cache headers
  noCacheMiddleware(req, res, () => {});
  
  // Add HTML-specific headers
  res.setHeader('Vary', 'Accept-Encoding, User-Agent');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  
  next();
}

// Add cache-busting parameters to URLs
export function addCacheBuster(url: string): string {
  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}v=${Date.now()}`;
}

// Check if request is from a potentially cached source
export function isCachedRequest(req: Request): boolean {
  const userAgent = req.get('User-Agent') || '';
  const referer = req.get('Referer') || '';
  
  // Check for common cache indicators
  const cacheIndicators = [
    'cache',
    'offline',
    'service-worker',
    'sw.js'
  ];
  
  return cacheIndicators.some(indicator => 
    userAgent.toLowerCase().includes(indicator) ||
    referer.toLowerCase().includes(indicator)
  );
}

// Generate fresh content headers
export function getFreshContentHeaders() {
  const timestamp = Date.now();
  return {
    'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
    'Pragma': 'no-cache',
    'Expires': 'Thu, 01 Jan 1970 00:00:00 GMT',
    'Last-Modified': new Date().toUTCString(),
    'X-Timestamp': timestamp.toString(),
    'X-Fresh-Load': 'true',
    'Vary': 'Accept-Encoding, User-Agent'
  };
}