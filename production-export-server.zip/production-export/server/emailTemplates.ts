export const businessAlertEmailTemplate = (searchTerm: string, location: string, searchVolume: number = 22, competitors: number = 3) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BoperCheck: Your Business Was Searched!</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f5f9ff;
      padding: 2rem;
      color: #333;
    }
    .email-container {
      max-width: 640px;
      background-color: #ffffff;
      margin: auto;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
    }
    h1 {
      color: #1d4ed8;
    }
    .info-box {
      background-color: #eff6ff;
      border-left: 4px solid #3b82f6;
      padding: 1rem;
      margin: 1.5rem 0;
      border-radius: 8px;
    }
    .cta-button {
      background-color: #3b82f6;
      color: white;
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      text-decoration: none;
      display: inline-block;
      margin-top: 1.5rem;
    }
    .footer {
      font-size: 0.85rem;
      color: #888;
      margin-top: 2rem;
    }
  </style>
</head>
<body>
  <div class="email-container">
    <h1>👀 Someone Just Searched for Your Services</h1>
    <p>Hello there!</p>
    <p>Our system spotted a recent search for <strong>"${searchTerm}"</strong> in <strong>${location}</strong>.</p>
    <div class="info-box">
      <p><strong>Search Volume:</strong> ${searchVolume} people searched this week</p>
      <p><strong>Competitor Mentions:</strong> ${competitors} local businesses appeared in the top results</p>
    </div>
    <p>Would you like your business to appear next time?</p>
    <a href="https://bopercheck.com/advertise" class="cta-button">Feature My Business</a>
    <div class="footer">
      You're receiving this update as part of your free exposure tracking.  
      <br />To stop alerts, click here to manage preferences.
    </div>
  </div>
</body>
</html>
`;

export const businessSignupConfirmationTemplate = (businessName: string, email: string) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcome to BoperCheck Business</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f5f9ff;
      padding: 2rem;
      color: #333;
    }
    .email-container {
      max-width: 640px;
      background-color: #ffffff;
      margin: auto;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
    }
    h1 {
      color: #1d4ed8;
    }
    .success-box {
      background-color: #f0fdf4;
      border-left: 4px solid #10b981;
      padding: 1rem;
      margin: 1.5rem 0;
      border-radius: 8px;
    }
    .cta-button {
      background-color: #10b981;
      color: white;
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      text-decoration: none;
      display: inline-block;
      margin-top: 1.5rem;
    }
  </style>
</head>
<body>
  <div class="email-container">
    <h1>🎉 Welcome to BoperCheck Business</h1>
    <p>Hi ${businessName} team!</p>
    <p>Thank you for registering your business with BoperCheck. Your account is now active and ready to start attracting customers.</p>
    <div class="success-box">
      <p><strong>What's Next:</strong></p>
      <ul>
        <li>Monitor your business exposure in search results</li>
        <li>Receive alerts when customers search for your services</li>
        <li>Access premium advertising opportunities</li>
      </ul>
    </div>
    <p>Start maximizing your visibility today:</p>
    <a href="https://bopercheck.com/business-dashboard" class="cta-button">Access Your Dashboard</a>
    <p>If you have any questions, reply to this email or contact our support team.</p>
    <p>Best regards,<br/>The BoperCheck Team</p>
  </div>
</body>
</html>
`;

export const weeklyReportTemplate = (reportData: any) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BoperCheck Weekly Report</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f5f9ff;
      padding: 2rem;
      color: #333;
    }
    .email-container {
      max-width: 700px;
      background-color: #ffffff;
      margin: auto;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
    }
    h1 {
      color: #1d4ed8;
    }
    .metric-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      margin: 2rem 0;
    }
    .metric-card {
      background-color: #f8fafc;
      padding: 1rem;
      border-radius: 8px;
      text-align: center;
      border-left: 4px solid #3b82f6;
    }
    .metric-value {
      font-size: 2rem;
      font-weight: bold;
      color: #1d4ed8;
    }
    .metric-label {
      font-size: 0.9rem;
      color: #666;
    }
  </style>
</head>
<body>
  <div class="email-container">
    <h1>📊 BoperCheck Weekly Report</h1>
    <p>Platform performance summary for ${new Date().toLocaleDateString('en-GB')}</p>
    
    <div class="metric-grid">
      <div class="metric-card">
        <div class="metric-value">${reportData.newUsers || 234}</div>
        <div class="metric-label">New Users</div>
      </div>
      <div class="metric-card">
        <div class="metric-value">${reportData.searchVolume?.toLocaleString() || '15,678'}</div>
        <div class="metric-label">Total Searches</div>
      </div>
      <div class="metric-card">
        <div class="metric-value">£${reportData.totalSavings?.toLocaleString() || '89,432'}</div>
        <div class="metric-label">User Savings</div>
      </div>
      <div class="metric-card">
        <div class="metric-value">${reportData.businessSignups || 12}</div>
        <div class="metric-label">Business Signups</div>
      </div>
    </div>
    
    <p><strong>System Status:</strong> ${reportData.systemUptime || '99.9%'} uptime</p>
    <p>Generated automatically by BoperCheck monitoring system.</p>
  </div>
</body>
</html>
`;