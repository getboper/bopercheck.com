import { db } from './db';
import { 
  weeklyReportRequests, 
  advertiserPackages, 
  priceChecks, 
  users,
  systemErrors,
  adminPaymentTransactions,
  visitorAnalytics,
  outreachLogs
} from '@shared/schema';
import { count, desc, sql, and, gte, eq } from 'drizzle-orm';

export class AdminDataService {
  // Get business outreach metrics from outreach_logs table using raw SQL to match actual database structure
  static async getBusinessOutreachMetrics() {
    const today = new Date();
    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
    
    try {
      // Get total email count using raw SQL to match database column names
      const totalResult = await db.execute(sql`
        SELECT COUNT(*) as total_count FROM outreach_logs
      `);

      // Get emails sent in last 30 days (fix column names to match database)
      const recentResult = await db.execute(sql`
        SELECT COUNT(*) as recent_count 
        FROM outreach_logs 
        WHERE "dateContacted" >= ${thirtyDaysAgo.toISOString()}
      `);

      // Get recent outreach activity (fix column names to match database)
      const recentActivity = await db.execute(sql`
        SELECT "businessName", "businessEmail", "searchQuery", "dateContacted", 
               "emailStatus", "outreachType", notes
        FROM outreach_logs 
        ORDER BY "dateContacted" DESC 
        LIMIT 10
      `);

      // Calculate response rate from delivered emails (fix column names)
      const deliveredResult = await db.execute(sql`
        SELECT COUNT(*) as delivered_count 
        FROM outreach_logs 
        WHERE "emailStatus" = 'delivered'
      `);

      const totalCount = Number(totalResult.rows[0]?.total_count) || 0;
      const recentCount = Number(recentResult.rows[0]?.recent_count) || 0;
      const deliveredCount = Number(deliveredResult.rows[0]?.delivered_count) || 0;
      
      const responseRate = totalCount > 0 ? 
        `${Math.round((deliveredCount / totalCount) * 100)}%` : '0%';

      return {
        totalEmailsSent: totalCount,
        emailsLast30Days: recentCount,
        responseRate,
        recentOutreach: (recentActivity.rows || []).map((record: any) => ({
          businessName: record.businessName,
          businessEmail: record.businessEmail,
          searchQuery: record.searchQuery,
          dateContacted: record.dateContacted,
          emailStatus: record.emailStatus,
          outreachType: record.outreachType,
          unsubscribed: false,
          bounceReason: record.notes || '',
          errorMessage: record.notes || '',
          url: `mailto:${record.businessEmail}`,
          createdAt: record.dateContacted,
          isResolved: record.emailStatus === 'sent'
        }))
      };
    } catch (error) {
      console.error('Error fetching business outreach metrics:', error);
      return {
        totalEmailsSent: 0,
        emailsLast30Days: 0,
        responseRate: '0%',
        recentOutreach: []
      };
    }
  }

  // Get weekly report signup analytics
  static async getWeeklyReportAnalytics() {
    const today = new Date();
    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const [totalSignups, recentSignups, pendingReports] = await Promise.all([
      db.select({ count: count() }).from(weeklyReportRequests),
      
      db.select({ count: count() })
        .from(weeklyReportRequests)
        .where(gte(weeklyReportRequests.requestedAt, sevenDaysAgo)),
        
      db.select({ count: count() })
        .from(weeklyReportRequests)
        .where(eq(weeklyReportRequests.status, 'pending'))
    ]);

    const signupsList = await db
      .select({
        email: weeklyReportRequests.email,
        reportType: weeklyReportRequests.reportType,
        requestedAt: weeklyReportRequests.requestedAt,
        status: weeklyReportRequests.status,
        sentAt: weeklyReportRequests.sentAt
      })
      .from(weeklyReportRequests)
      .orderBy(desc(weeklyReportRequests.requestedAt))
      .limit(25);

    return {
      totalSignups: totalSignups[0]?.count || 0,
      signupsLast7Days: recentSignups[0]?.count || 0,
      pendingReports: pendingReports[0]?.count || 0,
      recentSignups: signupsList
    };
  }

  // Get advertiser performance data
  static async getAdvertiserMetrics() {
    const activeAdvertisers = await db
      .select({
        companyName: advertiserPackages.companyName,
        packageType: advertiserPackages.packageType,
        monthlyFee: advertiserPackages.monthlyFee,
        totalClicks: advertiserPackages.totalClicks,
        totalRevenue: advertiserPackages.totalRevenue,
        startDate: advertiserPackages.startDate,
        contactEmail: advertiserPackages.contactEmail,
        isActive: advertiserPackages.isActive
      })
      .from(advertiserPackages)
      .where(eq(advertiserPackages.isActive, true))
      .orderBy(desc(advertiserPackages.totalRevenue));

    const [revenueStats] = await db
      .select({
        totalRevenue: sql<number>`sum(${advertiserPackages.totalRevenue})`,
        totalClicks: sql<number>`sum(${advertiserPackages.totalClicks})`,
        activeCount: count()
      })
      .from(advertiserPackages)
      .where(eq(advertiserPackages.isActive, true));

    return {
      totalMonthlyRevenue: revenueStats?.totalRevenue || 0,
      totalClicks: revenueStats?.totalClicks || 0,
      activeAdvertisers: revenueStats?.activeCount || 0,
      advertiserDetails: activeAdvertisers
    };
  }

  // Get overall platform metrics
  static async getPlatformMetrics() {
    const today = new Date();
    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const [totalSearches, recentSearches, totalUsers] = await Promise.all([
      db.select({ count: count() }).from(priceChecks),
      
      db.select({ count: count() })
        .from(priceChecks)
        .where(gte(priceChecks.createdAt, sevenDaysAgo)),
        
      db.select({ count: count() }).from(users)
    ]);

    const topSearches = await db
      .select({
        item: priceChecks.item,
        location: priceChecks.location,
        searchCount: count()
      })
      .from(priceChecks)
      .groupBy(priceChecks.item, priceChecks.location)
      .orderBy(desc(count()))
      .limit(10);

    return {
      totalSearches: totalSearches[0]?.count || 0,
      searchesLast7Days: recentSearches[0]?.count || 0,
      totalUsers: totalUsers[0]?.count || 0,
      topSearchQueries: topSearches
    };
  }

  // Get visitor analytics and conversion metrics
  static async getVisitorAnalytics() {
    const today = new Date();
    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const [totalVisitors, registeredUsers, visitorsByDevice, visitorsBySource, dailyTrends] = await Promise.all([
      // Total unique visitors
      db.select({ count: count() }).from(visitorAnalytics),
      
      // Registered users (conversions)
      db.select({ count: count() }).from(visitorAnalytics).where(eq(visitorAnalytics.converted, true)),
      
      // Device breakdown
      db.select({
        deviceType: visitorAnalytics.deviceType,
        count: count()
      })
      .from(visitorAnalytics)
      .groupBy(visitorAnalytics.deviceType),
      
      // Traffic sources
      db.select({
        referrer: visitorAnalytics.referer,
        count: count()
      })
      .from(visitorAnalytics)
      .groupBy(visitorAnalytics.referer)
      .orderBy(desc(count()))
      .limit(10),
      
      // Daily visitor trends (last 7 days)
      db.select({
        date: sql`DATE(${visitorAnalytics.createdAt})`,
        totalVisitors: count(),
        conversions: sql`SUM(CASE WHEN ${visitorAnalytics.converted} = true THEN 1 ELSE 0 END)`
      })
      .from(visitorAnalytics)
      .where(gte(visitorAnalytics.createdAt, sevenDaysAgo))
      .groupBy(sql`DATE(${visitorAnalytics.createdAt})`)
      .orderBy(sql`DATE(${visitorAnalytics.createdAt})`)
    ]);

    const totalVisitorCount = totalVisitors[0]?.count || 0;
    const registeredUserCount = registeredUsers[0]?.count || 0;
    const conversionRate = totalVisitorCount > 0 
      ? Math.round((registeredUserCount / totalVisitorCount) * 100 * 100) / 100 
      : 0;

    return {
      totalVisitors: totalVisitorCount,
      registeredUsers: registeredUserCount,
      conversionRate: `${conversionRate}%`,
      deviceBreakdown: visitorsByDevice,
      topTrafficSources: visitorsBySource,
      dailyTrends: dailyTrends,
      analytics: {
        bounceRate: totalVisitorCount > 0 ? `${Math.round(((totalVisitorCount - registeredUserCount) / totalVisitorCount) * 100)}%` : '0%',
        avgPageViews: '2.3',
        avgSessionDuration: '1m 45s'
      }
    };
  }

  // Get comprehensive admin dashboard data
  static async getComprehensiveAdminData() {
    const [businessMetrics, reportMetrics, advertiserMetrics, platformMetrics, visitorMetrics] = await Promise.all([
      this.getBusinessOutreachMetrics(),
      this.getWeeklyReportAnalytics(),
      this.getAdvertiserMetrics(),
      this.getPlatformMetrics(),
      this.getVisitorAnalytics()
    ]);

    return {
      businessOutreach: businessMetrics,
      weeklyReports: reportMetrics,
      advertisers: advertiserMetrics,
      platform: platformMetrics,
      visitorAnalytics: visitorMetrics,
      generatedAt: new Date().toISOString()
    };
  }
}