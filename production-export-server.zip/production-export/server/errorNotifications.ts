import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  console.warn("SENDGRID_API_KEY not found - email notifications disabled");
}

const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface ErrorNotificationData {
  errorType: string;
  errorMessage: string;
  userDetails: {
    userAgent?: string;
    item?: string;
    location?: string;
    guestId?: string;
    timestamp: string;
  };
  severity: 'low' | 'medium' | 'high' | 'critical';
  stack?: string;
}

export async function sendErrorNotification(data: ErrorNotificationData): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.log('SendGrid not configured - skipping email notification');
    return false;
  }

  try {
    const severityColors = {
      low: '#10b981',
      medium: '#f59e0b', 
      high: '#ef4444',
      critical: '#dc2626'
    };

    const emailContent = {
      to: 'admin@bopercheck.com', // Replace with your admin email
      from: 'alerts@bopercheck.com', // Replace with verified sender
      subject: `🚨 BoperCheck ${data.severity.toUpperCase()} Error: ${data.errorType}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: ${severityColors[data.severity]}; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
            <h2 style="margin: 0; font-size: 24px;">BoperCheck Error Alert</h2>
            <p style="margin: 10px 0 0 0; font-size: 16px;">Severity: ${data.severity.toUpperCase()}</p>
          </div>
          
          <div style="background: #f9fafb; padding: 20px; border: 1px solid #e5e7eb;">
            <h3 style="color: #1f2937; margin: 0 0 15px 0;">Error Details</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px 12px; background: #fff; border: 1px solid #e5e7eb; font-weight: bold;">Error Type:</td>
                <td style="padding: 8px 12px; background: #fff; border: 1px solid #e5e7eb;">${data.errorType}</td>
              </tr>
              <tr>
                <td style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; font-weight: bold;">Message:</td>
                <td style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb;">${data.errorMessage}</td>
              </tr>
              <tr>
                <td style="padding: 8px 12px; background: #fff; border: 1px solid #e5e7eb; font-weight: bold;">Timestamp:</td>
                <td style="padding: 8px 12px; background: #fff; border: 1px solid #e5e7eb;">${data.userDetails.timestamp}</td>
              </tr>
              ${data.userDetails.item ? `
              <tr>
                <td style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; font-weight: bold;">Search Item:</td>
                <td style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb;">${data.userDetails.item}</td>
              </tr>
              ` : ''}
              ${data.userDetails.location ? `
              <tr>
                <td style="padding: 8px 12px; background: #fff; border: 1px solid #e5e7eb; font-weight: bold;">Location:</td>
                <td style="padding: 8px 12px; background: #fff; border: 1px solid #e5e7eb;">${data.userDetails.location}</td>
              </tr>
              ` : ''}
              ${data.userDetails.userAgent ? `
              <tr>
                <td style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; font-weight: bold;">User Agent:</td>
                <td style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; font-size: 12px;">${data.userDetails.userAgent}</td>
              </tr>
              ` : ''}
            </table>
          </div>

          ${data.stack ? `
          <div style="background: #fef2f2; padding: 20px; border: 1px solid #fecaca; border-radius: 0 0 8px 8px;">
            <h3 style="color: #dc2626; margin: 0 0 15px 0;">Stack Trace</h3>
            <pre style="background: #fff; padding: 15px; border-radius: 4px; font-size: 12px; overflow-x: auto; color: #374151;">${data.stack}</pre>
          </div>
          ` : ''}
          
          <div style="background: #f3f4f6; padding: 15px; text-align: center; border-radius: 0 0 8px 8px; font-size: 12px; color: #6b7280;">
            <p style="margin: 0;">This is an automated alert from BoperCheck error monitoring system.</p>
            <p style="margin: 5px 0 0 0;">Time: ${new Date().toLocaleString('en-GB', { timeZone: 'Europe/London' })}</p>
          </div>
        </div>
      `
    };

    await mailService.send(emailContent);
    console.log(`Error notification sent for ${data.errorType} (${data.severity})`);
    return true;

  } catch (error) {
    console.error('Failed to send error notification email:', error);
    return false;
  }
}

// Send immediate critical search failure notifications
export async function notifySearchFailure(
  errorMessage: string,
  item: string,
  userAgent?: string,
  location?: string,
  guestId?: string,
  stack?: string
): Promise<void> {
  const severity = errorMessage.includes('Method is not a valid HTTP token') || 
                  errorMessage.includes('Analysis failed') ||
                  errorMessage.includes('HTTP error! status: 500') ? 'critical' : 'high';

  await sendErrorNotification({
    errorType: 'Search Analysis Failure',
    errorMessage,
    userDetails: {
      item,
      location,
      userAgent,
      guestId,
      timestamp: new Date().toISOString()
    },
    severity,
    stack
  });
}

// Send performance degradation alerts
export async function notifyPerformanceDegradation(
  metric: string,
  currentValue: number,
  threshold: number,
  details: any
): Promise<void> {
  await sendErrorNotification({
    errorType: 'Performance Degradation',
    errorMessage: `${metric} has dropped to ${currentValue}, below threshold of ${threshold}`,
    userDetails: {
      timestamp: new Date().toISOString(),
      ...details
    },
    severity: 'medium'
  });
}

// Send system health alerts
export async function notifySystemHealth(
  component: string,
  status: string,
  details: any
): Promise<void> {
  const severity = status === 'down' ? 'critical' : status === 'degraded' ? 'high' : 'medium';

  await sendErrorNotification({
    errorType: 'System Health Alert',
    errorMessage: `${component} status: ${status}`,
    userDetails: {
      timestamp: new Date().toISOString(),
      ...details
    },
    severity
  });
}