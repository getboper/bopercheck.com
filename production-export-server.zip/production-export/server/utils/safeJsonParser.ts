export function safeJsonParse(jsonString: string, fallbackData?: any) {
  try {
    // Remove any non-JSON content before parsing
    let cleanJson = jsonString.trim();
    
    // Find JSON start and end markers
    const jsonStart = cleanJson.indexOf('{');
    const jsonEnd = cleanJson.lastIndexOf('}');
    
    if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
      cleanJson = cleanJson.substring(jsonStart, jsonEnd + 1);
    }
    
    const parsed = JSON.parse(cleanJson);
    
    // Validate that we have the expected structure
    if (typeof parsed === 'object' && parsed !== null) {
      return parsed;
    }
    
    throw new Error('Parsed JSON is not an object');
  } catch (error) {
    console.error('JSON parsing failed:', error);
    console.error('Original string:', jsonString.substring(0, 200) + '...');
    
    if (fallbackData) {
      return fallbackData;
    }
    
    // Return a safe fallback structure
    return {
      price: "Price not available",
      installation: "Installation cost not available", 
      rating: "Rating not available",
      savings: "Savings not available",
      summary: "Analysis not available due to parsing error",
      stores: [],
      vouchers: [],
      localInstallers: []
    };
  }
}

export function extractJsonFromText(text: string): string | null {
  try {
    // Try to find JSON-like content in the text
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    return jsonMatch ? jsonMatch[0] : null;
  } catch (error) {
    return null;
  }
}