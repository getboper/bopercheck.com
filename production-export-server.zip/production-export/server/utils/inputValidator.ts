export function validatePriceCheckInput(item: string, location?: string) {
  if (!item || typeof item !== 'string') {
    throw new Error('Item is required and must be a string');
  }
  
  const trimmedItem = item.trim();
  if (trimmedItem.length === 0) {
    throw new Error('Item cannot be empty');
  }
  
  if (trimmedItem.length > 200) {
    throw new Error('Item description cannot exceed 200 characters');
  }
  
  let trimmedLocation: string | undefined = undefined;
  if (location) {
    if (typeof location !== 'string') {
      throw new Error('Location must be a string');
    }
    
    trimmedLocation = location.trim();
    if (trimmedLocation.length > 100) {
      throw new Error('Location cannot exceed 100 characters');
    }
    
    if (trimmedLocation.length === 0) {
      trimmedLocation = undefined;
    }
  }
  
  return { item: trimmedItem, location: trimmedLocation };
}

export function validateBusinessOutreachInput(searchQuery: string, businessEmails: any) {
  if (!searchQuery || typeof searchQuery !== 'string') {
    throw new Error('Search query is required and must be a string');
  }
  
  const trimmedQuery = searchQuery.trim();
  if (trimmedQuery.length === 0) {
    throw new Error('Search query cannot be empty');
  }
  
  if (trimmedQuery.length > 500) {
    throw new Error('Search query cannot exceed 500 characters');
  }
  
  if (!Array.isArray(businessEmails)) {
    throw new Error('Business emails must be an array');
  }
  
  if (businessEmails.length === 0) {
    throw new Error('At least one email address is required');
  }
  
  if (businessEmails.length > 50) {
    throw new Error('Cannot send to more than 50 email addresses at once');
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const validEmails = businessEmails.map((email, index) => {
    if (typeof email !== 'string') {
      throw new Error(`Email at position ${index + 1} must be a string`);
    }
    
    const trimmed = email.trim();
    if (trimmed.length === 0) {
      throw new Error(`Email at position ${index + 1} cannot be empty`);
    }
    
    if (trimmed.length > 254) {
      throw new Error(`Email at position ${index + 1} is too long`);
    }
    
    if (!emailRegex.test(trimmed)) {
      throw new Error(`Invalid email format at position ${index + 1}: ${trimmed}`);
    }
    
    return trimmed;
  });
  
  return { searchQuery: trimmedQuery, businessEmails: validEmails };
}