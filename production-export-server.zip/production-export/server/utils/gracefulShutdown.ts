import type { Server } from 'http';

let server: Server | null = null;
let isShuttingDown = false;

export function setupGracefulShutdown(httpServer: Server) {
  server = httpServer;

  process.on('SIGTERM', handleShutdown);
  process.on('SIGINT', handleShutdown);
  process.on('SIGUSR2', handleShutdown);

  process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    handleShutdown();
  });

  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  });
}

function handleShutdown() {
  if (isShuttingDown) return;
  isShuttingDown = true;

  console.log('Received shutdown signal, starting graceful shutdown...');

  if (server) {
    server.close((err) => {
      if (err) {
        console.error('Error during server shutdown:', err);
        process.exit(1);
      } else {
        console.log('Server closed successfully');
        process.exit(0);
      }
    });

    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 30000);
  } else {
    process.exit(0);
  }
}