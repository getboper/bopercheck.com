import { MailService } from '@sendgrid/mail';

const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface ErrorReport {
  type: 'api_failure' | 'search_failure' | 'cache_issue' | 'system_error';
  message: string;
  stack?: string;
  userAgent?: string;
  timestamp: string;
  endpoint?: string;
  requestData?: any;
  guestId?: string;
}

// Send critical error emails immediately
export async function sendCriticalErrorEmail(error: ErrorReport) {
  if (!process.env.SENDGRID_API_KEY) {
    console.error('SENDGRID_API_KEY not configured - cannot send error emails');
    return;
  }

  try {
    const emailContent = `
CRITICAL ERROR DETECTED IN BOPERCHECK

Type: ${error.type}
Time: ${error.timestamp}
Endpoint: ${error.endpoint || 'Unknown'}
Guest ID: ${error.guestId || 'Unknown'}

Error Message:
${error.message}

Stack Trace:
${error.stack || 'No stack trace available'}

Request Data:
${JSON.stringify(error.requestData, null, 2)}

User Agent:
${error.userAgent || 'Unknown'}

This requires immediate attention as it affects core search functionality.
    `;

    await mailService.send({
      to: 'njpards1@gmail.com',
      from: 'admin@bopercheck.com',
      subject: `🚨 CRITICAL: BoperCheck ${error.type} - ${new Date().toLocaleString()}`,
      text: emailContent,
      html: emailContent.replace(/\n/g, '<br>')
    });

    console.log('Critical error email sent successfully');
  } catch (emailError) {
    console.error('Failed to send critical error email:', emailError);
  }
}

// Log and track all errors
export function logError(error: ErrorReport) {
  // Always log to console
  console.error('ERROR LOGGED:', {
    type: error.type,
    timestamp: error.timestamp,
    message: error.message,
    endpoint: error.endpoint,
    guestId: error.guestId
  });

  // Send email for critical errors
  if (error.type === 'api_failure' || error.type === 'search_failure') {
    sendCriticalErrorEmail(error).catch(console.error);
  }
}

// Middleware to catch and report API errors
export function errorReportingMiddleware(req: any, res: any, next: any) {
  const originalSend = res.send;
  
  res.send = function(data: any) {
    // Check for error responses
    if (res.statusCode >= 400) {
      logError({
        type: 'api_failure',
        message: `API Error ${res.statusCode}: ${data?.message || 'Unknown error'}`,
        timestamp: new Date().toISOString(),
        endpoint: req.path,
        requestData: req.body,
        guestId: req.headers['x-guest-id'],
        userAgent: req.headers['user-agent']
      });
    }
    
    return originalSend.call(this, data);
  };
  
  next();
}