import cron from 'node-cron';
import { publicBusinessOutreach } from './publicBusinessOutreach';

class AutomatedOutreachScheduler {
  private isActive = false;
  private dailyEmailCount = 0;
  private targetDailyEmails = 150;
  private lastResetDate = new Date().toDateString();

  constructor() {
    this.initializeScheduler();
  }

  private initializeScheduler() {
    console.log('🚀 Starting automated outreach: 150 emails per day');
    
    // Reset daily counter at midnight UK time
    cron.schedule('0 0 * * *', () => {
      this.resetDailyCounter();
    }, {
      timezone: "Europe/London"
    });

    // Send 6 emails every hour (24/7) = 144 emails per day
    cron.schedule('0 * * * *', async () => {
      if (this.shouldSendEmails()) {
        await this.sendHourlyBatch(6);
      }
    }, {
      timezone: "Europe/London"
    });

    // Business hours boost: Extra 3 emails every 2 hours (9 AM - 6 PM UK time)
    // This adds 15 more emails during business hours = 159 total (within target)
    cron.schedule('0 9-17/2 * * *', async () => {
      if (this.shouldSendEmails()) {
        await this.sendHourlyBatch(3);
      }
    }, {
      timezone: "Europe/London"
    });

    this.isActive = true;
    console.log('✅ Automated outreach scheduler activated');
    console.log('📧 Targeting 150 emails per day');
    console.log('⏰ Hourly batches: 24/7');
    console.log('🏢 Business hours boost: 9 AM - 6 PM UK time');
  }

  private resetDailyCounter() {
    const today = new Date().toDateString();
    if (this.lastResetDate !== today) {
      this.dailyEmailCount = 0;
      this.lastResetDate = today;
      console.log(`📅 Daily email counter reset - Target: ${this.targetDailyEmails} emails`);
    }
  }

  private shouldSendEmails(): boolean {
    this.resetDailyCounter();
    return this.isActive && this.dailyEmailCount < this.targetDailyEmails;
  }

  private async sendHourlyBatch(batchSize: number): Promise<void> {
    try {
      const remainingEmails = this.targetDailyEmails - this.dailyEmailCount;
      const emailsToSend = Math.min(batchSize, remainingEmails);

      if (emailsToSend <= 0) {
        console.log(`📊 Daily target reached: ${this.dailyEmailCount}/${this.targetDailyEmails} emails sent`);
        return;
      }

      console.log(`📤 Sending batch: ${emailsToSend} emails (${this.dailyEmailCount}/${this.targetDailyEmails} today)`);
      
      const result = await publicBusinessOutreach.runAutomatedOutreach(emailsToSend);
      
      if (result.success) {
        this.dailyEmailCount += result.emailsSent;
        console.log(`✅ Batch complete: ${result.emailsSent} emails sent to UK businesses`);
        console.log(`📈 Daily progress: ${this.dailyEmailCount}/${this.targetDailyEmails} emails`);
      } else {
        console.error('❌ Automated outreach batch failed:', result.error);
      }
    } catch (error) {
      console.error('❌ Error in automated outreach batch:', error);
    }
  }

  public getStatus() {
    this.resetDailyCounter();
    return {
      isActive: this.isActive,
      dailyEmailCount: this.dailyEmailCount,
      targetDailyEmails: this.targetDailyEmails,
      remainingToday: this.targetDailyEmails - this.dailyEmailCount,
      lastResetDate: this.lastResetDate
    };
  }

  public async triggerManualBatch(emailCount: number = 10): Promise<any> {
    if (!this.shouldSendEmails()) {
      return {
        success: false,
        message: `Daily limit reached: ${this.dailyEmailCount}/${this.targetDailyEmails} emails sent today`
      };
    }

    const emailsToSend = Math.min(emailCount, this.targetDailyEmails - this.dailyEmailCount);
    console.log(`🔧 Manual trigger: Sending ${emailsToSend} emails`);
    
    const result = await publicBusinessOutreach.runAutomatedOutreach(emailsToSend);
    
    if (result.success) {
      this.dailyEmailCount += result.emailsSent;
    }
    
    return result;
  }

  public stop() {
    this.isActive = false;
    console.log('⏹️ Automated outreach scheduler stopped');
  }

  public start() {
    this.isActive = true;
    console.log('▶️ Automated outreach scheduler started');
  }
}

export const automatedOutreachScheduler = new AutomatedOutreachScheduler();