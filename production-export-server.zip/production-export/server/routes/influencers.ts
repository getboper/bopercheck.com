import type { Express } from "express";
import { z } from "zod";
import { InfluencerOutreachService } from "../lib/influencerOutreach";

const searchInfluencersSchema = z.object({
  query: z.string().min(1),
  minFollowers: z.number().min(1000),
  categories: z.array(z.string()),
});

const outreachSchema = z.object({
  influencerIds: z.array(z.string()),
  subject: z.string().min(1),
  message: z.string().min(10),
});

const manualInfluencerSchema = z.object({
  tiktokHandle: z.string().min(1),
  displayName: z.string().min(1),
  followerCount: z.number().min(1000),
  engagementRate: z.string().optional(),
  email: z.string().email().optional(),
  instagramHandle: z.string().optional(),
  bio: z.string().optional(),
  location: z.string().optional(),
});

export function registerInfluencerRoutes(app: Express) {
  const outreachService = new InfluencerOutreachService();

  // Get all influencers
  app.get('/api/influencers', async (req, res) => {
    try {
      // Return empty array for now until database is set up
      res.json([]);
    } catch (error) {
      console.error('Error fetching influencers:', error);
      res.status(500).json({ message: 'Failed to fetch influencers' });
    }
  });

  // Search for new influencers using Perplexity API
  app.post('/api/influencers/search', async (req, res) => {
    try {
      const { query, minFollowers, categories } = searchInfluencersSchema.parse(req.body);
      
      if (!process.env.PERPLEXITY_API_KEY) {
        return res.status(400).json({ 
          message: 'Perplexity API key not configured. Please add PERPLEXITY_API_KEY to environment variables.' 
        });
      }

      const foundInfluencers = await outreachService.searchInfluencers(categories, minFollowers);
      
      res.json({
        message: `Found ${foundInfluencers.length} influencers`,
        influencers: foundInfluencers,
      });
    } catch (error) {
      console.error('Influencer search error:', error);
      res.status(500).json({ message: 'Failed to search influencers' });
    }
  });

  // Manually add an influencer
  app.post('/api/influencers/manual', async (req, res) => {
    try {
      const influencerData = manualInfluencerSchema.parse(req.body);
      
      // For now, just return the data as confirmation
      const influencer = {
        id: `inf_${Date.now()}`,
        ...influencerData,
        partnershipStatus: 'not_contacted',
        contactAttempts: 0,
        featuredOnApp: false,
        createdAt: new Date().toISOString(),
      };

      res.json(influencer);
    } catch (error) {
      console.error('Error adding influencer:', error);
      res.status(500).json({ message: 'Failed to add influencer' });
    }
  });

  // Send outreach messages
  app.post('/api/influencers/outreach', async (req, res) => {
    try {
      const { influencerIds, subject, message } = outreachSchema.parse(req.body);
      
      // Simulate outreach for now
      const results = influencerIds.map(id => ({
        influencerId: id,
        success: true,
      }));

      res.json({
        message: `Would send ${influencerIds.length} messages (demo mode)`,
        sent: influencerIds.length,
        failed: 0,
        results,
      });
    } catch (error) {
      console.error('Outreach error:', error);
      res.status(500).json({ message: 'Failed to send outreach messages' });
    }
  });

  // Get campaigns
  app.get('/api/campaigns', async (req, res) => {
    try {
      res.json([]);
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      res.status(500).json({ message: 'Failed to fetch campaigns' });
    }
  });

  // Sample influencers endpoint for demonstration
  app.get('/api/influencers/samples', async (req, res) => {
    try {
      const sampleInfluencers = [
        {
          id: 'inf_sample_1',
          tiktokHandle: 'moneysavingtips_uk',
          displayName: 'Sarah Money Saver',
          followerCount: 85000,
          engagementRate: '4.2%',
          email: 'hello@moneysavingtips.co.uk',
          instagramHandle: 'moneysavingtips_uk',
          bio: 'Helping UK families save money on everyday purchases. Financial tips, discount codes, and budget-friendly finds.',
          location: 'London, UK',
          partnershipStatus: 'not_contacted',
          contactAttempts: 0,
          featuredOnApp: false,
        },
        {
          id: 'inf_sample_2',
          tiktokHandle: 'frugal_living_uk',
          displayName: 'James Budget Expert',
          followerCount: 142000,
          engagementRate: '5.1%',
          email: 'contact@frugallivinguk.com',
          instagramHandle: 'frugal_living_uk',
          bio: 'Budget expert sharing frugal living tips, money-saving hacks, and affordable lifestyle content for UK viewers.',
          location: 'Manchester, UK',
          partnershipStatus: 'contacted',
          contactAttempts: 1,
          featuredOnApp: false,
        },
        {
          id: 'inf_sample_3',
          tiktokHandle: 'deals_and_steals_uk',
          displayName: 'Emma Deal Hunter',
          followerCount: 67000,
          engagementRate: '6.8%',
          email: 'partnerships@dealsandsteals.co.uk',
          instagramHandle: 'deals_steals_uk',
          bio: 'Finding the best deals across UK retailers. Daily discount codes, cashback tips, and shopping hacks.',
          location: 'Birmingham, UK',
          partnershipStatus: 'responded',
          contactAttempts: 2,
          featuredOnApp: true,
        }
      ];

      res.json(sampleInfluencers);
    } catch (error) {
      console.error('Error fetching sample influencers:', error);
      res.status(500).json({ message: 'Failed to fetch sample influencers' });
    }
  });
}