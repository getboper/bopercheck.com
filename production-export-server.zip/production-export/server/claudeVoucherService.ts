import Anthropic from '@anthropic-ai/sdk';

// the newest Anthropic model is "claude-sonnet-4-20250514" which was released May 14, 2025. Use this by default unless user has already selected claude-3-7-sonnet-20250219
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

interface VoucherAnalysis {
  hasVouchers: boolean;
  vouchers: Array<{
    code: string;
    description: string;
    value: number;
    retailer: string;
    expiryDate?: string;
  }>;
  potentialSavings: number;
  confidence: number;
}

interface PriceAnalysis {
  product: string;
  bestPrice: number;
  retailer: string;
  alternatives: Array<{
    retailer: string;
    price: number;
    availability: string;
  }>;
  vouchers: VoucherAnalysis;
  totalPotentialSavings: number;
}

export async function analyzePriceWithClaude(query: string, location: string = 'UK'): Promise<PriceAnalysis> {
  try {
    const prompt = `You are a UK price comparison expert. Analyze "${query}" in ${location} and return ONLY valid JSON:

{
  "product": "${query}",
  "bestPrice": 299,
  "retailer": "Amazon UK",
  "alternatives": [
    {
      "retailer": "Argos",
      "price": 329,
      "availability": "In Stock"
    },
    {
      "retailer": "Currys PC World", 
      "price": 349,
      "availability": "In Stock"
    }
  ],
  "vouchers": {
    "hasVouchers": true,
    "vouchers": [
      {
        "code": "SAVE15",
        "description": "15% off electronics",
        "value": 45,
        "retailer": "Amazon UK",
        "expiryDate": "End of month"
      }
    ],
    "potentialSavings": 45,
    "confidence": 0.8
  },
  "totalPotentialSavings": 45
}

Use current UK market prices for ${query}. Include real retailers: Amazon UK, Argos, Currys, John Lewis, B&Q, Screwfix, ASDA, Tesco, Sainsbury's. Return only the JSON object, no other text.`;

    const message = await Promise.race([
      anthropic.messages.create({
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }],
        model: 'claude-sonnet-4-20250514',
      }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Claude API timeout')), 8000)
      )
    ]) as any;

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    
    // Extract JSON from response with better parsing
    let jsonMatch = responseText.match(/```json\s*([\s\S]*?)\s*```/);
    if (!jsonMatch) {
      jsonMatch = responseText.match(/\{[\s\S]*\}/);
    }
    
    if (!jsonMatch) {
      // Return structured fallback response instead of throwing error
      return {
        product: query,
        bestPrice: 0,
        retailer: 'Analysis in progress',
        alternatives: [],
        vouchers: {
          hasVouchers: false,
          vouchers: [],
          potentialSavings: 0,
          confidence: 0
        },
        totalPotentialSavings: 0
      };
    }

    try {
      const analysis = JSON.parse(jsonMatch[1] || jsonMatch[0]) as PriceAnalysis;
      
      // Ensure complete response structure
      analysis.product = analysis.product || query;
      analysis.bestPrice = analysis.bestPrice || 0;
      analysis.retailer = analysis.retailer || 'Analysis in progress';
      analysis.alternatives = analysis.alternatives || [];
      analysis.vouchers = analysis.vouchers || {
        hasVouchers: false,
        vouchers: [],
        potentialSavings: 0,
        confidence: 0
      };
      analysis.totalPotentialSavings = analysis.totalPotentialSavings || 0;

      return analysis;
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      // Return structured fallback when parsing fails
      return {
        product: query,
        bestPrice: 0,
        retailer: 'Analysis in progress',
        alternatives: [],
        vouchers: {
          hasVouchers: false,
          vouchers: [],
          potentialSavings: 0,
          confidence: 0
        },
        totalPotentialSavings: 0
      };
    }
  } catch (error) {
    console.error('Claude analysis error:', error);
    throw error; // Re-throw to use enhanced analysis fallback
  }
}

export async function generateVoucherRecommendations(searchHistory: string[]): Promise<VoucherAnalysis> {
  try {
    const prompt = `
Based on this user's search history, recommend relevant vouchers and discount opportunities:

Search History: ${searchHistory.join(', ')}

Analyze their shopping patterns and suggest vouchers from UK retailers that would be most valuable.
Provide realistic voucher codes and savings opportunities.

Return JSON with this structure:
{
  "hasVouchers": true,
  "vouchers": [
    {
      "code": "voucher code",
      "description": "what it offers",
      "value": estimated_savings,
      "retailer": "retailer name",
      "expiryDate": "date if known"
    }
  ],
  "potentialSavings": total_value,
  "confidence": confidence_score
}
`;

    const message = await anthropic.messages.create({
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
      model: 'claude-sonnet-4-20250514',
    });

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      throw new Error('No JSON found in voucher recommendation response');
    }

    return JSON.parse(jsonMatch[0]) as VoucherAnalysis;
  } catch (error) {
    console.error('Voucher recommendation error:', error);
    return {
      hasVouchers: false,
      vouchers: [],
      potentialSavings: 0,
      confidence: 0
    };
  }
}

export async function detectBusinessOpportunities(query: string): Promise<{
  isBusinessOpportunity: boolean;
  businessType: string;
  recommendedServices: string[];
  estimatedBudget: number;
}> {
  try {
    const prompt = `
Analyze this search query to detect if it represents a business opportunity or commercial need:

Query: "${query}"

Determine if this is:
1. A business looking for services/suppliers
2. A commercial purchase need
3. A potential B2B opportunity

Return JSON:
{
  "isBusinessOpportunity": boolean,
  "businessType": "type of business or 'consumer'",
  "recommendedServices": ["service1", "service2"],
  "estimatedBudget": estimated_budget_range
}
`;

    const message = await anthropic.messages.create({
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
      model: 'claude-sonnet-4-20250514',
    });

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      return {
        isBusinessOpportunity: false,
        businessType: 'consumer',
        recommendedServices: [],
        estimatedBudget: 0
      };
    }

    return JSON.parse(jsonMatch[0]);
  } catch (error) {
    console.error('Business opportunity detection error:', error);
    return {
      isBusinessOpportunity: false,
      businessType: 'consumer',
      recommendedServices: [],
      estimatedBudget: 0
    };
  }
}