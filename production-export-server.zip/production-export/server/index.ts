import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import cookieParser from "cookie-parser";
import { registerRoutes } from "./routes";
import { startWeeklyReportScheduler } from "./weeklyReportScheduler";
import { registerAdminExportRoutes } from "./adminExportRoutes";
import { setupVite, serveStatic, log } from "./vite";
import { setupAuth } from "./auth";
import { setupVoucherPot } from "./voucherPot";
import { addCacheBustingHeaders, addVersionHeaders } from "./middleware/cacheHeaders";

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(cookieParser());

// Apply aggressive cache busting for live platform
app.use(addCacheBustingHeaders);
app.use(addVersionHeaders);

// Security headers and cache-busting for production deployment
app.use((req: Request, res: Response, next: NextFunction) => {
  // UK GDPR and security compliance headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  
  // Content Security Policy for UK compliance
  res.setHeader('Content-Security-Policy', 
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://apis.google.com https://www.gstatic.com; " +
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com; " +
    "img-src 'self' data: https:; " +
    "connect-src 'self' https://api.anthropic.com https://api.sendgrid.com;"
  );
  
  // Cache-busting for fresh frontend loads
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.setHeader('ETag', Date.now().toString());
  next();
});

// Serve dev-sandbox static files
app.use('/dev-sandbox', express.static('dev-sandbox'));

// Configure session middleware with proper persistence
app.use(session({
  secret: process.env.SESSION_SECRET || 'bopercheck-dev-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // Set to false to work with both HTTP and HTTPS
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    sameSite: 'lax'
  },
  name: 'bopercheck.sid'
}));

// Force production mode for deployment environments
if (process.env.REPLIT_DEPLOYMENT || process.env.NODE_ENV === "production") {
  process.env.NODE_ENV = "production";
  console.log("BoperCheck starting in production mode...");
} else {
  console.log("BoperCheck starting in development mode...");
}

// Initialize automated outreach scheduler (150 emails per day)
(async () => {
  try {
    const { automatedOutreachScheduler } = await import('./automatedOutreachScheduler');
    console.log('Business outreach system initialized');
    console.log('Automated outreach scheduler activated - 150 emails per day');
  } catch (error) {
    console.error('Failed to start automated outreach scheduler:', error);
  }
})();

// Initialize enhanced weekly report scheduler
(async () => {
  try {
    const { generateAndSendEnhancedWeeklyReports } = await import('./services/enhancedWeeklyReports');
    
    // Set up scheduler to run every Monday at 9 AM
    setInterval(async () => {
      const now = new Date();
      const dayOfWeek = now.getDay(); // 0 = Sunday, 1 = Monday
      const hour = now.getHours();
      
      // Run on Monday (1) at 9 AM
      if (dayOfWeek === 1 && hour === 9) {
        try {
          console.log('Triggering scheduled enhanced weekly reports...');
          await generateAndSendEnhancedWeeklyReports();
        } catch (error) {
          console.error('Scheduled enhanced report generation failed:', error);
        }
      }
    }, 60 * 60 * 1000); // Check every hour
    
    console.log('Enhanced weekly report scheduler started - premium reports will send every Monday at 9 AM');
  } catch (error) {
    console.error('Failed to start enhanced weekly report scheduler:', error);
  }
})();

// Handle domain redirects and ensure proper serving
app.use((req, res, next) => {
  // Get host from header
  const host = req.headers.host?.toLowerCase();
  
  // Set proper headers for all requests
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  
  // Only apply redirects for production domains
  if (host?.includes('bopercheck.com')) {
    // Force HTTPS if accessing via HTTP
    if (req.headers['x-forwarded-proto'] === 'http') {
      return res.redirect(301, `https://${host}${req.url}`);
    }
    
    // Standardize on non-www version (redirect www to non-www)
    if (host?.startsWith('www.')) {
      return res.redirect(301, `https://${host.replace('www.', '')}${req.url}`);
    }
  }
  
  // Continue if no redirect needed
  next();
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Add health endpoints directly before Vite middleware  
  const { healthCheck, readinessCheck, livenessCheck } = await import('./healthCheck');
  app.get('/health', healthCheck);
  app.get('/ready', readinessCheck);
  app.get('/live', livenessCheck);
  // Register ALL API routes BEFORE Vite middleware to prevent conflicts
  const server = await registerRoutes(app);
  
  // Setup authentication and voucher pot systems
  setupAuth(app);
  setupVoucherPot(app);
  
  // Setup Claude AI quick price check
  const { setupQuickPriceCheck } = await import('./quickPrice');
  setupQuickPriceCheck(app);
  
  // Register all admin routes
  const { registerAdminRoutes } = await import("./adminRoutes");
  const { registerAdminRealtimeRoutes } = await import("./adminRealtimeRoutes");
  const { registerAdminDirectAccess } = await import("./adminDirectAccess");
  const { registerPublicAdminAccess } = await import("./publicAdminAccess");
  registerAdminRoutes(app);
  registerAdminRealtimeRoutes(app);
  registerAdminDirectAccess(app);
  registerPublicAdminAccess(app);
  
  // Register admin export routes
  const { registerAdminExportRoutes } = await import('./adminExportRoutes');
  registerAdminExportRoutes(app);



  // Error handling middleware
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // Setup frontend serving AFTER all API routes are registered
  if (process.env.NODE_ENV === "production") {
    // In production, serve pre-built static files
    serveStatic(app);
  } else {
    // In development, use Vite middleware - this must come LAST
    await setupVite(app, server);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, async () => {
    // Initialize business outreach system
    const { initializeBusinessOutreach } = await import('./businessOutreach');
    await initializeBusinessOutreach();
    
    log(`serving on port ${port}`);
  });
})();
