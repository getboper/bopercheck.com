import { notifySystemHealth } from './errorNotifications';
import { EventEmitter } from 'events';

// Circuit Breaker Pattern - Netflix Hystrix Style
class CircuitBreaker {
  private failureCount = 0;
  private lastFailureTime = 0;
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  
  constructor(
    private threshold: number = 5,
    private timeout: number = 30000,
    private resetTimeout: number = 60000
  ) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureTime >= this.resetTimeout) {
        this.state = 'HALF_OPEN';
      } else {
        throw new Error('Circuit breaker is OPEN');
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    this.failureCount = 0;
    this.state = 'CLOSED';
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();
    
    if (this.failureCount >= this.threshold) {
      this.state = 'OPEN';
    }
  }

  getState(): string {
    return this.state;
  }
}

// Health Check Pattern - Kubernetes Style
class HealthChecker extends EventEmitter {
  private checks: Map<string, () => Promise<boolean>> = new Map();
  private status: Map<string, { healthy: boolean; lastCheck: number; latency: number }> = new Map();
  private interval: NodeJS.Timeout | null = null;

  constructor(private checkInterval: number = 5000) {
    super();
  }

  addCheck(name: string, check: () => Promise<boolean>): void {
    this.checks.set(name, check);
    this.status.set(name, { healthy: true, lastCheck: 0, latency: 0 });
  }

  start(): void {
    if (this.interval) return;
    
    this.interval = setInterval(() => {
      this.runHealthChecks();
    }, this.checkInterval);
    
    // Run initial check
    this.runHealthChecks();
  }

  stop(): void {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
  }

  private async runHealthChecks(): Promise<void> {
    const results = await Promise.allSettled(
      Array.from(this.checks.entries()).map(async ([name, check]) => {
        const startTime = Date.now();
        try {
          const result = await Promise.race([
            check(),
            new Promise<boolean>((_, reject) => 
              setTimeout(() => reject(new Error('Health check timeout')), 10000)
            )
          ]);
          
          const latency = Date.now() - startTime;
          const previousStatus = this.status.get(name);
          
          this.status.set(name, {
            healthy: result,
            lastCheck: Date.now(),
            latency
          });

          // Emit events for status changes
          if (previousStatus && previousStatus.healthy !== result) {
            this.emit('statusChange', { name, healthy: result, latency });
          }

          return { name, result, latency };
        } catch (error) {
          const latency = Date.now() - startTime;
          const previousStatus = this.status.get(name);
          
          this.status.set(name, {
            healthy: false,
            lastCheck: Date.now(),
            latency
          });

          if (previousStatus && previousStatus.healthy !== false) {
            this.emit('statusChange', { name, healthy: false, latency, error });
          }

          throw { name, error, latency };
        }
      })
    );

    // Process results and trigger alerts
    const failures = results
      .filter(result => result.status === 'rejected')
      .map(result => (result as PromiseRejectedResult).reason);

    if (failures.length > 0) {
      this.emit('healthCheckFailures', failures);
    }
  }

  getStatus(): Record<string, any> {
    const overall = Array.from(this.status.values()).every(s => s.healthy);
    return {
      overall,
      services: Object.fromEntries(this.status),
      timestamp: new Date().toISOString()
    };
  }
}

// Rate Limiter with Exponential Backoff - AWS API Gateway Style
class AdaptiveRateLimiter {
  private buckets: Map<string, { tokens: number; lastRefill: number; backoffUntil: number }> = new Map();
  
  constructor(
    private baseTokens: number = 100,
    private refillRate: number = 10, // tokens per second
    private backoffMultiplier: number = 2,
    private maxBackoff: number = 300000 // 5 minutes
  ) {}

  async tryAcquire(key: string, tokens: number = 1): Promise<boolean> {
    const now = Date.now();
    const bucket = this.buckets.get(key) || {
      tokens: this.baseTokens,
      lastRefill: now,
      backoffUntil: 0
    };

    // Check if in backoff period
    if (bucket.backoffUntil > now) {
      return false;
    }

    // Refill tokens
    const timeSinceRefill = (now - bucket.lastRefill) / 1000;
    const tokensToAdd = Math.floor(timeSinceRefill * this.refillRate);
    bucket.tokens = Math.min(this.baseTokens, bucket.tokens + tokensToAdd);
    bucket.lastRefill = now;

    if (bucket.tokens >= tokens) {
      bucket.tokens -= tokens;
      bucket.backoffUntil = 0; // Reset backoff on success
      this.buckets.set(key, bucket);
      return true;
    } else {
      // Apply exponential backoff
      const currentBackoff = bucket.backoffUntil > 0 ? 
        Math.min(this.maxBackoff, (bucket.backoffUntil - now) * this.backoffMultiplier) :
        1000; // Start with 1 second
      
      bucket.backoffUntil = now + currentBackoff;
      this.buckets.set(key, bucket);
      return false;
    }
  }

  getStatus(key: string): any {
    const bucket = this.buckets.get(key);
    if (!bucket) return { tokens: this.baseTokens, backoffUntil: 0 };
    
    return {
      tokens: bucket.tokens,
      backoffUntil: bucket.backoffUntil,
      inBackoff: bucket.backoffUntil > Date.now()
    };
  }
}

// Bulkhead Pattern - Isolate Critical Resources
class ResourcePool {
  private pools: Map<string, { available: number; total: number; queue: (() => void)[] }> = new Map();

  createPool(name: string, size: number): void {
    this.pools.set(name, {
      available: size,
      total: size,
      queue: []
    });
  }

  async acquire(poolName: string, timeout: number = 5000): Promise<() => void> {
    const pool = this.pools.get(poolName);
    if (!pool) throw new Error(`Pool ${poolName} not found`);

    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        const index = pool.queue.indexOf(resolver);
        if (index > -1) pool.queue.splice(index, 1);
        reject(new Error(`Resource acquisition timeout for pool ${poolName}`));
      }, timeout);

      const resolver = () => {
        clearTimeout(timeoutId);
        resolve(() => this.release(poolName));
      };

      if (pool.available > 0) {
        pool.available--;
        resolver();
      } else {
        pool.queue.push(resolver);
      }
    });
  }

  private release(poolName: string): void {
    const pool = this.pools.get(poolName);
    if (!pool) return;

    if (pool.queue.length > 0) {
      const next = pool.queue.shift();
      if (next) next();
    } else {
      pool.available++;
    }
  }

  getPoolStatus(): Record<string, any> {
    return Object.fromEntries(
      Array.from(this.pools.entries()).map(([name, pool]) => [
        name,
        {
          available: pool.available,
          total: pool.total,
          utilization: ((pool.total - pool.available) / pool.total) * 100,
          queueLength: pool.queue.length
        }
      ])
    );
  }
}

// Enterprise Auto-Healing System
class EnterpriseAutoHealing extends EventEmitter {
  private static instance: EnterpriseAutoHealing;
  private circuitBreakers: Map<string, CircuitBreaker> = new Map();
  private healthChecker: HealthChecker;
  private rateLimiter: AdaptiveRateLimiter;
  private resourcePool: ResourcePool;
  private errorCounts: Map<string, { count: number; window: number[] }> = new Map();
  private isInitialized = false;

  constructor() {
    super();
    this.healthChecker = new HealthChecker(3000); // 3 second checks
    this.rateLimiter = new AdaptiveRateLimiter();
    this.resourcePool = new ResourcePool();
    this.setupEventHandlers();
  }

  static getInstance(): EnterpriseAutoHealing {
    if (!EnterpriseAutoHealing.instance) {
      EnterpriseAutoHealing.instance = new EnterpriseAutoHealing();
    }
    return EnterpriseAutoHealing.instance;
  }

  initialize(): void {
    if (this.isInitialized) return;

    // Setup circuit breakers for critical services
    this.circuitBreakers.set('database', new CircuitBreaker(3, 30000, 60000));
    this.circuitBreakers.set('ai-service', new CircuitBreaker(5, 30000, 120000));
    this.circuitBreakers.set('email-service', new CircuitBreaker(3, 60000, 300000));

    // Setup resource pools
    this.resourcePool.createPool('database-connections', 20);
    this.resourcePool.createPool('ai-requests', 10);
    this.resourcePool.createPool('email-requests', 5);

    // Setup health checks
    this.healthChecker.addCheck('database', this.checkDatabase.bind(this));
    this.healthChecker.addCheck('ai-service', this.checkAIService.bind(this));
    this.healthChecker.addCheck('email-service', this.checkEmailService.bind(this));
    this.healthChecker.addCheck('memory-usage', this.checkMemoryUsage.bind(this));
    this.healthChecker.addCheck('response-time', this.checkResponseTime.bind(this));

    this.healthChecker.start();
    this.isInitialized = true;

    console.log('Enterprise auto-healing system initialized');
  }

  private setupEventHandlers(): void {
    this.healthChecker.on('statusChange', async (event) => {
      const { name, healthy, error } = event;
      
      if (!healthy) {
        console.log(`Health check failed for ${name}:`, error?.message);
        await this.handleServiceFailure(name, error);
      } else {
        console.log(`Health check recovered for ${name}`);
        await this.handleServiceRecovery(name);
      }
    });

    this.healthChecker.on('healthCheckFailures', async (failures) => {
      if (failures.length >= 2) {
        console.log('Multiple health check failures detected, initiating emergency protocols');
        await this.handleCascadingFailures(failures);
      }
    });
  }

  async processError(errorType: string, errorMessage: string, context: any): Promise<boolean> {
    try {
      // Rate limit error processing to prevent spam
      const canProcess = await this.rateLimiter.tryAcquire(`error-${errorType}`);
      if (!canProcess) {
        console.log(`Rate limiting error processing for ${errorType}`);
        return false;
      }

      // Track error patterns
      this.trackErrorPattern(errorType, errorMessage);

      // Determine severity and response
      const severity = this.calculateErrorSeverity(errorType, errorMessage);
      const strategy = this.selectHealingStrategy(errorType, severity, context);

      console.log(`Processing ${severity} error: ${errorType} with strategy: ${strategy.name}`);

      // Execute healing strategy with circuit breaker protection
      const circuitBreaker = this.circuitBreakers.get(strategy.service) || 
        new CircuitBreaker(3, 30000, 60000);

      const result = await circuitBreaker.execute(() => strategy.execute(context)) as boolean;
      
      if (result) {
        await notifySystemHealth('Auto-Healing', 'recovered', {
          errorType,
          strategy: strategy.name,
          timestamp: new Date().toISOString()
        });
        
        this.emit('healingSuccess', { errorType, strategy: strategy.name });
      }

      return result;
    } catch (healingError: any) {
      console.error('Healing strategy failed:', healingError);
      
      await notifySystemHealth('Auto-Healing', 'failed', {
        errorType,
        healingError: healingError?.message || 'Unknown error',
        timestamp: new Date().toISOString()
      });

      this.emit('healingFailure', { errorType, error: healingError?.message || 'Unknown error' });
      return false;
    }
  }

  private trackErrorPattern(errorType: string, errorMessage: string): void {
    const now = Date.now();
    const windowSize = 300000; // 5 minutes
    
    const errorData = this.errorCounts.get(errorType) || { count: 0, window: [] };
    
    // Clean old entries
    errorData.window = errorData.window.filter(time => now - time < windowSize);
    errorData.window.push(now);
    errorData.count = errorData.window.length;
    
    this.errorCounts.set(errorType, errorData);

    // Trigger escalation if error pattern indicates system degradation
    if (errorData.count >= 10) {
      this.emit('errorSpike', { errorType, count: errorData.count });
    }
  }

  private calculateErrorSeverity(errorType: string, errorMessage: string): 'low' | 'medium' | 'high' | 'critical' {
    const criticalPatterns = [
      'database connection',
      'out of memory',
      'service unavailable',
      'authentication failed'
    ];
    
    const highPatterns = [
      'method is not a valid http token',
      'analysis failed',
      'timeout',
      'rate limit exceeded'
    ];

    const mediumPatterns = [
      'json parsing failed',
      'invalid input',
      'validation error'
    ];

    const lowerMessage = errorMessage.toLowerCase();
    
    if (criticalPatterns.some(pattern => lowerMessage.includes(pattern))) {
      return 'critical';
    } else if (highPatterns.some(pattern => lowerMessage.includes(pattern))) {
      return 'high';
    } else if (mediumPatterns.some(pattern => lowerMessage.includes(pattern))) {
      return 'medium';
    }
    
    return 'low';
  }

  private selectHealingStrategy(errorType: string, severity: string, context: any): {
    name: string;
    service: string;
    execute: (context: any) => Promise<boolean>;
  } {
    const strategies: Record<string, {
      name: string;
      service: string;
      execute: (context: any) => Promise<boolean>;
    }> = {
      'http-token-error': {
        name: 'Header Validation Reset',
        service: 'api-gateway',
        execute: this.fixHeaderValidation.bind(this)
      },
      'json-parsing-error': {
        name: 'JSON Parser Recovery',
        service: 'parser',
        execute: this.fixJSONParsing.bind(this)
      },
      'database-error': {
        name: 'Database Connection Reset',
        service: 'database',
        execute: this.fixDatabaseConnection.bind(this)
      },
      'ai-service-error': {
        name: 'AI Service Recovery',
        service: 'ai-service',
        execute: this.fixAIService.bind(this)
      },
      'memory-error': {
        name: 'Memory Cleanup',
        service: 'system',
        execute: this.fixMemoryIssue.bind(this)
      },
      'complete-search-failure': {
        name: 'Complete Search Recovery',
        service: 'system',
        execute: this.fixHeaderValidation.bind(this)
      }
    };

    // Select strategy based on error type and severity
    const errorKey = errorType.toLowerCase().replace(/\s+/g, '-');
    
    return strategies[errorKey] || {
      name: 'Generic System Reset',
      service: 'system',
      execute: this.genericSystemReset.bind(this)
    };
  }

  // Healing Strategy Implementations
  private async fixHeaderValidation(context: any): Promise<boolean> {
    console.log('Executing header validation fix...');
    
    // Clear any cached header validation state
    if (global.gc) global.gc();
    
    // Trigger graceful restart with header fix
    setTimeout(() => process.exit(0), 2000);
    return true;
  }

  private async fixJSONParsing(context: any): Promise<boolean> {
    console.log('Executing JSON parsing recovery...');
    
    // Clear JSON parser caches
    if (global.gc) global.gc();
    
    setTimeout(() => process.exit(0), 1500);
    return true;
  }

  private async fixDatabaseConnection(context: any): Promise<boolean> {
    console.log('Executing database connection reset...');
    
    try {
      const releaseConnection = await this.resourcePool.acquire('database-connections');
      
      // Test database connection
      const { db } = await import('./db');
      await db.execute('SELECT 1');
      
      releaseConnection();
      return true;
    } catch (error) {
      console.error('Database reset failed, triggering restart:', error);
      setTimeout(() => process.exit(0), 2000);
      return true;
    }
  }

  private async fixAIService(context: any): Promise<boolean> {
    console.log('Executing AI service recovery...');
    
    // Clear AI service state and restart
    if (global.gc) global.gc();
    
    setTimeout(() => process.exit(0), 2000);
    return true;
  }

  private async fixMemoryIssue(context: any): Promise<boolean> {
    console.log('Executing memory cleanup...');
    
    // Force garbage collection
    if (global.gc) {
      global.gc();
      global.gc(); // Run twice for better cleanup
    }
    
    // Clear caches
    if (typeof window !== 'undefined' && 'caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
    }
    
    return true;
  }

  private async genericSystemReset(context: any): Promise<boolean> {
    console.log('Executing generic system reset...');
    
    if (global.gc) global.gc();
    setTimeout(() => process.exit(0), 2000);
    return true;
  }

  // Health Check Implementations
  private async checkDatabase(): Promise<boolean> {
    try {
      const { db } = await import('./db');
      await db.execute('SELECT 1');
      return true;
    } catch {
      return false;
    }
  }

  private async checkAIService(): Promise<boolean> {
    return !!process.env.ANTHROPIC_API_KEY;
  }

  private async checkEmailService(): Promise<boolean> {
    return !!process.env.SENDGRID_API_KEY;
  }

  private async checkMemoryUsage(): Promise<boolean> {
    const usage = process.memoryUsage();
    const heapUsedMB = usage.heapUsed / 1024 / 1024;
    return heapUsedMB < 450; // Alert if using more than 450MB
  }

  private async checkResponseTime(): Promise<boolean> {
    // This would be updated by request handlers
    return true;
  }

  // Failure Handlers
  private async handleServiceFailure(serviceName: string, error: any): Promise<void> {
    console.log(`Service failure detected: ${serviceName}`);
    
    const strategy = this.selectHealingStrategy(serviceName, 'high', { error });
    await strategy.execute({ serviceName, error });
  }

  private async handleServiceRecovery(serviceName: string): Promise<void> {
    console.log(`Service recovered: ${serviceName}`);
    
    // Reset circuit breaker if it exists
    const circuitBreaker = this.circuitBreakers.get(serviceName);
    if (circuitBreaker) {
      // Circuit breaker will reset itself on successful operation
    }
  }

  private async handleCascadingFailures(failures: any[]): Promise<void> {
    console.log('Handling cascading failures:', failures.length);
    
    await notifySystemHealth('System', 'degraded', {
      failures: failures.map(f => f.name),
      timestamp: new Date().toISOString()
    });

    // Emergency restart for cascading failures
    setTimeout(() => process.exit(0), 3000);
  }

  // Status and Metrics
  getSystemStatus(): any {
    return {
      health: this.healthChecker.getStatus(),
      circuitBreakers: Object.fromEntries(
        Array.from(this.circuitBreakers.entries()).map(([name, cb]) => [
          name,
          { state: cb.getState() }
        ])
      ),
      resourcePools: this.resourcePool.getPoolStatus(),
      errorCounts: Object.fromEntries(this.errorCounts),
      timestamp: new Date().toISOString()
    };
  }

  shutdown(): void {
    this.healthChecker.stop();
    this.removeAllListeners();
    console.log('Enterprise auto-healing system shutdown');
  }
}

export const enterpriseAutoHealing = EnterpriseAutoHealing.getInstance();
export default EnterpriseAutoHealing;