// Simple authentication system for voucher pot functionality
import type { Express } from "express";
import { storage } from "./storage";

// Simple user store for demo - in production use proper database
const users = new Map<string, { id: string; email: string; password: string; name: string }>();
const sessions = new Map<string, string>(); // sessionId -> userId

function generateSessionId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

export function setupAuth(app: Express) {
  // Simple login endpoint
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      // Find user by email
      const user = Array.from(users.values()).find(u => u.email === email);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      // Create session
      const sessionId = generateSessionId();
      sessions.set(sessionId, user.id);
      
      // Set session cookie
      res.cookie('sessionId', sessionId, { 
        httpOnly: true, 
        secure: false, // Set to true in production with HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
      });
      
      res.json({ 
        success: true, 
        user: { id: user.id, email: user.email, name: user.name }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Login failed' });
    }
  });

  // Simple signup endpoint
  app.post('/api/auth/signup', async (req, res) => {
    try {
      const { email, password, name } = req.body;
      
      // Check if user already exists
      const existingUser = Array.from(users.values()).find(u => u.email === email);
      if (existingUser) {
        return res.status(400).json({ error: 'User already exists' });
      }
      
      // Create new user
      const userId = `user_${Date.now()}_${Math.random().toString(36).substring(2)}`;
      const newUser = { id: userId, email, password, name };
      users.set(userId, newUser);
      
      // Create session
      const sessionId = generateSessionId();
      sessions.set(sessionId, userId);
      
      // Set session cookie
      res.cookie('sessionId', sessionId, { 
        httpOnly: true, 
        secure: false, // Set to true in production with HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
      });
      
      res.json({ 
        success: true, 
        user: { id: userId, email, name }
      });
    } catch (error) {
      console.error('Signup error:', error);
      res.status(500).json({ error: 'Signup failed' });
    }
  });

  // Logout endpoint
  app.post('/api/auth/logout', (req, res) => {
    const sessionId = req.cookies?.sessionId;
    if (sessionId) {
      sessions.delete(sessionId);
      res.clearCookie('sessionId');
    }
    res.json({ success: true });
  });

  // Get current user endpoint
  app.get('/api/auth/user', (req, res) => {
    const sessionId = req.cookies?.sessionId;
    const userId = sessionId ? sessions.get(sessionId) : null;
    const user = userId ? users.get(userId) : null;
    
    if (user) {
      res.json({ id: user.id, email: user.email, name: user.name });
    } else {
      res.status(401).json({ error: 'Not authenticated' });
    }
  });
}

// Middleware to check authentication
export function requireAuth(req: any, res: any, next: any) {
  const sessionId = req.cookies?.sessionId;
  const userId = sessionId ? sessions.get(sessionId) : null;
  const user = userId ? users.get(userId) : null;
  
  if (user) {
    req.user = user;
    next();
  } else {
    res.status(401).json({ error: 'Authentication required' });
  }
}