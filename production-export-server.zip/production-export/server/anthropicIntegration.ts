import Anthropic from '@anthropic-ai/sdk';

// Initialize Anthropic client if API key is available
const anthropic = process.env.ANTHROPIC_API_KEY ? new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
}) : null;

export interface PriceAnalysisRequest {
  item: string;
  description?: string;
  budget?: number;
  location?: string;
}

export interface PriceAnalysisResponse {
  isService: boolean;
  isValid: boolean;
  productName: string;
  category: string;
  retailers: Array<{
    name: string;
    price: number;
    link: string;
    notes: string;
    rating: number;
  }>;
  bestPrice: string;
  dealRating: string;
  analysis: string;
  message?: string;
}

// Add website extraction function
export async function extractWebsiteInfo(prompt: string): Promise<string> {
  if (!anthropic) {
    throw new Error('Anthropic API not configured');
  }

  try {
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514', // the newest Anthropic model is "claude-sonnet-4-20250514" which was released May 14, 2025. Use this by default unless user has already selected claude-3-7-sonnet-20250219
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }],
    });

    return message.content[0].type === 'text' ? message.content[0].text : '';
  } catch (error) {
    console.error('Claude API error:', error);
    throw error;
  }
}

export async function analyzeWithClaude(request: PriceAnalysisRequest): Promise<PriceAnalysisResponse> {
  const { item, description, budget, location } = request;
  
  // Service detection
  const serviceKeywords = ['restaurant', 'hotel', 'spa', 'salon', 'dentist', 'doctor', 'lawyer', 'accountant', 'plumber', 'electrician', 'mechanic', 'therapy', 'massage', 'hairdresser', 'barber', 'gym', 'fitness', 'personal trainer', 'tutor', 'cleaning service', 'taxi', 'uber', 'delivery', 'cafe', 'bar', 'pub'];
  
  const queryLower = item.toLowerCase();
  const isService = serviceKeywords.some(keyword => queryLower.includes(keyword));
  
  if (isService) {
    return {
      isService: true,
      isValid: false,
      productName: item,
      category: 'service',
      retailers: [],
      bestPrice: 'N/A',
      dealRating: 'N/A',
      analysis: '',
      message: `We specialize in product price comparison. For ${item} services, try Google Maps, Yelp, or local directories for reviews and pricing.`
    };
  }

  // If Claude API is available, use it for analysis
  if (anthropic) {
    try {
      const prompt = `Analyze this UK product search: "${item}${description ? ' - ' + description : ''}"
      
      Instructions:
      1. Determine if this is a valid product that can be bought from UK retailers
      2. Identify the product category (electronics, furniture, home_garden, general)
      3. Suggest realistic UK retailers that would sell this product
      4. Provide a brief analysis
      
      Respond in JSON format:
      {
        "isValid": true/false,
        "category": "electronics|furniture|home_garden|general",
        "analysis": "brief product analysis",
        "suggestedRetailers": ["Amazon UK", "Argos", "Currys PC World", etc.]
      }`;

      const response = await anthropic.messages.create({
        model: 'claude-3-sonnet-20240229',
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      });

      const content = response.content[0];
      if (content.type === 'text') {
        try {
          const analysis = JSON.parse(content.text);
          
          return {
            isService: false,
            isValid: analysis.isValid,
            productName: item,
            category: analysis.category || 'general',
            retailers: [],
            bestPrice: 'Analyzing...',
            dealRating: 'Pending',
            analysis: analysis.analysis || `Analyzing ${item} prices`,
            message: analysis.isValid ? undefined : `Unable to find reliable pricing for "${item}"`
          };
        } catch (parseError) {
          console.error('Claude response parsing error:', parseError);
        }
      }
    } catch (error) {
      console.error('Claude API error:', error);
    }
  }

  // Fallback analysis without Claude
  const category = determineCategory(item);
  
  return {
    isService: false,
    isValid: true,
    productName: item,
    category,
    retailers: [],
    bestPrice: 'Analyzing...',
    dealRating: 'Pending',
    analysis: `Searching UK retailers for ${item}`,
  };
}

function determineCategory(item: string): string {
  const queryLower = item.toLowerCase();
  
  if (queryLower.includes('laptop') || queryLower.includes('computer') || queryLower.includes('phone') || queryLower.includes('tablet') || queryLower.includes('headphones') || queryLower.includes('mouse') || queryLower.includes('keyboard') || queryLower.includes('monitor') || queryLower.includes('camera')) {
    return 'electronics';
  }
  
  if (queryLower.includes('chair') || queryLower.includes('desk') || queryLower.includes('sofa') || queryLower.includes('bed') || queryLower.includes('table') || queryLower.includes('furniture')) {
    return 'furniture';
  }
  
  if (queryLower.includes('garden') || queryLower.includes('plant') || queryLower.includes('grass') || queryLower.includes('outdoor') || queryLower.includes('lawn') || queryLower.includes('shed')) {
    return 'home_garden';
  }
  
  return 'general';
}