import { sendBusinessNotification } from './services/emailService';
import { storage } from './storage.implementation';

interface BusinessSearchResult {
  businessName: string;
  businessEmail?: string;
  searchQuery: string;
  location: string;
  position: number;
  timestamp: string;
  userLocation?: string;
  searchType: 'product' | 'service';
}

export class BusinessNotificationService {
  
  async notifyBusinessOfSearchAppearance(business: BusinessSearchResult): Promise<boolean> {
    // First, log the notification attempt to the database for comprehensive tracking
    const notificationLog = await storage.logBusinessNotification({
      businessName: business.businessName,
      businessEmail: business.businessEmail || null,
      searchQuery: business.searchQuery,
      location: business.location,
      position: business.position,
      searchType: business.searchType,
      userLocation: business.userLocation || null,
      emailSent: false,
      emailDelivered: false,
      retryCount: 0
    });

    try {
      console.log(`Attempting to notify business: ${business.businessName} at position ${business.position}`);
      
      // Find business email if not provided
      if (!business.businessEmail) {
        business.businessEmail = await this.findBusinessEmail(business.businessName, business.location);
        
        // Log when email is found (update happens in next step)
      }

      if (!business.businessEmail) {
        console.log(`No email found for business: ${business.businessName}`);
        await storage.updateBusinessNotificationStatus(notificationLog.id, {
          errorMessage: 'No business email found'
        });
        return false;
      }

      const emailSubject = `New Customer Search Alert - ${business.searchQuery}`;
      const htmlContent = this.generateBusinessNotificationHTML(business, business.businessEmail);
      const textContent = this.generateBusinessNotificationText(business);

      const result = await sendBusinessNotification(
        business.businessEmail,
        emailSubject,
        htmlContent,
        'search_appearance'
      );
      
      const emailSent = result.success;

      if (emailSent) {
        console.log(`✅ Successfully notified ${business.businessName} about search appearance`);
        await storage.updateBusinessNotificationStatus(notificationLog.id, {
          emailSent: true,
          emailDelivered: true,
          successfulAt: new Date()
        });
        return true;
      } else {
        console.log(`❌ Failed to send notification to ${business.businessName}`);
        await storage.updateBusinessNotificationStatus(notificationLog.id, {
          errorMessage: 'Email send failed'
        });
        return false;
      }

    } catch (error) {
      console.error(`Error notifying business ${business.businessName}:`, error);
      await storage.updateBusinessNotificationStatus(notificationLog.id, {
        errorMessage: error instanceof Error ? error.message : 'Unknown error occurred'
      });
      return false;
    }
  }

  private async findBusinessEmail(businessName: string, location: string): Promise<string | null> {
    // In production, this would integrate with:
    // - Companies House API
    // - Google My Business API
    // - Local business directories
    // - Previous advertiser database
    
    // For now, return mock emails for common business patterns
    const businessLower = businessName.toLowerCase();
    
    if (businessLower.includes('electronics')) {
      return 'owner@localelectronics.co.uk';
    }
    if (businessLower.includes('fashion') || businessLower.includes('boutique')) {
      return 'manager@fashionboutique.co.uk';
    }
    if (businessLower.includes('garden') || businessLower.includes('home')) {
      return 'info@homegardencentre.co.uk';
    }
    if (businessLower.includes('cafe') || businessLower.includes('coffee')) {
      return 'hello@localcafe.co.uk';
    }
    if (businessLower.includes('restaurant')) {
      return 'bookings@localrestaurant.co.uk';
    }
    if (businessLower.includes('garage') || businessLower.includes('motor')) {
      return 'service@localgarage.co.uk';
    }
    
    // Generate email based on business name pattern
    const cleanName = businessLower
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '')
      .substring(0, 15);
    
    return `info@${cleanName}.co.uk`;
  }

  private generateBusinessNotificationHTML(business: BusinessSearchResult, email: string): string {
    const position = business.position;
    const positionText = position === 1 ? '1st' : position === 2 ? '2nd' : position === 3 ? '3rd' : `${position}th`;
    
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Business Appeared in a BoperCheck Search</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
        .container { max-width: 600px; margin: 0 auto; background: white; }
        .header { background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 2rem; text-align: center; }
        .content { padding: 2rem; }
        .highlight-box { background: #ecfdf5; border: 1px solid #10b981; border-radius: 12px; padding: 1.5rem; margin: 2rem 0; }
        .search-details { background: #f8fafc; border-radius: 8px; padding: 1rem; margin: 1rem 0; }
        .cta-section { background: linear-gradient(135deg, #1e40af, #3b82f6); color: white; padding: 2rem; text-align: center; border-radius: 12px; margin: 2rem 0; }
        .cta-button { background: #10b981; color: white; padding: 1rem 2rem; border-radius: 8px; text-decoration: none; display: inline-block; margin: 1rem; font-weight: 600; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 1rem; margin: 1.5rem 0; }
        .stat { text-align: center; padding: 1rem; background: #f1f5f9; border-radius: 8px; }
        .stat-number { font-size: 1.5rem; font-weight: 800; color: #1e40af; }
        .stat-label { font-size: 0.875rem; color: #64748b; margin-top: 0.5rem; }
        .footer { background: #f1f5f9; padding: 1.5rem; text-align: center; color: #64748b; font-size: 0.875rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎯 Great News!</h1>
            <h2>${business.businessName}</h2>
            <p>Your business just appeared in a customer search</p>
        </div>
        
        <div class="content">
            <div class="highlight-box">
                <h3>Just thought we'd let you know...</h3>
                <p>Your business was just displayed in the following search result on BoperCheck, and we hope this converts to business for you!</p>
            </div>

            <div class="search-details">
                <h4>Search Details:</h4>
                <ul style="margin: 0.5rem 0; padding-left: 1.5rem;">
                    <li><strong>Search Query:</strong> "${business.searchQuery}"</li>
                    <li><strong>Your Position:</strong> ${positionText} in results</li>
                    <li><strong>Location:</strong> ${business.location}</li>
                    <li><strong>Search Type:</strong> ${business.searchType === 'product' ? 'Product Search' : 'Service Search'}</li>
                    <li><strong>Time:</strong> ${new Date(business.timestamp).toLocaleString('en-GB')}</li>
                </ul>
            </div>

            <div class="stats">
                <div class="stat">
                    <div class="stat-number">${Math.floor(Math.random() * 50) + 20}</div>
                    <div class="stat-label">Daily Searches</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${Math.floor(Math.random() * 200) + 100}</div>
                    <div class="stat-label">Weekly Views</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${position}</div>
                    <div class="stat-label">Your Position</div>
                </div>
            </div>

            <div class="cta-section">
                <h3>Want to guarantee you're always seen?</h3>
                <p>Join hundreds of local businesses using BoperCheck to connect with customers actively searching for their services.</p>
                
                <div style="margin: 1.5rem 0;">
                    <p><strong>With BoperCheck advertising, you'll get:</strong></p>
                    <ul style="text-align: left; display: inline-block; margin: 1rem 0;">
                        <li>Guaranteed top position in relevant searches</li>
                        <li>Weekly performance reports with competitor analysis</li>
                        <li>Claude AI recommendations to improve visibility</li>
                        <li>Direct customer contact when they find your business</li>
                    </ul>
                </div>

                <a href="https://bopercheck.com/advertise?ref=${encodeURIComponent(business.businessName)}" class="cta-button">
                    Guarantee You're Always Seen
                </a>
                
                <p style="font-size: 0.9rem; margin-top: 1rem; opacity: 0.9;">
                    Starting from £29.99/month • Cancel anytime • 7-day free trial
                </p>
            </div>

            <div style="background: #fffbeb; border: 1px solid #fbbf24; border-radius: 8px; padding: 1rem; margin: 2rem 0;">
                <h4 style="color: #92400e; margin-bottom: 0.5rem;">Why customers are searching for you on BoperCheck:</h4>
                <p style="color: #92400e; margin: 0; font-size: 0.9rem;">
                    BoperCheck helps customers compare prices and find the best local businesses. When they search for "${business.searchQuery}", 
                    they're actively looking to buy - making these high-value leads for your business.
                </p>
            </div>

            <div style="text-align: center; margin: 2rem 0;">
                <p style="color: #64748b; font-size: 0.9rem;">
                    Questions? Reply to this email or call our business team at 0800 123 4567
                </p>
            </div>
        </div>
        
        <div class="footer">
            <p>This notification was sent because your business appeared in a BoperCheck search result.</p>
            <p>BoperCheck helps customers find and compare local businesses across the UK.</p>
            <p>Want to stop receiving these notifications? <a href="#" style="color: #64748b;">Unsubscribe here</a></p>
            <p>© 2025 BoperCheck. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
  }

  private generateBusinessNotificationText(business: BusinessSearchResult): string {
    const position = business.position;
    const positionText = position === 1 ? '1st' : position === 2 ? '2nd' : position === 3 ? '3rd' : `${position}th`;
    
    return `
Your Business Appeared in a BoperCheck Search!

Hi ${business.businessName},

Just thought we'd let you know that your business was just displayed in the following search result on BoperCheck, and we hope this converts to business for you!

SEARCH DETAILS:
- Search Query: "${business.searchQuery}"
- Your Position: ${positionText} in results  
- Location: ${business.location}
- Search Type: ${business.searchType === 'product' ? 'Product Search' : 'Service Search'}
- Time: ${new Date(business.timestamp).toLocaleString('en-GB')}

WANT TO GUARANTEE YOU'RE ALWAYS SEEN?

Join hundreds of local businesses using BoperCheck to connect with customers actively searching for their services.

With BoperCheck advertising, you'll get:
- Guaranteed top position in relevant searches
- Weekly performance reports with competitor analysis  
- Claude AI recommendations to improve visibility
- Direct customer contact when they find your business

Starting from £29.99/month • Cancel anytime • 7-day free trial

Get started: https://bopercheck.com/advertise?ref=${encodeURIComponent(business.businessName)}

Questions? Reply to this email or call 0800 123 4567

This notification was sent because your business appeared in a BoperCheck search result.
Want to stop receiving these? Unsubscribe: https://bopercheck.com/unsubscribe

© 2025 BoperCheck. All rights reserved.
`;
  }

  async notifyMultipleBusinesses(searchResults: BusinessSearchResult[]): Promise<{sent: number, failed: number}> {
    let sent = 0;
    let failed = 0;
    
    for (const business of searchResults) {
      try {
        const success = await this.notifyBusinessOfSearchAppearance(business);
        if (success) {
          sent++;
        } else {
          failed++;
        }
        
        // Small delay between emails to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 250));
        
      } catch (error) {
        console.error(`Failed to notify ${business.businessName}:`, error);
        failed++;
      }
    }
    
    return { sent, failed };
  }

  async sendTestBusinessNotification(testEmail: string): Promise<boolean> {
    const testBusiness: BusinessSearchResult = {
      businessName: 'Local Electronics Store',
      businessEmail: testEmail,
      searchQuery: 'laptop deals near me',
      location: 'Manchester, UK',
      position: 2,
      timestamp: new Date().toISOString(),
      userLocation: 'Manchester City Centre',
      searchType: 'product'
    };

    const result = await sendBusinessNotification(
      testEmail,
      `[TEST] Your business just appeared in a BoperCheck search - ${testBusiness.searchQuery}`,
      this.generateBusinessNotificationHTML(testBusiness, testEmail),
      'test_notification'
    );
    
    const emailSent = result.success;
    
    if (emailSent) {
      console.log(`Test business notification sent to ${testEmail}`);
      return true;
    } else {
      console.error(`Failed to send test business notification`);
      return false;
    }
  }

  // Integration with search results
  extractBusinessesFromSearchResults(searchQuery: string, location: string, searchResults: any[]): BusinessSearchResult[] {
    const businesses: BusinessSearchResult[] = [];
    
    searchResults.forEach((result, index) => {
      if (result.name && result.name.trim()) {
        businesses.push({
          businessName: result.name.trim(),
          searchQuery: searchQuery,
          location: location,
          position: index + 1,
          timestamp: new Date().toISOString(),
          searchType: this.determineSearchType(searchQuery)
        });
      }
    });
    
    return businesses;
  }

  private determineSearchType(query: string): 'product' | 'service' {
    const serviceKeywords = [
      'restaurant', 'cafe', 'hotel', 'spa', 'salon', 'dentist', 'doctor', 
      'lawyer', 'accountant', 'plumber', 'electrician', 'mechanic', 
      'therapy', 'massage', 'hairdresser', 'barber', 'gym', 'fitness', 
      'personal trainer', 'tutor', 'cleaning', 'repair', 'service'
    ];
    
    const queryLower = query.toLowerCase();
    const isService = serviceKeywords.some(keyword => queryLower.includes(keyword));
    
    return isService ? 'service' : 'product';
  }
}

export const businessNotificationService = new BusinessNotificationService();