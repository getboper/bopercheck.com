import type { Express } from "express";
import { db } from "./db";
import { 
  priceChecks, 
  guestUsers, 
  users, 
  businessProfiles, 
  paymentTransactions,
  platformFailures
} from "../shared/schema";
import { desc, gte, and, eq, count, sum } from "drizzle-orm";

export function registerAdminExportRoutes(app: Express) {
  
  // Price checks export - your core business data
  app.get("/api/admin/export/price-checks", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (!adminUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const priceCheckData = await db
        .select()
        .from(priceChecks)
        .orderBy(desc(priceChecks.createdAt));

      // Convert to CSV format
      const headers = [
        'ID', 'User ID', 'Guest ID', 'Item', 'Description', 'Category', 
        'Budget', 'Has Image', 'Image URL', 'Result JSON', 'Created At', 
        'PDF Generated', 'Priority Processing'
      ];

      const csvRows = priceCheckData.map(row => [
        row.id,
        row.userId || '',
        row.guestId || '',
        `"${(row.item || '').replace(/"/g, '""')}"`,
        `"${(row.description || '').replace(/"/g, '""')}"`,
        row.category || '',
        row.budget || '',
        row.hasImage,
        row.imageUrl || '',
        `"${JSON.stringify(row.result || {}).replace(/"/g, '""')}"`,
        row.createdAt,
        row.pdfGenerated,
        row.priorityProcessing
      ]);

      const csvContent = [headers.join(','), ...csvRows.map(row => row.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="price-checks-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);

    } catch (error) {
      console.error('Price checks export error:', error);
      res.status(500).json({ error: 'Failed to export price checks data' });
    }
  });

  // Users export - registration and account data
  app.get("/api/admin/export/users", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (!adminUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const userData = await db
        .select()
        .from(users)
        .orderBy(desc(users.createdAt));

      const headers = [
        'ID', 'Username', 'Email', 'Stripe Customer ID', 'Stripe Subscription ID',
        'Credits', 'Referral Code', 'Is Business', 'Company Name', 'Business Type',
        'Account Status', 'Verification Status', 'Created At', 'Last Login'
      ];

      const csvRows = userData.map(row => [
        row.id,
        `"${(row.username || '').replace(/"/g, '""')}"`,
        `"${(row.email || '').replace(/"/g, '""')}"`,
        row.stripeCustomerId || '',
        row.stripeSubscriptionId || '',
        row.credits || 0,
        row.referralCode || '',
        row.isBusiness || false,
        `"${(row.companyName || '').replace(/"/g, '""')}"`,
        row.businessType || '',
        row.accountStatus || '',
        row.verificationStatus || '',
        row.createdAt,
        row.lastLogin || ''
      ]);

      const csvContent = [headers.join(','), ...csvRows.map(row => row.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="users-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);

    } catch (error) {
      console.error('Users export error:', error);
      res.status(500).json({ error: 'Failed to export users data' });
    }
  });

  // Guest users export - traffic analysis
  app.get("/api/admin/export/guests", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (!adminUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const guestData = await db
        .select()
        .from(guestUsers)
        .orderBy(desc(guestUsers.createdAt));

      const headers = [
        'ID', 'Guest ID', 'Search Count', 'Used Free Credit', 'Last Activity',
        'IP Address', 'User Agent', 'Created At'
      ];

      const csvRows = guestData.map(row => [
        row.id,
        row.guestId || '',
        row.searchCount || 0,
        row.usedFreeCredit || false,
        row.lastActivity || '',
        row.ipAddress || '',
        `"${(row.userAgent || '').replace(/"/g, '""')}"`,
        row.createdAt
      ]);

      const csvContent = [headers.join(','), ...csvRows.map(row => row.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="guest-users-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);

    } catch (error) {
      console.error('Guest users export error:', error);
      res.status(500).json({ error: 'Failed to export guest users data' });
    }
  });

  // Business profiles export
  app.get("/api/admin/export/businesses", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (!adminUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const businessData = await db
        .select()
        .from(businessProfiles)
        .orderBy(desc(businessProfiles.createdAt));

      const headers = [
        'ID', 'User ID', 'Logo', 'Cover Image', 'Description', 'Address',
        'City', 'Region', 'Postal Code', 'Country', 'Phone', 'Website',
        'Social Links', 'Business Hours', 'Featured', 'Featured Until',
        'Created At', 'Updated At'
      ];

      const csvRows = businessData.map(row => [
        row.id,
        row.userId,
        row.logo || '',
        row.coverImage || '',
        `"${(row.description || '').replace(/"/g, '""')}"`,
        `"${(row.address || '').replace(/"/g, '""')}"`,
        row.city || '',
        row.region || '',
        row.postalCode || '',
        row.country || '',
        row.phone || '',
        row.website || '',
        `"${JSON.stringify(row.socialLinks || {}).replace(/"/g, '""')}"`,
        `"${JSON.stringify(row.businessHours || {}).replace(/"/g, '""')}"`,
        row.featured || false,
        row.featuredUntil || '',
        row.createdAt,
        row.updatedAt || ''
      ]);

      const csvContent = [headers.join(','), ...csvRows.map(row => row.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="businesses-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);

    } catch (error) {
      console.error('Business export error:', error);
      res.status(500).json({ error: 'Failed to export business data' });
    }
  });

  // Revenue and payment transactions export
  app.get("/api/admin/export/revenue", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (!adminUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const revenueData = await db
        .select()
        .from(paymentTransactions)
        .orderBy(desc(paymentTransactions.createdAt));

      const headers = [
        'ID', 'User ID', 'Stripe Payment Intent ID', 'Amount', 'Currency',
        'Status', 'Type', 'Description', 'Created At'
      ];

      const csvRows = revenueData.map(row => [
        row.id,
        row.userId || '',
        row.stripePaymentIntentId || '',
        row.amount || 0,
        row.currency || 'GBP',
        row.status || '',
        row.type || '',
        `"${(row.description || '').replace(/"/g, '""')}"`,
        row.createdAt
      ]);

      const csvContent = [headers.join(','), ...csvRows.map(row => row.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="revenue-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);

    } catch (error) {
      console.error('Revenue export error:', error);
      res.status(500).json({ error: 'Failed to export revenue data' });
    }
  });

  // Platform failures and error tracking export
  app.get("/api/admin/export/platform-failures", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (!adminUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const failureData = await db
        .select()
        .from(platformFailures)
        .orderBy(desc(platformFailures.createdAt));

      const headers = [
        'ID', 'Failure Type', 'Error Message', 'URL', 'User Agent',
        'User ID', 'Resolved', 'Created At'
      ];

      const csvRows = failureData.map(row => [
        row.id,
        row.failureType || '',
        `"${(row.errorMessage || '').replace(/"/g, '""')}"`,
        row.url || '',
        `"${(row.userAgent || '').replace(/"/g, '""')}"`,
        row.userId || '',
        row.resolved || false,
        row.createdAt
      ]);

      const csvContent = [headers.join(','), ...csvRows.map(row => row.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="platform-failures-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);

    } catch (error) {
      console.error('Platform failures export error:', error);
      res.status(500).json({ error: 'Failed to export platform failures data' });
    }
  });

  // Comprehensive analytics summary export
  app.get("/api/admin/export/analytics-summary", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (!adminUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const today = new Date();
      const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
      const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

      // Get comprehensive analytics from actual database
      const [
        totalPriceChecks,
        priceChecksLast30Days,
        priceChecksLast7Days,
        totalUsers,
        totalGuestUsers,
        totalBusinesses,
        totalRevenue,
        totalPlatformFailures
      ] = await Promise.all([
        db.select({ count: count() }).from(priceChecks),
        db.select({ count: count() }).from(priceChecks).where(gte(priceChecks.createdAt, thirtyDaysAgo)),
        db.select({ count: count() }).from(priceChecks).where(gte(priceChecks.createdAt, sevenDaysAgo)),
        db.select({ count: count() }).from(users),
        db.select({ count: count() }).from(guestUsers),
        db.select({ count: count() }).from(businessProfiles),
        db.select({ total: sum(paymentTransactions.amount) }).from(paymentTransactions).where(eq(paymentTransactions.status, 'succeeded')),
        db.select({ count: count() }).from(platformFailures)
      ]);

      const analyticsData = [
        ['Metric', 'Value', 'Generated At'],
        ['Total Price Checks', totalPriceChecks[0]?.count || 0, new Date().toISOString()],
        ['Price Checks (Last 30 Days)', priceChecksLast30Days[0]?.count || 0, new Date().toISOString()],
        ['Price Checks (Last 7 Days)', priceChecksLast7Days[0]?.count || 0, new Date().toISOString()],
        ['Total Registered Users', totalUsers[0]?.count || 0, new Date().toISOString()],
        ['Total Guest Users', totalGuestUsers[0]?.count || 0, new Date().toISOString()],
        ['Total Business Profiles', totalBusinesses[0]?.count || 0, new Date().toISOString()],
        ['Total Revenue (GBP)', totalRevenue[0]?.total || 0, new Date().toISOString()],
        ['Total Platform Failures', totalPlatformFailures[0]?.count || 0, new Date().toISOString()]
      ];

      const csvContent = analyticsData.map(row => row.join(',')).join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="analytics-summary-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);

    } catch (error) {
      console.error('Analytics summary export error:', error);
      res.status(500).json({ error: 'Failed to export analytics summary' });
    }
  });
}