import { MailService } from '@sendgrid/mail';

const apiKey = process.env.SENDGRID_API_KEY || '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';
const mailService = new MailService();
mailService.setApiKey(apiKey);

export async function testEmailSetup(): Promise<{success: boolean, message: string, details?: any}> {
  try {
    // Test with verified sender - your Gmail address
    const testEmail = {
      to: 'njpards1@gmail.com',
      from: 'support@bopercheck.com', // Verified sender in SendGrid
      subject: 'BoperCheck Email System Test',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #10b981;">BoperCheck Email System Test</h2>
          <p>This is a test email from your BoperCheck automatic email system.</p>
          <p><strong>Status:</strong> System is configured and ready to send automatic apologies to users who experience technical issues.</p>
          <p><strong>Next Steps:</strong></p>
          <ul>
            <li>Verify your sender domain in SendGrid dashboard</li>
            <li>Or use Single Sender Verification for immediate testing</li>
          </ul>
          <p>Time: ${new Date().toISOString()}</p>
        </div>
      `
    };

    await mailService.send(testEmail);
    
    return {
      success: true,
      message: 'Test email sent successfully! Check your inbox at njpards1@gmail.com'
    };
    
  } catch (error: any) {
    return {
      success: false,
      message: 'Email setup needs verification',
      details: {
        error: error.message,
        code: error.code,
        solution: 'Go to SendGrid dashboard > Settings > Sender Authentication to verify support@bopercheck.com'
      }
    };
  }
}

export async function sendTestApologyEmail(): Promise<{success: boolean, message: string}> {
  try {
    const apologyEmail = {
      to: 'njpards1@gmail.com',
      from: 'support@bopercheck.com',
      subject: 'We\'re Sorry - BoperCheck Technical Issue Resolved',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .cta-button { background: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>We're Sorry About That</h1>
              <p>Technical Issue Detected & Resolved</p>
            </div>
            <div class="content">
              <p>Hi there,</p>
              
              <p>We detected that you may have experienced a technical issue while using BoperCheck. We sincerely apologize for any inconvenience this may have caused.</p>
              
              <p><strong>What happened:</strong> Our monitoring system detected a potential cache error during your recent price search.</p>
              
              <p><strong>What we've done:</strong> Our technical team has been automatically notified and the issue has been resolved.</p>
              
              <a href="https://getboper.com" class="cta-button">Try BoperCheck Again</a>
              
              <p>As an apology, here are some money-saving tips:</p>
              <ul>
                <li>🔍 Use specific product model numbers for better price comparisons</li>
                <li>💰 Check for voucher codes before making purchases</li>
                <li>📅 Price tracking can alert you to future deals</li>
              </ul>
              
              <p>Thank you for your patience and for using BoperCheck.</p>
              
              <p>Best regards,<br>
              The BoperCheck Team</p>
              
              <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
              <p style="font-size: 12px; color: #666;">
                This email was automatically sent by our error monitoring system.
                Visit <a href="https://getboper.com">BoperCheck</a> for the latest price comparisons.
              </p>
            </div>
          </div>
        </body>
        </html>
      `
    };

    await mailService.send(apologyEmail);
    
    return {
      success: true,
      message: 'Apology email sent successfully!'
    };
    
  } catch (error: any) {
    return {
      success: false,
      message: `Email failed: ${error.message}`
    };
  }
}