// Admin authentication middleware for secure dashboard access
interface AdminCredentials {
  email: string;
  password: string;
}

const ADMIN_EMAIL = 'njpards1@gmail.com';
const ADMIN_PASSWORD = 'njpards1@gmail.com';

export function validateAdminCredentials(email: string, password: string): boolean {
  return email === ADMIN_EMAIL && password === ADMIN_PASSWORD;
}

export function requireAdminAuth(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Admin authentication required' });
  }
  
  try {
    const token = authHeader.substring(7);
    const credentials = JSON.parse(Buffer.from(token, 'base64').toString());
    
    if (!validateAdminCredentials(credentials.email, credentials.password)) {
      return res.status(401).json({ error: 'Invalid admin credentials' });
    }
    
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid authentication token' });
  }
}

export function generateAdminToken(email: string, password: string): string {
  const credentials = { email, password };
  return Buffer.from(JSON.stringify(credentials)).toString('base64');
}