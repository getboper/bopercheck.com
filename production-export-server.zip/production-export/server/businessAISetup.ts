import Anthropic from '@anthropic-ai/sdk';
import { db } from './db';
import { users, businessProfiles, paymentTransactions } from '@shared/schema';
import { eq } from 'drizzle-orm';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export interface BusinessSetupData {
  businessName: string;
  industry: string;
  description?: string;
  location?: string;
  services?: string[];
  targetAudience?: string;
  website?: string;
  phone?: string;
}

export interface AIBusinessProfile {
  optimizedDescription: string;
  suggestedCategories: string[];
  keywordTags: string[];
  competitorAnalysis: string;
  marketingTips: string[];
  pricingStrategy: string;
  targetCustomers: string;
}

export async function setupBusinessWithAI(userId: number, setupData: BusinessSetupData): Promise<AIBusinessProfile> {
  // the newest Anthropic model is "claude-sonnet-4-20250514" which was released May 14, 2025
  const prompt = `You are a business marketing expert helping to optimize a business listing for maximum customer engagement. 

Business Information:
- Name: ${setupData.businessName}
- Industry: ${setupData.industry}
- Description: ${setupData.description || 'Not provided'}
- Location: ${setupData.location || 'UK'}
- Services: ${setupData.services?.join(', ') || 'Not specified'}
- Target Audience: ${setupData.targetAudience || 'General public'}
- Website: ${setupData.website || 'None'}
- Phone: ${setupData.phone || 'Not provided'}

Please provide comprehensive business optimization recommendations in JSON format:

{
  "optimizedDescription": "A compelling 2-3 sentence business description that highlights unique value proposition and key services",
  "suggestedCategories": ["category1", "category2", "category3"],
  "keywordTags": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"],
  "competitorAnalysis": "Brief analysis of market position and competitive advantages",
  "marketingTips": ["tip1", "tip2", "tip3"],
  "pricingStrategy": "Recommended pricing approach for this business type",
  "targetCustomers": "Description of ideal customer profile"
}

Requirements:
- Description must be engaging and professional
- Categories should be specific and searchable
- Keywords should be terms customers actually search for
- Marketing tips should be actionable and specific to this business
- All recommendations should be realistic and implementable
- Focus on UK market context`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }],
    });

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    
    // Clean the response text to extract JSON
    let cleanedResponse = responseText;
    if (responseText.includes('```json')) {
      cleanedResponse = responseText.split('```json')[1].split('```')[0].trim();
    } else if (responseText.includes('```')) {
      cleanedResponse = responseText.split('```')[1].trim();
    }
    
    const aiProfile: AIBusinessProfile = JSON.parse(cleanedResponse);

    // Save the optimized profile to database
    await updateBusinessProfile(userId, setupData, aiProfile);

    return aiProfile;
  } catch (error) {
    console.error('AI business setup error:', error);
    // Fallback profile if AI fails
    return {
      optimizedDescription: `${setupData.businessName} provides professional ${setupData.industry} services. Contact us for quality solutions tailored to your needs.`,
      suggestedCategories: [setupData.industry, 'services', 'local business'],
      keywordTags: [setupData.industry, 'professional', 'quality', 'reliable', 'local'],
      competitorAnalysis: 'Position your business by emphasizing quality and customer service.',
      marketingTips: ['Highlight unique selling points', 'Encourage customer reviews', 'Maintain consistent branding'],
      pricingStrategy: 'Competitive pricing with value-added services',
      targetCustomers: 'Local customers seeking reliable service providers'
    };
  }
}

async function updateBusinessProfile(userId: number, setupData: BusinessSetupData, aiProfile: AIBusinessProfile) {
  // Update user business categories
  await db.update(users)
    .set({
      businessCategories: aiProfile.suggestedCategories,
      businessType: setupData.industry,
      companyName: setupData.businessName
    })
    .where(eq(users.id, userId));

  // Create or update business profile
  try {
    await db.insert(businessProfiles).values({
      userId: userId,
      description: aiProfile.optimizedDescription,
      phone: setupData.phone || null,
      website: setupData.website || null,
      address: setupData.location || null,
      country: 'United Kingdom',
      businessHours: {
        monday: '9:00-17:00',
        tuesday: '9:00-17:00', 
        wednesday: '9:00-17:00',
        thursday: '9:00-17:00',
        friday: '9:00-17:00',
        saturday: 'Closed',
        sunday: 'Closed'
      }
    });
  } catch (error) {
    // Profile might already exist, update it
    await db.update(businessProfiles)
      .set({
        description: aiProfile.optimizedDescription,
        phone: setupData.phone || null,
        website: setupData.website || null,
        address: setupData.location || null,
        updatedAt: new Date()
      })
      .where(eq(businessProfiles.userId, userId));
  }
}

export async function getBusinessDisplayInfo(userId: number) {
  const [business] = await db
    .select({
      businessName: users.companyName,
      username: users.username,
      email: users.email,
      description: businessProfiles.description,
      phone: businessProfiles.phone,
      website: businessProfiles.website,
      address: businessProfiles.address,
      businessHours: businessProfiles.businessHours,
      categories: users.businessCategories,
      businessType: users.businessType,
      plan: users.stripeSubscriptionId
    })
    .from(users)
    .leftJoin(businessProfiles, eq(users.id, businessProfiles.userId))
    .where(eq(users.id, userId));

  return business;
}

export async function shouldShowBusinessInResults(searchQuery: string, userId: number): Promise<boolean> {
  const business = await getBusinessDisplayInfo(userId);
  if (!business || !business.categories) return false;

  const query = searchQuery.toLowerCase();
  const categories = business.categories;
  const businessType = business.businessType?.toLowerCase() || '';
  const description = business.description?.toLowerCase() || '';

  // Check if search matches business categories or type
  return categories.some(cat => 
    query.includes(cat.toLowerCase()) || 
    cat.toLowerCase().includes(query)
  ) || 
  query.includes(businessType) || 
  businessType.includes(query) ||
  description.includes(query);
}

export async function getBusinessesForSearchResults(searchQuery: string): Promise<Array<any>> {
  const businesses = await db
    .select({
      id: businessProfiles.id,
      userId: users.id,
      businessName: users.companyName,
      username: users.username,
      description: businessProfiles.description,
      phone: businessProfiles.phone,
      website: businessProfiles.website,
      address: businessProfiles.address,
      categories: users.businessCategories,
      businessType: users.businessType,
      plan: users.stripeSubscriptionId,
      featured: businessProfiles.featured
    })
    .from(businessProfiles)
    .leftJoin(users, eq(businessProfiles.userId, users.id))
    .where(eq(users.isBusiness, true));

  // Filter businesses relevant to search query
  const relevantBusinesses = [];
  
  for (const business of businesses) {
    if (await shouldShowBusinessInResults(searchQuery, business.userId)) {
      relevantBusinesses.push({
        ...business,
        displayName: business.businessName || business.username,
        contactButton: business.phone ? `Call ${business.phone}` : 'Contact Business',
        isPremium: business.plan !== null,
        isFeatured: business.featured || false
      });
    }
  }

  // Sort by plan priority: featured > premium > basic
  return relevantBusinesses.sort((a, b) => {
    if (a.isFeatured && !b.isFeatured) return -1;
    if (!a.isFeatured && b.isFeatured) return 1;
    if (a.isPremium && !b.isPremium) return -1;
    if (!a.isPremium && b.isPremium) return 1;
    return 0;
  });
}