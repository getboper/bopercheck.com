import { MailService } from '@sendgrid/mail';
import { db } from './db';
import { sql } from 'drizzle-orm';

// Set up SendGrid
const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface BusinessContact {
  name: string;
  email: string;
  phone?: string;
  website?: string;
  location?: string;
  category?: string;
}

// Extract potential business contacts from search results
export async function extractBusinessContacts(searchQuery: string, searchResults: any, location?: string): Promise<BusinessContact[]> {
  const contacts: BusinessContact[] = [];
  
  // Only extract authentic businesses from AI search results
  console.log('Extracting contacts from authentic search results only');
  
  // Also extract from existing localBusinesses in search results if available
  if (searchResults.localBusinesses && Array.isArray(searchResults.localBusinesses)) {
    console.log('Found existing localBusinesses:', searchResults.localBusinesses.length, 'businesses');
    for (const business of searchResults.localBusinesses) {
      console.log('Processing business:', business.name, 'location:', business.location);
      if (business.name && business.location) {
        // Only use authentic email addresses from search results
        const extractedEmail = business.contactInfo?.email || 
                              business.email || 
                              business.contact_email;
        
        // Only add businesses with authentic email addresses
        if (extractedEmail && !extractedEmail.includes('generated') && extractedEmail.includes('@')) {
          contacts.push({
            name: business.name,
            email: extractedEmail,
            phone: business.contactInfo?.phone || business.phone || undefined,
            website: business.contactInfo?.website || business.website || undefined,
            location: business.location,
            category: business.serviceType || searchQuery
          });
        }
        console.log('Added business contact:', business.name, 'with email:', extractedEmail);
      } else {
        console.log('Skipping business - missing name or location:', business);
      }
    }
  } else {
    console.log('No localBusinesses found in search results');
  }
  
  // Look for businesses mentioned in AI analysis or search results
  if (searchResults.businesses && Array.isArray(searchResults.businesses)) {
    for (const business of searchResults.businesses) {
      if (business.contact_email || business.email) {
        contacts.push({
          name: business.name || business.business_name || 'Business',
          email: business.contact_email || business.email,
          phone: business.phone || business.contact_phone,
          website: business.website || business.url,
          location: business.location || business.address,
          category: business.category || business.type
        });
      }
    }
  }
  
  // Extract from retailer/store information in search results
  if (searchResults.stores && Array.isArray(searchResults.stores)) {
    for (const store of searchResults.stores) {
      // Generate potential business email from store information
      if (store.name && store.name !== 'Amazon UK' && store.name !== 'Currys' && store.name !== 'Argos') {
        const storeName = store.name.toLowerCase().replace(/[^a-z0-9]/g, '');
        const potentialEmails = [
          `info@${storeName}.co.uk`,
          `sales@${storeName}.com`,
          `contact@${storeName}.co.uk`
        ];
        
        // For local businesses, add first potential email
        if (store.name.includes('Electronics') || store.name.includes('Store') || store.name.includes('Shop')) {
          contacts.push({
            name: store.name,
            email: potentialEmails[0],
            website: store.link || store.website,
            location: 'Local Business',
            category: 'Retail'
          });
        }
      }
    }
  }
  
  // Extract from retailer information
  if (searchResults.retailers && Array.isArray(searchResults.retailers)) {
    for (const retailer of searchResults.retailers) {
      if (retailer.contact_email && !contacts.find(c => c.email === retailer.contact_email)) {
        contacts.push({
          name: retailer.name || retailer.store_name || 'Retailer',
          email: retailer.contact_email,
          website: retailer.website || retailer.store_url,
          location: retailer.location,
          category: 'Retail'
        });
      }
    }
  }
  
  return contacts;
}

// Generate personalized business outreach email
function generateBusinessOutreachEmail(
  businessName: string, 
  searchQuery: string, 
  searchLocation?: string
): string {
  const locationText = searchLocation ? ` in the ${searchLocation} area` : '';
  
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Business Visibility Update from BoperCheck</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; line-height: 1.6; margin: 0; padding: 20px; background: #f8fafc; color: #334155; }
    .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07); }
    .logo-header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 25px 30px; text-align: center; }
    .logo { display: inline-flex; align-items: center; gap: 12px; margin-bottom: 15px; }
    .logo-icon { width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold; }
    .logo-text { font-size: 24px; font-weight: bold; letter-spacing: -0.5px; }
    .header-subtitle { font-size: 16px; opacity: 0.9; margin: 0; }
    .content { padding: 30px; }
    .good-news { background: #dcfce7; border-left: 4px solid #16a34a; padding: 20px; margin: 25px 0; border-radius: 6px; }
    .good-news h3 { margin: 0 0 10px 0; color: #166534; font-size: 18px; }
    .search-highlight { background: #f1f5f9; padding: 15px; border-radius: 6px; margin: 15px 0; border: 1px solid #e2e8f0; }
    .benefits-list { background: #f8fafc; padding: 20px; border-radius: 6px; margin: 20px 0; }
    .benefits-list ul { margin: 10px 0; padding-left: 20px; }
    .benefits-list li { margin: 8px 0; color: #475569; }
    .cta-box { background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border: 1px solid #0ea5e9; border-radius: 8px; padding: 25px; margin: 30px 0; text-align: center; }
    .cta-box h3 { color: #0c4a6e; margin: 0 0 15px 0; }
    .price-highlight { font-size: 20px; font-weight: bold; color: #0ea5e9; margin: 10px 0; }
    .cta-button { background: #0ea5e9; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 15px 0; font-weight: 600; transition: background 0.2s; }
    .cta-button:hover { background: #0284c7; }
    .footer { background: #f8fafc; padding: 25px; text-align: center; color: #64748b; font-size: 13px; border-top: 1px solid #e2e8f0; }
    .footer a { color: #0ea5e9; text-decoration: none; }
    .unsubscribe { margin-top: 15px; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo-header">
      <div class="logo">
        <div class="logo-icon">B</div>
        <div class="logo-text">BoperCheck</div>
      </div>
      <p class="header-subtitle">Great news about your business visibility, ${businessName}!</p>
    </div>
    
    <div class="content">

      <div class="good-news">
        <h3>A bit of good news...</h3>
        <p>Your business details have recently shown up in a customer search on BoperCheck.com:</p>
        <div class="search-highlight">
          <strong>"${searchQuery}"</strong>${locationText}
        </div>
      </div>

      <p>This means real customers are actively looking for products and services like yours, and your business is being discovered through our AI-powered search engine!</p>
      
      <p>We hope this keeps happening for you and that our platform continues to help connect you with potential customers. Keep up the excellent work!</p>

      <div class="benefits-list">
        <h3 style="margin: 0 0 15px 0; color: #334155;">What This Means for Your Business</h3>
        <ul>
          <li>Real customers are searching for products/services you offer</li>
          <li>Your business is naturally appearing in relevant searches</li>
          <li>BoperCheck is helping drive organic visibility for your business</li>
          <li>You're reaching customers actively looking to make purchases</li>
        </ul>
      </div>

      <div class="cta-box">
        <h3>Want to guarantee being seen every time?</h3>
        <p>While organic appearances are excellent, you can ensure your business appears in <strong>every relevant customer search</strong> with our business advertising packages.</p>
        
        <div class="price-highlight">Starting from just £35/month</div>
        
        <ul style="text-align: left; display: inline-block; margin: 15px 0;">
          <li>Appear in 50+ relevant customer searches monthly</li>
          <li>Get detailed performance analytics and insights</li>
          <li>Priority placement in search results</li>
          <li>Weekly business performance reports</li>
          <li>Direct customer contact information</li>
        </ul>
        
        <a href="https://bopercheck.com/business" class="cta-button">Learn More About Guaranteed Visibility</a>
        
        <p style="margin: 15px 0 0 0; font-size: 14px; color: #64748b;">Or simply reply to this email to speak with our business team</p>
      </div>

      <p style="margin: 30px 0 10px 0;">Best regards,<br>
      <strong>The BoperCheck Business Team</strong><br>
      <span style="color: #64748b; font-size: 14px;">Connecting UK customers with trusted local businesses</span></p>
    </div>

    <div class="footer">
      <p><strong>BoperCheck</strong> - AI-powered price comparison helping UK customers find the best deals</p>
      <p>This email was sent because your business appeared in a customer search on our platform</p>
      <div class="unsubscribe">
        <a href="mailto:support@bopercheck.com?subject=Unsubscribe Business Notifications">Unsubscribe from business notifications</a> | 
        <a href="https://bopercheck.com/terms">Terms</a> | 
        <a href="https://bopercheck.com/contact">Contact Us</a>
      </div>
    </div>
  </div>
</body>
</html>`;
}

// Send business outreach email
export async function sendBusinessOutreachEmail(
  contact: BusinessContact,
  searchQuery: string,
  searchLocation?: string
): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.error('SendGrid API key not configured');
    return false;
  }

  try {
    const emailHTML = generateBusinessOutreachEmail(contact.name, searchQuery, searchLocation);
    
    await mailService.send({
      to: contact.email,
      from: {
        email: 'support@bopercheck.com',
        name: 'BoperCheck Business Team'
      },
      replyTo: 'support@bopercheck.com',
      subject: `Your business appeared in a customer search on BoperCheck`,
      html: emailHTML,
      text: `Hello ${contact.name},

Great news! Your business details recently appeared in a customer search on BoperCheck.com for: "${searchQuery}"${searchLocation ? ` in the ${searchLocation} area` : ''}.

This means real customers are actively looking for products and services like yours, and your business is being discovered through our AI-powered search engine.

We hope this keeps happening for you and that our platform continues to help connect you with potential customers.

Want to guarantee being seen every time? While organic appearances are excellent, you can ensure your business appears in every relevant customer search with our business advertising packages starting from just £35/month.

Benefits include:
- Appear in 50+ relevant customer searches monthly
- Get detailed performance analytics and insights  
- Priority placement in search results
- Weekly business performance reports
- Direct customer contact information

Learn more: https://bopercheck.com/business
Or reply to this email to speak with our business team.

Best regards,
The BoperCheck Business Team
Connecting UK customers with trusted local businesses

---
This email was sent because your business appeared in a customer search on our platform.
Unsubscribe: support@bopercheck.com`,
      headers: {
        'List-Unsubscribe': '<mailto:support@bopercheck.com?subject=Unsubscribe>',
        'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click',
        'X-Entity-ID': 'bopercheck-business-outreach'
      }
    });

    // Log the outreach attempt
    await db.execute(sql`
      INSERT INTO business_outreach_log (
        business_name, email, search_query, search_location, sent_at, status
      ) VALUES (
        ${contact.name}, ${contact.email}, ${searchQuery}, 
        ${searchLocation || null}, NOW(), 'sent'
      )
    `);

    console.log(`Business outreach email sent to ${contact.email}`);
    return true;

  } catch (error) {
    console.error(`Failed to send business outreach email to ${contact.email}:`, error);
    
    // Log the failed attempt
    try {
      await db.execute(sql`
        INSERT INTO business_outreach_log (
          business_name, email, search_query, search_location, sent_at, status, error_message
        ) VALUES (
          ${contact.name}, ${contact.email}, ${searchQuery}, 
          ${searchLocation || null}, NOW(), 'failed', ${String(error)}
        )
      `);
    } catch (logError) {
      console.error('Failed to log outreach attempt:', logError);
    }
    
    return false;
  }
}

// Process business outreach for a search
export async function processBusinessOutreach(
  searchQuery: string, 
  searchResults: any, 
  searchLocation?: string
): Promise<{ sent: number; failed: number }> {
  console.log('Processing business outreach for:', searchQuery);
  console.log('Search results structure:', {
    hasLocalBusinesses: !!searchResults.localBusinesses,
    localBusinessCount: searchResults.localBusinesses?.length || 0,
    hasBusinesses: !!searchResults.businesses,
    hasStores: !!searchResults.stores,
    hasRetailers: !!searchResults.retailers
  });
  
  const contacts = await extractBusinessContacts(searchQuery, searchResults, searchLocation);
  console.log('Extracted contacts:', contacts);
  
  let sent = 0;
  let failed = 0;
  
  for (const contact of contacts) {
    // Check if we've already contacted this business for this search in the last 30 days
    const recentContact = await db.execute(sql`
      SELECT id FROM business_outreach_log 
      WHERE email = ${contact.email} 
      AND search_query = ${searchQuery}
      AND sent_at >= NOW() - INTERVAL '30 days'
      LIMIT 1
    `);
    
    if (recentContact.rows.length > 0) {
      console.log(`Skipping ${contact.email} - already contacted recently for this search`);
      continue;
    }
    
    const success = await sendBusinessOutreachEmail(contact, searchQuery, searchLocation);
    if (success) {
      sent++;
    } else {
      failed++;
    }
    
    // Add small delay between emails to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  return { sent, failed };
}

// Initialize business outreach logging table
export async function initializeBusinessOutreach() {
  try {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS business_outreach_log (
        id SERIAL PRIMARY KEY,
        business_name TEXT NOT NULL,
        email TEXT NOT NULL,
        search_query TEXT NOT NULL,
        search_location TEXT,
        sent_at TIMESTAMP DEFAULT NOW(),
        status TEXT NOT NULL, -- 'sent', 'failed', 'bounced'
        error_message TEXT,
        response_received BOOLEAN DEFAULT FALSE,
        converted_to_customer BOOLEAN DEFAULT FALSE
      )
    `);
    
    console.log('Business outreach system initialized');
  } catch (error) {
    console.error('Error initializing business outreach system:', error);
  }
}