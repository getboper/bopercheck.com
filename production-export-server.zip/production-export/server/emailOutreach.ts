import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
const apiKey = process.env.SENDGRID_API_KEY || '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';
mailService.setApiKey(apiKey);

interface ApologyEmailData {
  email: string;
  firstName?: string;
  lastVisit?: string;
  searchQuery?: string;
}

const SENDER_EMAIL = 'noreply@getboper.com'; // Using verified domain

export async function sendApologyEmail(userData: ApologyEmailData): Promise<boolean> {
  try {
    const emailContent = {
      to: userData.email,
      from: {
        email: 'support@bopercheck.com',
        name: 'BoperCheck Team'
      },
      subject: 'We\'re Sorry - BoperCheck is Back and Better Than Ever!',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>BoperCheck Apology</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }
            .button { display: inline-block; background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
            .highlight { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🙏 We Owe You an Apology</h1>
              <p>BoperCheck Team</p>
            </div>
            
            <div class="content">
              <p>Dear ${userData.firstName || 'Valued Customer'},</p>
              
              <p>We noticed you visited BoperCheck recently${userData.lastVisit ? ` on ${userData.lastVisit}` : ''} and may have experienced some technical difficulties with our cache system. We sincerely apologize for any frustration this caused.</p>
              
              <div class="highlight">
                <h3>🔧 What Happened?</h3>
                <p>We experienced temporary cache errors that prevented some searches from displaying results properly. This has now been completely resolved.</p>
              </div>
              
              <h3>✅ What We've Fixed:</h3>
              <ul>
                <li><strong>Enhanced voucher detection</strong> - Now properly extracts discount codes like "BIKESPRING20"</li>
                <li><strong>Improved search reliability</strong> - Cache issues completely resolved</li>
                <li><strong>Better error handling</strong> - Smoother experience for all users</li>
                <li><strong>Faster response times</strong> - Optimized performance across the platform</li>
              </ul>
              
              ${userData.searchQuery ? `
              <div class="highlight">
                <h3>🎯 Try Your Search Again</h3>
                <p>We noticed you were searching for "${userData.searchQuery}". The system is now working perfectly and you'll get much better results!</p>
              </div>
              ` : ''}
              
              <p>As an apology for the inconvenience, we're offering:</p>
              <ul>
                <li><strong>Priority support</strong> for any questions you have</li>
                <li><strong>Enhanced voucher access</strong> with improved discount code detection</li>
                <li><strong>Guaranteed reliable service</strong> going forward</li>
              </ul>
              
              <center>
                <a href="https://bopercheck.com" class="button">Try BoperCheck Again - It's Fixed!</a>
              </center>
              
              <p>Thank you for your patience and for giving us the opportunity to make this right. If you experience any issues at all, please don't hesitate to reach out to us directly.</p>
              
              <p>Best regards,<br>
              The BoperCheck Team</p>
              
              <p><em>P.S. We've also added new features like better price analysis and enhanced discount code detection that you'll love!</em></p>
            </div>
            
            <div class="footer">
              <p>BoperCheck - AI-Powered Price Comparison Platform</p>
              <p>This email was sent because you recently visited our website. If you no longer wish to receive emails, you can unsubscribe at any time.</p>
            </div>
          </div>
        </body>
        </html>
      `,
      text: `
Dear ${userData.firstName || 'Valued Customer'},

We noticed you visited BoperCheck recently and may have experienced some technical difficulties with our cache system. We sincerely apologize for any frustration this caused.

What We've Fixed:
- Enhanced voucher detection - Now properly extracts discount codes like "BIKESPRING20"
- Improved search reliability - Cache issues completely resolved  
- Better error handling - Smoother experience for all users
- Faster response times - Optimized performance across the platform

${userData.searchQuery ? `We noticed you were searching for "${userData.searchQuery}". The system is now working perfectly and you'll get much better results!` : ''}

As an apology for the inconvenience, we're offering:
- Priority support for any questions you have
- Enhanced voucher access with improved discount code detection
- Guaranteed reliable service going forward

Try BoperCheck again at: https://bopercheck.com

Thank you for your patience and for giving us the opportunity to make this right.

Best regards,
The BoperCheck Team
      `
    };

    await mailService.send(emailContent);
    console.log(`Apology email sent successfully to ${userData.email}`);
    return true;
  } catch (error) {
    console.error('Error sending apology email:', error);
    return false;
  }
}

export async function sendBulkApologyEmails(userList: ApologyEmailData[]): Promise<{
  sent: number;
  failed: number;
  errors: string[];
}> {
  const results = {
    sent: 0,
    failed: 0,
    errors: [] as string[]
  };

  for (const user of userList) {
    try {
      const success = await sendApologyEmail(user);
      if (success) {
        results.sent++;
      } else {
        results.failed++;
        results.errors.push(`Failed to send to ${user.email}`);
      }
      
      // Add delay between emails to respect rate limits
      await new Promise(resolve => setTimeout(resolve, 100));
    } catch (error) {
      results.failed++;
      results.errors.push(`Error sending to ${user.email}: ${error}`);
    }
  }

  return results;
}