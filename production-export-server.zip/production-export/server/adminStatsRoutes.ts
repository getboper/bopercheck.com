import type { Express } from "express";
import { db } from "./db";
import { priceChecks, users, businessProfiles, outreachLogs, weeklyReportRequests } from "@shared/schema";
import { sql, count, desc, eq, gte } from "drizzle-orm";

interface AdminStats {
  overview: {
    totalSearches: number;
    todaySearches: number;
    totalUsers: number;
    totalGuestUsers: number;
    activeUsers: number;
    totalRevenue: number;
    monthlyRevenue: number;
  };
  users: {
    total: number;
    guests: number;
    active: number;
    registered: number;
    recent: Array<{
      id: string;
      email?: string;
      createdAt: string;
      type: 'guest' | 'registered';
    }>;
  };
  searches: {
    total: number;
    today: number;
    thisWeek: number;
    thisMonth: number;
    recent: Array<{
      id: number;
      item: string;
      location?: string;
      createdAt: string;
      type: 'guest' | 'user';
    }>;
  };
  system: {
    status: 'healthy' | 'warning' | 'critical';
    uptime: number;
    lastCheck: string;
    errors: number;
  };
  businessOutreach: {
    totalSent: number;
    successful: number;
    pending: number;
    failed: number;
    recentEmails: Array<any>;
  };
  advertising: {
    totalPackages: number;
    activePackages: number;
    revenue: number;
    packages: Array<any>;
  };
  revenue: {
    total: number;
    monthly: number;
    weekly: number;
    transactions: Array<any>;
    breakdown: {
      subscriptions: number;
      oneTime: number;
      vouchers: number;
    };
    recentPayments: Array<any>;
    projected: {
      monthly: number;
      annual: number;
    };
  };
}

export function registerAdminStatsRoutes(app: Express): void {
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

      // Get live search statistics
      const [totalSearches, todaySearches, thisWeekSearches, thisMonthSearches] = await Promise.all([
        db.select({ count: count() }).from(priceChecks),
        db.select({ count: count() }).from(priceChecks).where(gte(priceChecks.createdAt, todayStart)),
        db.select({ count: count() }).from(priceChecks).where(gte(priceChecks.createdAt, weekStart)),
        db.select({ count: count() }).from(priceChecks).where(gte(priceChecks.createdAt, monthStart))
      ]);

      // Get live outreach statistics
      const outreachStats = await db.execute(sql`
        SELECT 
          COUNT(*) as total_sent,
          COUNT(CASE WHEN "deliveredAt" IS NOT NULL THEN 1 END) as delivered,
          COUNT(CASE WHEN "openedAt" IS NOT NULL THEN 1 END) as opened,
          COUNT(CASE WHEN "clickedAt" IS NOT NULL THEN 1 END) as clicked
        FROM outreach_logs
      `);

      // Get live business signup statistics
      const businessStats = await db.execute(sql`
        SELECT 
          COUNT(*) as total_signups,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active_signups,
          COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_signups
        FROM weekly_report_requests
      `);

      // Get recent searches
      const recentSearches = await db
        .select({
          id: priceChecks.id,
          item: priceChecks.item,
          location: priceChecks.location,
          createdAt: priceChecks.createdAt
        })
        .from(priceChecks)
        .orderBy(desc(priceChecks.createdAt))
        .limit(10);

      const stats: AdminStats = {
        overview: {
          totalSearches: totalSearches[0]?.count || 0,
          todaySearches: todaySearches[0]?.count || 0,
          totalUsers: 0,
          totalGuestUsers: 0,
          activeUsers: 0,
          totalRevenue: 0,
          monthlyRevenue: 0,
        },
        users: {
          total: 0,
          guests: 0,
          active: 0,
          registered: 0,
          recent: [],
        },
        searches: {
          total: totalSearches[0]?.count || 0,
          today: todaySearches[0]?.count || 0,
          thisWeek: thisWeekSearches[0]?.count || 0,
          thisMonth: thisMonthSearches[0]?.count || 0,
          recent: recentSearches.map(search => ({
            id: search.id,
            item: search.item,
            location: search.location || undefined,
            createdAt: search.createdAt.toISOString(),
            type: 'guest' as const,
          })),
        },
        system: {
          status: 'healthy',
          uptime: 99.9,
          lastCheck: new Date().toISOString(),
          errors: 0,
        },
        businessOutreach: {
          totalSent: Number(outreachStats.rows[0]?.total_sent) || 0,
          successful: Number(outreachStats.rows[0]?.delivered) || 0,
          pending: (Number(outreachStats.rows[0]?.total_sent) || 0) - (Number(outreachStats.rows[0]?.delivered) || 0),
          failed: 0,
          recentEmails: [],
        },
        advertising: {
          totalPackages: 0,
          activePackages: 0,
          revenue: 0,
          packages: [],
        },
        revenue: {
          total: 0,
          monthly: 0,
          weekly: 0,
          transactions: [],
          breakdown: {
            subscriptions: 0,
            oneTime: 0,
            vouchers: 0,
          },
          recentPayments: [],
          projected: {
            monthly: 0,
            annual: 0,
          },
        },
      };

      console.log(`[ADMIN STATS] Live data: ${stats.overview.totalSearches} searches, ${stats.businessOutreach.totalSent} outreach emails`);
      res.json(stats);

    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ error: "Failed to fetch admin stats" });
    }
  });
}