import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

interface FastBusiness {
  name: string;
  location: string;
  serviceType: string;
  contactInfo: {
    phone?: string;
    website?: string;
  };
  notes: string;
  authentic: true;
}

export async function findFastLocalBusinesses(
  searchQuery: string, 
  location: string
): Promise<FastBusiness[]> {
  
  if (!location || !searchQuery) {
    return [];
  }

  try {
    // Optimized prompt for faster response
    const prompt = `List 2-3 real businesses in ${location}, UK for "${searchQuery}".

Return JSON only: {"businesses": [{"name": "Business Name", "serviceType": "Service", "location": "${location}", "notes": "Brief description"}]}`;

    console.log(`Fast search: ${searchQuery} in ${location}`);
    
    const message = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 400,
      messages: [{ role: "user", content: prompt }],
      system: "Return only real businesses. Be concise."
    });

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    
    let cleanedResponse = responseText;
    if (responseText.includes('```json')) {
      cleanedResponse = responseText.split('```json')[1].split('```')[0].trim();
    } else if (responseText.includes('```')) {
      cleanedResponse = responseText.split('```')[1].trim();
    }

    const response = JSON.parse(cleanedResponse);
    
    if (!response?.businesses || !Array.isArray(response.businesses)) {
      return [];
    }

    const businesses = response.businesses
      .filter((business: any) => business.name && business.name.length > 2)
      .slice(0, 3) // Limit to 3 businesses
      .map((business: any): FastBusiness => ({
        name: business.name,
        location: business.location || `${location} area`,
        serviceType: business.serviceType || 'Local Service',
        contactInfo: {
          phone: business.contactInfo?.phone,
          website: business.contactInfo?.website
        },
        notes: business.notes || "Contact for pricing and availability",
        authentic: true
      }));

    console.log(`Fast search found ${businesses.length} businesses`);
    return businesses;

  } catch (error) {
    console.error('Fast business search error:', error);
    return [];
  }
}