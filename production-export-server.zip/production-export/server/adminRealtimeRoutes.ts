import type { Express } from "express";
import { db } from "./db";
import { 
  priceChecks, users, guestUsers, adminAlerts, systemMetrics, 
  advertisingClicks, advertiserPackages, weeklyReportRequests, 
  adminPaymentTransactions, systemErrors, paymentTransactions
} from "../shared/schema";
import { influencers } from "../shared/influencer-schema";
import { eq, desc, count, sum, and, gte, sql } from "drizzle-orm";

// Admin authentication middleware
const requireAdminAuth = (req: any, res: any, next: any) => {
  const adminUser = (req.session as any)?.adminUser;
  if (!adminUser || adminUser.email !== "njpards1@gmail.com") {
    return res.status(401).json({ success: false, message: 'Admin access required' });
  }
  next();
};

// Get business outreach statistics for admin dashboard
async function getBusinessOutreachStats() {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Get outreach statistics from the last 30 days
    const stats = await db.execute(sql`
      SELECT 
        COUNT(*) as total_sent,
        COUNT(CASE WHEN "emailStatus" IN ('sent', 'delivered') THEN 1 END) as successful_sends,
        COUNT(CASE WHEN "emailStatus" IN ('failed', 'bounced') THEN 1 END) as failed_sends,
        COUNT(CASE WHEN responded = true THEN 1 END) as responses,
        COUNT(CASE WHEN converted = true THEN 1 END) as conversions
      FROM outreach_logs
      WHERE "dateContacted" >= ${thirtyDaysAgo.toISOString()}
    `);

    // Get recent outreach attempts
    const recentOutreach = await db.execute(sql`
      SELECT "businessName", "businessEmail", "searchQuery", "dateContacted", "emailStatus", "outreachType"
      FROM outreach_logs 
      ORDER BY "dateContacted" DESC 
      LIMIT 10
    `);

    const statsRow = stats.rows[0] || {};
    
    return {
      totalSent: Number(statsRow.total_sent) || 0,
      successfulSends: Number(statsRow.successful_sends) || 0,
      failedSends: Number(statsRow.failed_sends) || 0,
      responses: Number(statsRow.responses) || 0,
      conversions: Number(statsRow.conversions) || 0,
      recentOutreach: recentOutreach.rows || []
    };
  } catch (error) {
    console.error('Error fetching business outreach stats:', error);
    return {
      totalSent: 0,
      successfulSends: 0,
      failedSends: 0,
      responses: 0,
      conversions: 0,
      recentOutreach: []
    };
  }
}

// Get influencer statistics for admin dashboard
async function getInfluencerStats() {
  try {
    const totalInfluencers = await db.select({ count: count() }).from(influencers);
    const contactedInfluencers = await db.select({ count: count() })
      .from(influencers)
      .where(sql`${influencers.partnershipStatus} != 'not_contacted'`);
    const partneredInfluencers = await db.select({ count: count() })
      .from(influencers)
      .where(eq(influencers.partnershipStatus, 'partnered'));
    const pendingInfluencers = await db.select({ count: count() })
      .from(influencers)
      .where(sql`${influencers.partnershipStatus} IN ('contacted', 'responded')`);
    const totalFollowers = await db.select({ 
      total: sum(influencers.followerCount) 
    }).from(influencers);

    return {
      total: totalInfluencers[0]?.count || 0,
      contacted: contactedInfluencers[0]?.count || 0,
      partnered: partneredInfluencers[0]?.count || 0,
      pending: pendingInfluencers[0]?.count || 0,
      totalFollowers: Number(totalFollowers[0]?.total || 0)
    };
  } catch (error) {
    console.error('Error fetching influencer stats:', error);
    return {
      total: 0,
      contacted: 0,
      partnered: 0,
      pending: 0,
      totalFollowers: 0
    };
  }
}

// Real-time alert creation function
export async function createAdminAlert(type: string, title: string, message: string, details?: any, severity = "medium", userId?: number) {
  try {
    await db.insert(adminAlerts).values({
      type,
      title,
      message,
      details: details ? JSON.stringify(details) : null,
      severity,
      userId,
      isRead: false,
    });
  } catch (error) {
    console.error('Failed to create admin alert:', error);
  }
}

// Log system metrics
export async function logSystemMetric(metricType: string, value: number, metadata?: any) {
  try {
    const today = new Date().toISOString().split('T')[0];
    await db.insert(systemMetrics).values({
      metricType,
      value: value.toString(),
      metadata: metadata ? JSON.stringify(metadata) : null,
      date: today,
    });
  } catch (error) {
    console.error('Failed to log system metric:', error);
  }
}

// Log system errors
export async function logSystemError(errorType: string, errorMessage: string, details?: any, severity = "medium", userId?: number, guestId?: string) {
  try {
    console.log('Logging system error:', { errorType, errorMessage, severity });
    
    await db.insert(systemErrors).values({
      errorType: errorType,
      errorMessage: errorMessage,
      stackTrace: details?.stack || null,
      url: details?.url || null,
      userId: userId || null,
      guestId: guestId || null,
      severity: severity,
      isResolved: false,
    });

    console.log('System error logged successfully');

    // Create admin alert for critical errors
    if (severity === "critical" || severity === "high") {
      await createAdminAlert(
        "error",
        `${severity.toUpperCase()} Error: ${errorType}`,
        errorMessage,
        details,
        severity,
        userId
      );
    }
  } catch (error) {
    console.error('Failed to log system error:', error);
    console.error('Error details:', error);
  }
}

// Get auto-healing system status
async function getAutoHealingStatus() {
  try {
    const { intelligentAutoHealing } = await import('./intelligentAutoHealing');
    const stats = await intelligentAutoHealing.getAutoHealingStats();
    const history = intelligentAutoHealing.getFixHistory();
    
    return {
      isActive: true,
      stats,
      recentFixes: history.slice(-10),
      lastScanTime: new Date().toISOString()
    };
  } catch (error) {
    return {
      isActive: false,
      error: 'Auto-healing system not available',
      stats: { totalErrors: 0, resolvedErrors: 0, autoFixesApplied: 0 }
    };
  }
}

export function registerAdminRealtimeRoutes(app: Express): void {
  
  // Admin login endpoint
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      // Simple admin authentication - in production, use proper password hashing
      if (email === "njpards1@gmail.com" && password === "admin123") {
        (req.session as any).adminUser = { email };
        res.json({ success: true, message: "Admin login successful" });
      } else {
        res.status(401).json({ success: false, message: "Invalid admin credentials" });
      }
    } catch (error) {
      console.error('Admin login error:', error);
      res.status(500).json({ success: false, message: "Login failed" });
    }
  });

  // Admin logout endpoint
  app.post("/api/admin/logout", (req, res) => {
    delete (req.session as any).adminUser;
    res.json({ success: true, message: "Logged out successfully" });
  });
  
  // Real-time dashboard data endpoint
  app.get("/api/admin/realtime-data", requireAdminAuth, async (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const thisWeek = new Date();
      thisWeek.setDate(thisWeek.getDate() - 7);
      
      // Get total search statistics
      const totalSearches = await db.select({ count: count() }).from(priceChecks);
      const todaySearches = await db.select({ count: count() })
        .from(priceChecks)
        .where(gte(priceChecks.createdAt, new Date(today)));
      
      // Get unique locations from searches
      const searchLocations = await db.select({
        location: priceChecks.location,
        count: count()
      })
      .from(priceChecks)
      .where(sql`${priceChecks.location} IS NOT NULL`)
      .groupBy(priceChecks.location)
      .orderBy(desc(count()));

      // Get most searched products
      const topProducts = await db.select({
        item: priceChecks.item,
        count: count()
      })
      .from(priceChecks)
      .groupBy(priceChecks.item)
      .orderBy(desc(count()))
      .limit(10);

      // Get recent searches with proper handling
      const recentSearches = await db.select()
        .from(priceChecks)
        .orderBy(desc(priceChecks.createdAt))
        .limit(20);

      // Get unique user statistics
      const totalUsers = await db.select({ count: count() }).from(users);
      const totalGuestUsers = await db.select({ count: count() }).from(guestUsers);
      const activeUsers = await db.select({ count: count() })
        .from(users)
        .where(gte(users.lastLogin, thisWeek));

      // Get weekly report requests
      const weeklyReports = await db.select()
        .from(weeklyReportRequests)
        .orderBy(desc(weeklyReportRequests.requestedAt))
        .limit(50);

      // Get advertising data
      const advertisingData = await db.select()
        .from(advertisingClicks)
        .orderBy(desc(advertisingClicks.clickedAt))
        .limit(100);

      const advertiserPackagesData = await db.select().from(advertiserPackages);

      // Get revenue breakdown from both payment tables
      const adminRevenue = await db.select({ 
        total: sum(adminPaymentTransactions.amount) 
      }).from(adminPaymentTransactions)
      .where(eq(adminPaymentTransactions.status, 'completed'));

      const stripeRevenue = await db.select({ 
        total: sum(sql`${paymentTransactions.amount} / 100`) 
      }).from(paymentTransactions)
      .where(eq(paymentTransactions.status, 'succeeded'));

      const monthlyAdminRevenue = await db.select({
        total: sum(adminPaymentTransactions.amount)
      }).from(adminPaymentTransactions)
      .where(and(
        eq(adminPaymentTransactions.status, 'completed'),
        gte(adminPaymentTransactions.createdAt, new Date(new Date().getFullYear(), new Date().getMonth(), 1))
      ));

      const monthlyStripeRevenue = await db.select({
        total: sum(sql`${paymentTransactions.amount} / 100`)
      }).from(paymentTransactions)
      .where(and(
        eq(paymentTransactions.status, 'succeeded'),
        gte(paymentTransactions.createdAt, new Date(new Date().getFullYear(), new Date().getMonth(), 1))
      ));

      // Get recent payments from both tables
      const recentAdminPayments = await db.select()
        .from(adminPaymentTransactions)
        .orderBy(desc(adminPaymentTransactions.createdAt))
        .limit(10);

      const recentStripePayments = await db.select()
        .from(paymentTransactions)
        .orderBy(desc(paymentTransactions.createdAt))
        .limit(10);

      // Get system errors and alerts
      const recentErrors = await db.select()
        .from(systemErrors)
        .orderBy(desc(systemErrors.createdAt))
        .limit(50);

      const unreadAlerts = await db.select()
        .from(adminAlerts)
        .where(eq(adminAlerts.isRead, false))
        .orderBy(desc(adminAlerts.createdAt));

      // Get system metrics
      const recentMetrics = await db.select()
        .from(systemMetrics)
        .orderBy(desc(systemMetrics.recordedAt))
        .limit(100);

      const responseData = {
        overview: {
          totalSearches: totalSearches[0]?.count || 0,
          todaySearches: todaySearches[0]?.count || 0,
          totalUsers: totalUsers[0]?.count || 0,
          totalGuestUsers: totalGuestUsers[0]?.count || 0,
          activeUsers: activeUsers[0]?.count || 0,
          totalRevenue: (Number(adminRevenue[0]?.total || 0) + Number(stripeRevenue[0]?.total || 0)),
          monthlyRevenue: (Number(monthlyAdminRevenue[0]?.total || 0) + Number(monthlyStripeRevenue[0]?.total || 0)),
        },
        users: {
          total: totalUsers[0]?.count || 0,
          guests: totalGuestUsers[0]?.count || 0,
          active: activeUsers[0]?.count || 0,
          registered: totalUsers[0]?.count || 0,
          recent: recentSearches.map(search => ({
            id: search.id,
            type: search.userId ? 'registered' : 'guest',
            location: search.location,
            item: search.item,
            timestamp: search.createdAt
          })).slice(0, 10)
        },
        socialMedia: {
          tiktok: {
            pixelActive: !!process.env.VITE_TIKTOK_PIXEL_ID,
            conversions: 0,
            todayConversions: 0,
            clickThrough: 0,
          },
          influencers: {
            totalInfluencers: 0,
            activePartnerships: 0,
            totalReach: 0,
            monthlyEngagement: 0,
            conversionRate: 0
          }
        },
        business: {
          totalBusinesses: 0,
          activeSubscriptions: 0,
          totalInfluencers: 0,
          activePartnerships: 0,
          totalReach: 0
        },
        email: {
          totalEmailsSent: 0,
          businessOutreachEmails: 0,
          tiktokInfluencerEmails: 0,
          clickThroughRate: 0,
          responseRate: 0
        },
        analytics: {
          searchTrends: [],
          userGrowth: [],
          conversionRates: []
        },
        revenue: {
          total: (Number(adminRevenue[0]?.total || 0) + Number(stripeRevenue[0]?.total || 0)),
          monthly: (Number(monthlyAdminRevenue[0]?.total || 0) + Number(monthlyStripeRevenue[0]?.total || 0)),
          weekly: 0,
          transactions: [...recentAdminPayments, ...recentStripePayments].slice(0, 10),
          breakdown: {
            subscriptions: 0,
            oneTime: 0,
            vouchers: 0
          },
          recentPayments: [...recentAdminPayments, ...recentStripePayments].slice(0, 10),
          projected: {
            monthly: (Number(monthlyAdminRevenue[0]?.total || 0) + Number(monthlyStripeRevenue[0]?.total || 0)) * 1.1,
            annual: (Number(monthlyAdminRevenue[0]?.total || 0) + Number(monthlyStripeRevenue[0]?.total || 0)) * 12
          }
        },
        businessOutreach: await getBusinessOutreachStats(),
        advertising: {
          totalCampaigns: 0,
          activeCampaigns: 0,
          totalSpend: 0,
          monthlySpend: 0,
          clickThroughRate: 0,
          conversionRate: 0,
          campaignPackages: []
        },
        searches: {
          locations: searchLocations.map(loc => ({
            location: loc.location || 'Unknown',
            count: loc.count
          })),
          topProducts: topProducts.map(product => ({
            item: product.item,
            count: product.count
          })),
          recent: recentSearches.map(search => ({
            id: search.id,
            item: search.item,
            location: search.location,
            timestamp: search.createdAt
          })).slice(0, 10)
        },
        alerts: {
          unread: unreadAlerts,
          criticalCount: unreadAlerts.filter(alert => alert.severity === 'critical').length,
          highCount: unreadAlerts.filter(alert => alert.severity === 'high').length,
          recentErrors: recentErrors.slice(0, 10)
        },
        notifications: {
          unread: unreadAlerts,
          criticalCount: unreadAlerts.filter(alert => alert.severity === 'critical').length,
          highCount: unreadAlerts.filter(alert => alert.severity === 'high').length,
          recentErrors: recentErrors.slice(0, 10)
        },
        system: {
          metrics: recentMetrics,
          status: 'operational',
          lastUpdated: new Date().toISOString(),
          uptime: process.uptime()
        },
        weeklyReports: []
      };

      res.json(responseData);
    } catch (error) {
      console.error('Error fetching realtime admin data:', error);
      res.status(500).json({ success: false, message: 'Failed to fetch admin data' });
    }
  });

  // Mark alert as read
  app.post("/api/admin/alerts/:id/read", requireAdminAuth, async (req, res) => {
    try {
      const alertId = parseInt(req.params.id);
      await db.update(adminAlerts)
        .set({ isRead: true })
        .where(eq(adminAlerts.id, alertId));
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ success: false, message: 'Failed to mark alert as read' });
    }
  });

  // Resolve system error
  app.post("/api/admin/errors/:id/resolve", requireAdminAuth, async (req, res) => {
    try {
      const errorId = parseInt(req.params.id);
      await db.update(systemErrors)
        .set({ isResolved: true, resolvedAt: new Date() })
        .where(eq(systemErrors.id, errorId));
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ success: false, message: 'Failed to resolve error' });
    }
  });

  // Create manual alert
  app.post("/api/admin/alerts", requireAdminAuth, async (req, res) => {
    try {
      const { type, title, message, severity } = req.body;
      await createAdminAlert(type, title, message, null, severity);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ success: false, message: 'Failed to create alert' });
    }
  });

  // Get detailed analytics
  app.get("/api/admin/analytics/detailed", requireAdminAuth, async (req, res) => {
    try {
      const { timeframe = '7d' } = req.query;
      let dateFilter = new Date();
      
      switch (timeframe) {
        case '24h':
          dateFilter.setHours(dateFilter.getHours() - 24);
          break;
        case '7d':
          dateFilter.setDate(dateFilter.getDate() - 7);
          break;
        case '30d':
          dateFilter.setDate(dateFilter.getDate() - 30);
          break;
        case '90d':
          dateFilter.setDate(dateFilter.getDate() - 90);
          break;
      }

      // Search analytics
      const searchAnalytics = await db.select({
        date: sql`DATE(${priceChecks.createdAt})`,
        count: count(),
      })
      .from(priceChecks)
      .where(gte(priceChecks.createdAt, dateFilter))
      .groupBy(sql`DATE(${priceChecks.createdAt})`)
      .orderBy(sql`DATE(${priceChecks.createdAt})`);

      // User registration analytics
      const userAnalytics = await db.select({
        date: sql`DATE(${users.createdAt})`,
        count: count(),
      })
      .from(users)
      .where(gte(users.createdAt, dateFilter))
      .groupBy(sql`DATE(${users.createdAt})`)
      .orderBy(sql`DATE(${users.createdAt})`);

      // Revenue analytics from both payment tables
      const adminRevenueAnalytics = await db.select({
        date: sql`DATE(${adminPaymentTransactions.createdAt})`,
        amount: sum(adminPaymentTransactions.amount),
        count: count(),
      })
      .from(adminPaymentTransactions)
      .where(and(
        gte(adminPaymentTransactions.createdAt, dateFilter),
        eq(adminPaymentTransactions.status, 'completed')
      ))
      .groupBy(sql`DATE(${adminPaymentTransactions.createdAt})`)
      .orderBy(sql`DATE(${adminPaymentTransactions.createdAt})`);

      const stripeRevenueAnalytics = await db.select({
        date: sql`DATE(${paymentTransactions.createdAt})`,
        amount: sum(sql`${paymentTransactions.amount} / 100`),
        count: count(),
      })
      .from(paymentTransactions)
      .where(and(
        gte(paymentTransactions.createdAt, dateFilter),
        eq(paymentTransactions.status, 'succeeded')
      ))
      .groupBy(sql`DATE(${paymentTransactions.createdAt})`)
      .orderBy(sql`DATE(${paymentTransactions.createdAt})`);

      res.json({
        timeframe,
        searches: searchAnalytics,
        users: userAnalytics,
        revenue: {
          admin: adminRevenueAnalytics,
          stripe: stripeRevenueAnalytics,
          combined: [...adminRevenueAnalytics, ...stripeRevenueAnalytics]
        },
      });
    } catch (error) {
      console.error('Error fetching detailed analytics:', error);
      res.status(500).json({ success: false, message: 'Failed to fetch analytics' });
    }
  });
}