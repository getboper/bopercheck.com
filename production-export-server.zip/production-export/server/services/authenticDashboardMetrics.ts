import { db } from '../db';
import { sql } from 'drizzle-orm';

export class AuthenticDashboardMetrics {
  
  // Get real business outreach metrics from database
  static async getBusinessOutreachMetrics() {
    try {
      // Get outreach counts by status
      const outreachStats = await db.execute(sql`
        SELECT 
          COUNT(*) as total_emails,
          COUNT(CASE WHEN delivery_status = 'delivered' THEN 1 END) as delivered,
          COUNT(CASE WHEN opened_at IS NOT NULL THEN 1 END) as opened,
          COUNT(CASE WHEN clicked_at IS NOT NULL THEN 1 END) as clicked,
          COUNT(CASE WHEN delivery_status = 'bounced' THEN 1 END) as bounced,
          COUNT(CASE WHEN created_at >= CURRENT_DATE THEN 1 END) as today_emails,
          COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '7 days' THEN 1 END) as week_emails
        FROM outreach_logs
      `);

      const stats = outreachStats.rows[0];
      
      return {
        totalEmailsSent: parseInt(stats.total_emails) || 0,
        deliveryRate: stats.total_emails > 0 ? 
          Math.round((parseInt(stats.delivered) / parseInt(stats.total_emails)) * 100) : 0,
        openRate: stats.delivered > 0 ? 
          Math.round((parseInt(stats.opened) / parseInt(stats.delivered)) * 100) : 0,
        clickRate: stats.delivered > 0 ? 
          Math.round((parseInt(stats.clicked) / parseInt(stats.delivered)) * 100) : 0,
        todayEmails: parseInt(stats.today_emails) || 0,
        weekEmails: parseInt(stats.week_emails) || 0,
        bounceRate: stats.total_emails > 0 ? 
          Math.round((parseInt(stats.bounced) / parseInt(stats.total_emails)) * 100) : 0
      };
    } catch (error) {
      console.error('Error fetching outreach metrics:', error);
      return {
        totalEmailsSent: 0,
        deliveryRate: 0,
        openRate: 0,
        clickRate: 0,
        todayEmails: 0,
        weekEmails: 0,
        bounceRate: 0
      };
    }
  }

  // Get real weekly report metrics from database
  static async getWeeklyReportsMetrics() {
    try {
      const reportStats = await db.execute(sql`
        SELECT 
          COUNT(*) as total_requests,
          COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
          COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
          COUNT(CASE WHEN requested_at >= CURRENT_DATE THEN 1 END) as today_requests,
          COUNT(CASE WHEN requested_at >= CURRENT_DATE - INTERVAL '7 days' THEN 1 END) as week_requests
        FROM weekly_report_requests
      `);

      const stats = reportStats.rows[0];
      
      return {
        totalRequests: parseInt(stats.total_requests) || 0,
        completedReports: parseInt(stats.completed) || 0,
        pendingReports: parseInt(stats.pending) || 0,
        todayRequests: parseInt(stats.today_requests) || 0,
        weekRequests: parseInt(stats.week_requests) || 0,
        completionRate: stats.total_requests > 0 ? 
          Math.round((parseInt(stats.completed) / parseInt(stats.total_requests)) * 100) : 0
      };
    } catch (error) {
      console.error('Error fetching weekly report metrics:', error);
      return {
        totalRequests: 0,
        completedReports: 0,
        pendingReports: 0,
        todayRequests: 0,
        weekRequests: 0,
        completionRate: 0
      };
    }
  }

  // Get real advertiser metrics from database
  static async getAdvertiserMetrics() {
    try {
      const advertiserStats = await db.execute(sql`
        SELECT 
          COUNT(*) as total_advertisers,
          COUNT(CASE WHEN is_active = true THEN 1 END) as active_advertisers,
          COALESCE(SUM(CASE WHEN is_active = true THEN monthly_price ELSE 0 END), 0) as monthly_revenue,
          COUNT(CASE WHEN start_date >= CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as new_this_month
        FROM advertiser_packages
      `);

      const stats = advertiserStats.rows[0];
      
      return {
        totalAdvertisers: parseInt(stats.total_advertisers) || 0,
        activeAdvertisers: parseInt(stats.active_advertisers) || 0,
        monthlyRevenue: parseFloat(stats.monthly_revenue) || 0,
        newThisMonth: parseInt(stats.new_this_month) || 0,
        activeRate: stats.total_advertisers > 0 ? 
          Math.round((parseInt(stats.active_advertisers) / parseInt(stats.total_advertisers)) * 100) : 0
      };
    } catch (error) {
      console.error('Error fetching advertiser metrics:', error);
      return {
        totalAdvertisers: 0,
        activeAdvertisers: 0,
        monthlyRevenue: 0,
        newThisMonth: 0,
        activeRate: 0
      };
    }
  }

  // Get real platform metrics from database
  static async getPlatformMetrics() {
    try {
      const platformStats = await db.execute(sql`
        SELECT 
          (SELECT COUNT(*) FROM price_checks) as total_searches,
          (SELECT COUNT(*) FROM guest_users) as total_users,
          (SELECT COUNT(*) FROM price_checks WHERE created_at >= CURRENT_DATE) as today_searches,
          (SELECT COUNT(*) FROM guest_users WHERE created_at >= CURRENT_DATE) as today_users,
          (SELECT COUNT(*) FROM price_checks WHERE created_at >= CURRENT_DATE - INTERVAL '7 days') as week_searches,
          (SELECT COUNT(*) FROM guest_users WHERE created_at >= CURRENT_DATE - INTERVAL '7 days') as week_users,
          (SELECT COUNT(*) FROM voucher_wallet) as total_vouchers,
          (SELECT COUNT(*) FROM system_errors WHERE created_at >= CURRENT_DATE - INTERVAL '24 hours') as recent_errors
      `);

      const stats = platformStats.rows[0];
      
      return {
        totalSearches: parseInt(stats.total_searches) || 0,
        totalUsers: parseInt(stats.total_users) || 0,
        todaySearches: parseInt(stats.today_searches) || 0,
        todayUsers: parseInt(stats.today_users) || 0,
        weekSearches: parseInt(stats.week_searches) || 0,
        weekUsers: parseInt(stats.week_users) || 0,
        totalVouchers: parseInt(stats.total_vouchers) || 0,
        recentErrors: parseInt(stats.recent_errors) || 0,
        systemHealth: parseInt(stats.recent_errors) === 0 ? 'healthy' : 'issues'
      };
    } catch (error) {
      console.error('Error fetching platform metrics:', error);
      return {
        totalSearches: 0,
        totalUsers: 0,
        todaySearches: 0,
        todayUsers: 0,
        weekSearches: 0,
        weekUsers: 0,
        totalVouchers: 0,
        recentErrors: 0,
        systemHealth: 'unknown'
      };
    }
  }

  // Get visitor analytics from database
  static async getVisitorAnalytics() {
    try {
      const visitorStats = await db.execute(sql`
        SELECT 
          COUNT(*) as total_visits,
          COUNT(CASE WHEN visit_date >= CURRENT_DATE THEN 1 END) as today_visits,
          COUNT(CASE WHEN visit_date >= CURRENT_DATE - INTERVAL '7 days' THEN 1 END) as week_visits,
          COUNT(DISTINCT ip_address) as unique_visitors
        FROM visitor_analytics
        WHERE visit_date >= CURRENT_DATE - INTERVAL '30 days'
      `);

      const stats = visitorStats.rows[0];
      
      return {
        totalVisits: parseInt(stats.total_visits) || 0,
        todayVisits: parseInt(stats.today_visits) || 0,
        weekVisits: parseInt(stats.week_visits) || 0,
        uniqueVisitors: parseInt(stats.unique_visitors) || 0
      };
    } catch (error) {
      console.error('Error fetching visitor analytics:', error);
      return {
        totalVisits: 0,
        todayVisits: 0,
        weekVisits: 0,
        uniqueVisitors: 0
      };
    }
  }
}