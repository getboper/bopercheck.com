import sgMail from '@sendgrid/mail';
import { storage } from '../storage.implementation';

// Configure SendGrid
if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

export async function sendBusinessNotification(
  email: string, 
  subject: string, 
  content: string,
  notificationType: string = 'admin_test'
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    if (!process.env.SENDGRID_API_KEY) {
      throw new Error('SendGrid API key not configured');
    }

    const msg = {
      to: email,
      from: 'alerts@bopercheck.com',
      subject: subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb;">BoperCheck Business Notification</h2>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            ${content}
          </div>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
            <p style="color: #6b7280; font-size: 14px;">
              This email was sent from BoperCheck Platform<br>
              Business Intelligence & Price Comparison System<br>
              Timestamp: ${new Date().toISOString()}
            </p>
          </div>
        </div>
      `
    };

    const result = await sgMail.send(msg);
    const messageId = result[0].headers['x-message-id'] as string;

    // Log successful notification in database
    await storage.logBusinessNotification({
      businessEmail: email,
      notificationType: notificationType,
      status: 'sent',
      response: `Email sent successfully - Message ID: ${messageId}`
    });

    return {
      success: true,
      messageId: messageId
    };

  } catch (error: any) {
    console.error('Email sending failed:', error);

    // Log failed notification in database
    try {
      await storage.logBusinessNotification({
        businessEmail: email,
        notificationType: notificationType,
        status: 'failed',
        response: `Email failed: ${error.message}`
      });
    } catch (logError) {
      console.error('Failed to log notification error:', logError);
    }

    return {
      success: false,
      error: error.message
    };
  }
}