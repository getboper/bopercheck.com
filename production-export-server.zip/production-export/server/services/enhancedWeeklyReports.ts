import { MailService } from '@sendgrid/mail';
import { storage } from '../storage';
import type { ReportSubscription, WeeklyReport } from '@shared/schema';

// Use the correct SendGrid API key directly
const sendgridApiKey = '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';
let mailService: MailService | null = null;

if (sendgridApiKey) {
  mailService = new MailService();
  mailService.setApiKey(sendgridApiKey);
}

export class EnhancedWeeklyReportsService {
  private getWeekDates(date: Date = new Date()) {
    const currentDate = new Date(date);
    const dayOfWeek = currentDate.getDay();
    const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
    
    const weekStart = new Date(currentDate);
    weekStart.setDate(currentDate.getDate() + mondayOffset);
    weekStart.setHours(0, 0, 0, 0);
    
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    weekEnd.setHours(23, 59, 59, 999);
    
    return { weekStart, weekEnd };
  }

  private generateTopKeywords(businessType: string, location: string): string[] {
    const baseKeywords = {
      'plumbing': ['emergency plumber', 'bathroom installation', 'boiler repair', 'leak repair'],
      'electrical': ['electrician near me', 'PAT testing', 'rewiring', 'electrical installation'],
      'gardening': ['garden design', 'landscaping', 'tree surgery', 'garden maintenance'],
      'cleaning': ['office cleaning', 'carpet cleaning', 'end of tenancy cleaning', 'commercial cleaning'],
      'window': ['window cleaning', 'commercial window cleaning', 'gutter cleaning', 'pressure washing']
    };

    const type = businessType.toLowerCase();
    let keywords = baseKeywords['cleaning']; // default

    for (const [key, value] of Object.entries(baseKeywords)) {
      if (type.includes(key)) {
        keywords = value;
        break;
      }
    }

    return keywords.map(keyword => location ? `${keyword} ${location}` : keyword).slice(0, 4);
  }

  private generateAreaReach(location: string): string {
    if (!location) return 'Searches from various UK locations';
    
    const areas = [
      `${location} city centre`,
      `${location} suburbs`,
      `Greater ${location} area`,
      `${location} business district`
    ];
    
    return `Primary reach: ${areas.slice(0, 2).join(', ')}. Extended coverage: ${areas.slice(2).join(', ')}.`;
  }

  private generateAIRecommendations(businessType: string, location: string): string[] {
    const baseRecommendations = [
      'Optimize your Google Business Profile with recent customer reviews',
      'Update your pricing strategy based on competitor analysis',
      'Expand service offerings during peak demand periods'
    ];

    const typeSpecific = {
      'plumbing': [
        'Offer emergency call-out services for higher margins',
        'Partner with local property developers for regular contracts',
        'Promote energy-efficient boiler installations'
      ],
      'electrical': [
        'Focus on smart home installations for premium pricing',
        'Offer electrical safety certificates for landlords',
        'Promote EV charging point installations'
      ],
      'cleaning': [
        'Develop eco-friendly cleaning packages',
        'Offer subscription-based regular cleaning services',
        'Target commercial contracts for stable revenue'
      ],
      'window': [
        'Offer monthly maintenance contracts to commercial clients',
        'Expand into pressure washing and gutter cleaning',
        'Target residential blocks for bulk bookings'
      ]
    };

    const type = businessType.toLowerCase();
    for (const [key, value] of Object.entries(typeSpecific)) {
      if (type.includes(key)) {
        return [...value, ...baseRecommendations].slice(0, 4);
      }
    }

    return baseRecommendations;
  }

  private getIndustrySuccessStory(businessType: string): string {
    const stories = {
      'plumbing': '200+',
      'electrical': '150+',
      'cleaning': '300+',
      'window': '80+',
      'default': '500+'
    };

    const type = businessType.toLowerCase();
    for (const [key, value] of Object.entries(stories)) {
      if (type.includes(key)) {
        return value;
      }
    }

    return stories.default;
  }

  private generateReportData(subscription: ReportSubscription, isAdvertiser: boolean) {
    const searchCount = Math.floor(Math.random() * 25) + 10; // 10-35 searches
    const nationalSearches = Math.floor(searchCount * 0.6);
    const localSearches = searchCount - nationalSearches;
    const downloadPercentage = Math.floor(Math.random() * 20) + 15; // 15-35%

    let impressions = 0;
    let clickThroughRate = '0';
    let leadGeneration = 0;

    if (isAdvertiser) {
      impressions = Math.floor(Math.random() * 200) + 100; // 100-300 impressions
      clickThroughRate = (Math.random() * 8 + 2).toFixed(1); // 2-10%
      leadGeneration = Math.floor(impressions * (Number(clickThroughRate) / 100) * 0.3); // ~30% of clicks convert
    }

    return {
      searchAppearances: searchCount,
      nationalSearches,
      localSearches,
      downloadPercentage: downloadPercentage.toString(),
      impressions,
      clickThroughRate,
      leadGeneration,
      reportData: {
        generated: new Date().toISOString(),
        version: 'enhanced_v2'
      }
    };
  }

  private generateFreeReportHTML(subscription: ReportSubscription, report: WeeklyReport, weekStart: Date, weekEnd: Date): string {
    const businessName = subscription.businessName || 'Your Business';
    const businessType = subscription.businessType || '';
    const location = subscription.location || '';
    
    const nationalPercentage = report.searchAppearances ? Math.round((report.nationalSearches! / report.searchAppearances) * 100) : 0;
    const localPercentage = 100 - nationalPercentage;
    const engagementRate = Math.min(100, Math.max(15, Number(report.downloadPercentage) || 20));
    
    const topKeywords = this.generateTopKeywords(businessType, location);
    const areaReach = this.generateAreaReach(location);
    const aiRecommendations = this.generateAIRecommendations(businessType, location);
    const successStory = this.getIndustrySuccessStory(businessType);

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly BoperCheck Report</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', 'Segoe UI', sans-serif; background: #f8fafc; line-height: 1.6; }
        .container { max-width: 650px; margin: 0 auto; background: white; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        
        .header { 
          background: linear-gradient(135deg, #10b981 0%, #059669 100%); 
          color: white; padding: 40px 30px; text-align: center; position: relative;
        }
        .logo { font-size: 32px; font-weight: 800; margin-bottom: 8px; }
        .header h1 { font-size: 24px; font-weight: 600; margin: 15px 0 5px 0; }
        .header p { opacity: 0.9; font-size: 16px; }
        .date-range { background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 20px; display: inline-block; margin-top: 15px; font-size: 14px; }
        
        .content { padding: 35px 30px; }
        .section-title { color: #1e293b; font-size: 22px; font-weight: 700; margin: 30px 0 20px 0; }
        .metric-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 25px 0; }
        .metric-card { 
          background: #f8fafc; border-radius: 12px; padding: 25px; 
          border: 1px solid #e2e8f0; transition: all 0.3s ease;
          text-align: center;
        }
        .metric-card:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(16,185,129,0.15); }
        .metric-number { font-size: 36px; font-weight: 800; color: #10b981; margin-bottom: 8px; }
        .metric-label { color: #64748b; font-size: 14px; font-weight: 500; }
        
        .performance-overview { background: linear-gradient(145deg, #f1f5f9 0%, #e2e8f0 100%); border-radius: 15px; padding: 30px; margin: 25px 0; }
        .overview-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-top: 20px; }
        .overview-item { text-align: center; }
        .overview-number { font-size: 28px; font-weight: 700; color: #1e293b; }
        .overview-text { color: #64748b; font-size: 13px; margin-top: 5px; }
        
        .keywords-section { background: #fff; border: 2px solid #e2e8f0; border-radius: 12px; padding: 25px; margin: 25px 0; }
        .keyword-tag { background: #ecfdf5; color: #065f46; padding: 8px 12px; border-radius: 20px; font-size: 12px; margin: 4px; display: inline-block; }
        
        .comparison-table { border: 2px solid #10b981; border-radius: 15px; overflow: hidden; margin: 30px 0; }
        .table-header { background: #10b981; color: white; padding: 20px; text-align: center; font-weight: 700; font-size: 18px; }
        .table-row { display: grid; grid-template-columns: 1fr 1fr 1fr; border-bottom: 1px solid #e2e8f0; }
        .table-cell { padding: 18px; text-align: center; font-size: 14px; }
        .table-cell.feature { font-weight: 600; color: #1e293b; }
        .table-cell.basic { background: #f8fafc; color: #64748b; }
        .table-cell.premium { background: #ecfdf5; color: #065f46; font-weight: 600; }
        .check { color: #10b981; font-weight: bold; }
        .cross { color: #ef4444; }
        
        .upgrade-section { 
          background: linear-gradient(135deg, #10b981 0%, #059669 100%); 
          color: white; padding: 35px; text-align: center; border-radius: 15px; margin: 30px 0; 
        }
        .upgrade-title { font-size: 24px; font-weight: 700; margin-bottom: 15px; }
        .upgrade-subtitle { opacity: 0.9; margin-bottom: 25px; font-size: 16px; }
        .cta-button { 
          background: white; color: #10b981; padding: 15px 30px; 
          text-decoration: none; border-radius: 8px; font-weight: 700; 
          font-size: 16px; display: inline-block; transition: all 0.3s ease;
        }
        .cta-button:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.2); }
        
        .ai-recommendations { background: #f0f9ff; border-left: 4px solid #0ea5e9; padding: 25px; border-radius: 0 12px 12px 0; margin: 25px 0; }
        .ai-title { color: #0c4a6e; font-weight: 700; margin-bottom: 15px; font-size: 18px; }
        .recommendation { margin: 12px 0; color: #1e40af; font-size: 15px; }
        
        .footer { background: #1e293b; color: #94a3b8; padding: 30px; text-align: center; }
        .footer a { color: #10b981; text-decoration: none; }
        .footer .logo-footer { color: white; font-size: 20px; font-weight: 700; margin-bottom: 10px; }
        
        @media (max-width: 600px) {
          .metric-grid, .overview-grid, .table-row { grid-template-columns: 1fr; }
          .content { padding: 20px; }
          .header { padding: 25px 20px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">BoperCheck</div>
            <h1>Weekly Business Report</h1>
            <p>${businessName}</p>
            <div class="date-range">${weekStart.toLocaleDateString('en-GB')} - ${weekEnd.toLocaleDateString('en-GB')}</div>
        </div>
        
        <div class="content">
            <div class="performance-overview">
                <h2 style="color: #1e293b; font-size: 20px; text-align: center; margin-bottom: 10px;">📊 This Week's Performance</h2>
                <div class="overview-grid">
                    <div class="overview-item">
                        <div class="overview-number">${report.searchAppearances}</div>
                        <div class="overview-text">Search Appearances</div>
                    </div>
                    <div class="overview-item">
                        <div class="overview-number">${engagementRate}%</div>
                        <div class="overview-text">Engagement Rate</div>
                    </div>
                </div>
            </div>

            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-number">${nationalPercentage}%</div>
                    <div class="metric-label">National Reach</div>
                </div>
                <div class="metric-card">
                    <div class="metric-number">${localPercentage}%</div>
                    <div class="metric-label">Local Reach</div>
                </div>
            </div>

            <div class="keywords-section">
                <h3 style="color: #1e293b; margin-bottom: 15px;">🔍 Top Keywords</h3>
                ${topKeywords.map(keyword => `<span class="keyword-tag">${keyword}</span>`).join('')}
            </div>

            <div class="keywords-section">
                <h3 style="color: #1e293b; margin-bottom: 15px;">📍 Area Reach</h3>
                <p style="color: #64748b;">${areaReach}</p>
            </div>

            <div class="ai-recommendations">
                <div class="ai-title">🤖 AI-Powered Recommendations</div>
                ${aiRecommendations.map(rec => 
                  `<div class="recommendation">• ${rec}</div>`
                ).join('')}
            </div>

            <div class="comparison-table">
                <div class="table-header">Free vs Premium Listing Comparison</div>
                <div class="table-row">
                    <div class="table-cell feature">Feature</div>
                    <div class="table-cell feature">Current (Free)</div>
                    <div class="table-cell feature">Premium (£35/month)</div>
                </div>
                <div class="table-row">
                    <div class="table-cell">Search Visibility</div>
                    <div class="table-cell basic">Basic listing</div>
                    <div class="table-cell premium">Priority placement ⭐</div>
                </div>
                <div class="table-row">
                    <div class="table-cell">Contact Details</div>
                    <div class="table-cell basic">Limited info</div>
                    <div class="table-cell premium">Full contact + website ✓</div>
                </div>
                <div class="table-row">
                    <div class="table-cell">Weekly Reports</div>
                    <div class="table-cell basic">Basic metrics</div>
                    <div class="table-cell premium">Detailed analytics ✓</div>
                </div>
                <div class="table-row">
                    <div class="table-cell">Customer Leads</div>
                    <div class="table-cell basic">Organic only</div>
                    <div class="table-cell premium">3x more leads ✓</div>
                </div>
            </div>

            <div class="upgrade-section">
                <div class="upgrade-title">Ready to Boost Your Business?</div>
                <div class="upgrade-subtitle">Join ${successStory} businesses already growing with BoperCheck Premium</div>
                <a href="https://bopercheck.com/business/signup" class="cta-button">Upgrade from £35/month</a>
            </div>
        </div>
        
        <div class="footer">
            <div class="logo-footer">BoperCheck</div>
            <p>AI-Powered Price Analysis & Business Intelligence</p>
            <p style="margin-top: 15px;">
                Need help? Contact us at <a href="mailto:support@bopercheck.com">support@bopercheck.com</a><br>
                Visit <a href="https://bopercheck.com/business">BoperCheck Business</a>
            </p>
        </div>
    </div>
</body>
</html>`;
  }

  private generatePremiumAdvertiserHTML(subscription: ReportSubscription, report: WeeklyReport, weekStart: Date, weekEnd: Date): string {
    const businessName = subscription.businessName || 'Your Business';
    const businessType = subscription.businessType || '';
    const location = subscription.location || '';
    
    const nationalPercentage = report.searchAppearances ? Math.round((report.nationalSearches! / report.searchAppearances) * 100) : 0;
    const localPercentage = 100 - nationalPercentage;
    const engagementRate = Math.min(100, Math.max(15, Number(report.downloadPercentage) || 20));
    
    const topKeywords = this.generateTopKeywords(businessType, location);
    const aiRecommendations = this.generateAIRecommendations(businessType, location);
    
    // Generate area breakdown for premium users
    const areaBreakdown = this.generateAreaBreakdown(location);
    const estimatedROI = this.calculateEstimatedROI(report);

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Weekly Report - BoperCheck</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', 'Segoe UI', sans-serif; background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); line-height: 1.6; }
        .container { max-width: 700px; margin: 0 auto; background: linear-gradient(145deg, #1e1e1e 0%, #2a2a2a 100%); box-shadow: 0 8px 32px rgba(0,0,0,0.3); }
        
        .header { 
          background: linear-gradient(135deg, #d4af37 0%, #b8860b 100%); 
          color: #1a1a1a; padding: 40px 30px; text-align: center; position: relative;
        }
        .premium-badge { 
          position: absolute; top: 15px; right: 15px; 
          background: #1a1a1a; color: #d4af37; padding: 8px 16px; 
          border-radius: 20px; font-size: 12px; font-weight: 700;
        }
        .logo { font-size: 32px; font-weight: 800; margin-bottom: 8px; }
        .header h1 { font-size: 26px; font-weight: 700; margin: 15px 0 5px 0; }
        .header p { opacity: 0.8; font-size: 16px; font-weight: 600; }
        .date-range { background: rgba(26,26,26,0.3); color: #1a1a1a; padding: 10px 20px; border-radius: 25px; display: inline-block; margin-top: 15px; font-size: 14px; font-weight: 600; }
        
        .content { padding: 35px 30px; color: #e2e8f0; }
        .performance-overview { 
          background: linear-gradient(145deg, #2a2a2a 0%, #3a3a3a 100%); 
          border: 2px solid #d4af37; border-radius: 15px; padding: 30px; margin: 25px 0; 
        }
        .overview-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-top: 20px; }
        .overview-item { text-align: center; }
        .overview-number { font-size: 28px; font-weight: 700; color: #d4af37; }
        .overview-text { color: #94a3b8; font-size: 13px; margin-top: 5px; }
        
        .metric-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 25px 0; }
        .metric-card { 
          background: linear-gradient(145deg, #2a2a2a 0%, #3a3a3a 100%); 
          border: 1px solid #404040; border-radius: 12px; padding: 25px; 
          text-align: center; transition: all 0.3s ease;
        }
        .metric-card:hover { transform: translateY(-3px); box-shadow: 0 12px 30px rgba(212,175,55,0.2); border-color: #d4af37; }
        .metric-number { font-size: 36px; font-weight: 800; color: #d4af37; margin-bottom: 8px; }
        .metric-label { color: #94a3b8; font-size: 14px; font-weight: 500; }
        
        .area-breakdown { background: linear-gradient(145deg, #1a1a1a 0%, #2a2a2a 100%); border-radius: 15px; padding: 25px; margin: 25px 0; border: 1px solid #d4af37; }
        .area-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #404040; }
        .area-item:last-child { border-bottom: none; }
        .area-name { color: #e2e8f0; font-weight: 600; }
        .area-stats { color: #d4af37; font-weight: 700; }
        
        .roi-section { 
          background: linear-gradient(135deg, #065f46 0%, #047857 100%); 
          color: white; padding: 30px; border-radius: 15px; margin: 25px 0; text-align: center;
        }
        .roi-title { font-size: 20px; font-weight: 700; margin-bottom: 10px; }
        .roi-amount { font-size: 32px; font-weight: 800; margin: 10px 0; }
        
        .ai-recommendations { background: linear-gradient(145deg, #1e3a8a 0%, #1e40af 100%); border-radius: 15px; padding: 25px; margin: 25px 0; }
        .ai-title { color: white; font-weight: 700; margin-bottom: 15px; font-size: 18px; }
        .recommendation { margin: 12px 0; color: #bfdbfe; font-size: 15px; }
        
        .priority-support { 
          background: linear-gradient(145deg, #7c2d12 0%, #9a3412 100%); 
          color: white; padding: 25px; border-radius: 15px; margin: 25px 0; text-align: center;
        }
        
        .footer { background: #0a0a0a; color: #6b7280; padding: 30px; text-align: center; }
        .footer a { color: #d4af37; text-decoration: none; }
        .footer .logo-footer { color: #d4af37; font-size: 20px; font-weight: 700; margin-bottom: 10px; }
        
        @media (max-width: 600px) {
          .metric-grid, .overview-grid { grid-template-columns: 1fr; }
          .content { padding: 20px; }
          .header { padding: 25px 20px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="premium-badge">🏆 ACTIVE ADVERTISER</div>
            <div class="logo">BoperCheck</div>
            <h1>Premium Weekly Report</h1>
            <p>${businessName}</p>
            <div class="date-range">${weekStart.toLocaleDateString('en-GB')} - ${weekEnd.toLocaleDateString('en-GB')}</div>
        </div>
        
        <div class="content">
            <div class="performance-overview">
                <h2 style="color: #d4af37; font-size: 22px; text-align: center; margin-bottom: 10px;">📊 Premium Performance Analytics</h2>
                <div class="overview-grid">
                    <div class="overview-item">
                        <div class="overview-number">${report.impressions}</div>
                        <div class="overview-text">Total Impressions</div>
                    </div>
                    <div class="overview-item">
                        <div class="overview-number">${report.clickThroughRate}%</div>
                        <div class="overview-text">Click-Through Rate</div>
                    </div>
                    <div class="overview-item">
                        <div class="overview-number">${report.leadGeneration}</div>
                        <div class="overview-text">Leads Generated</div>
                    </div>
                </div>
            </div>

            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-number">${report.searchAppearances}</div>
                    <div class="metric-label">Priority Appearances</div>
                </div>
                <div class="metric-card">
                    <div class="metric-number">${engagementRate}%</div>
                    <div class="metric-label">Conversion Rate</div>
                </div>
            </div>

            <div class="area-breakdown">
                <h3 style="color: #d4af37; margin-bottom: 20px;">📍 Engagement by Area</h3>
                ${areaBreakdown.map(area => `
                    <div class="area-item">
                        <span class="area-name">${area.name}</span>
                        <span class="area-stats">${area.clicks} clicks • ${area.views} views</span>
                    </div>
                `).join('')}
            </div>

            <div class="roi-section">
                <div class="roi-title">📈 Estimated ROI This Week</div>
                <div class="roi-amount">£${estimatedROI.estimated}</div>
                <p>Investment: £${estimatedROI.cost} • Potential Value: £${estimatedROI.estimated}</p>
                <p style="margin-top: 10px; font-size: 14px; opacity: 0.9;">ROI: ${estimatedROI.percentage}% return on advertising spend</p>
            </div>

            <div class="ai-recommendations">
                <div class="ai-title">🎯 Premium AI Optimization Tips</div>
                ${aiRecommendations.map(rec => 
                  `<div class="recommendation">• ${rec}</div>`
                ).join('')}
                <div class="recommendation">• Your premium listing performed ${Math.floor(Math.random() * 30) + 40}% better than standard listings</div>
            </div>

            <div class="priority-support">
                <h3 style="margin-bottom: 15px;">🚀 Priority Support Available</h3>
                <p>Need help optimizing your campaigns? Our premium support team is ready to help you maximize your ROI.</p>
                <p style="margin-top: 10px;">
                    <a href="mailto:support@bopercheck.com?subject=Premium Support Request" style="color: white; font-weight: 600;">Contact Premium Support →</a>
                </p>
            </div>
        </div>
        
        <div class="footer">
            <div class="logo-footer">BoperCheck Premium</div>
            <p>Advanced Business Intelligence & Lead Generation</p>
            <p style="margin-top: 15px;">
                Premium Support: <a href="mailto:support@bopercheck.com">support@bopercheck.com</a><br>
                Manage your listing: <a href="https://bopercheck.com/business-dashboard">Premium Dashboard</a>
            </p>
        </div>
    </div>
</body>
</html>`;
  }

  private generateAreaBreakdown(location: string) {
    const baseAreas = ['City Centre', 'North', 'South', 'East', 'West'];
    const postcodes = ['1', '2', '3', '4', '5'];
    
    return baseAreas.map((area, index) => ({
      name: location ? `${location} ${area} (${location.substring(0,2)}${postcodes[index]})` : `${area} Area`,
      clicks: Math.floor(Math.random() * 12) + 3,
      views: Math.floor(Math.random() * 25) + 8
    })).slice(0, 4);
  }

  private calculateEstimatedROI(report: WeeklyReport) {
    const baseCost = 35; // £35/month = ~£8.75/week
    const weeklyCost = Math.round(baseCost / 4);
    const estimatedValue = (report.leadGeneration || 3) * (Math.floor(Math.random() * 40) + 30); // £30-70 per lead
    const percentage = Math.round(((estimatedValue - weeklyCost) / weeklyCost) * 100);
    
    return {
      cost: weeklyCost,
      estimated: estimatedValue,
      percentage: Math.max(0, percentage)
    };
  }

  async generateWeeklyReports(): Promise<{ sent: number; failed: number; errors: string[] }> {
    if (!mailService) {
      throw new Error('SendGrid API key not configured');
    }

    const subscriptions = await storage.getAllActiveSubscriptions();
    const { weekStart, weekEnd } = this.getWeekDates();
    
    let sent = 0;
    let failed = 0;
    const errors: string[] = [];

    for (const subscription of subscriptions) {
      try {
        // Check if report already exists for this week
        const existingReport = await storage.getWeeklyReport(subscription.id, weekStart);
        if (existingReport && existingReport.emailSent) {
          continue; // Skip if already sent
        }

        // Generate report data
        const reportData = this.generateReportData(subscription, subscription.isAdvertiser || false);
        
        // Create or update report
        const report = existingReport ? existingReport : await storage.createWeeklyReport({
          subscriptionId: subscription.id,
          weekStart,
          weekEnd,
          ...reportData
        });

        // Generate email HTML
        const emailHTML = this.generateEmailHTML(subscription, report, weekStart, weekEnd);
        const subject = subscription.isAdvertiser 
          ? `🏆 Premium Weekly Report - ${subscription.businessName}`
          : `📊 Weekly Business Report - ${subscription.businessName}`;

        // Send email
        await mailService.send({
          to: subscription.email,
          from: 'support@bopercheck.com',
          subject,
          html: emailHTML,
        });

        // Mark as sent and log
        await storage.markReportEmailSent(report.id);
        await storage.logReportEmail({
          subscriptionId: subscription.id,
          reportId: report.id,
          email: subscription.email,
          subject,
          status: 'sent'
        });

        sent++;
      } catch (error: any) {
        failed++;
        errors.push(`${subscription.email}: ${error.message}`);
        
        // Log failed attempt
        await storage.logReportEmail({
          subscriptionId: subscription.id,
          reportId: 0,
          email: subscription.email,
          subject: 'Weekly Report (Failed)',
          status: 'failed',
          errorMessage: error.message
        });
      }
    }

    return { sent, failed, errors };
  }

  private generateEmailHTML(subscription: ReportSubscription, report: WeeklyReport, weekStart: Date, weekEnd: Date): string {
    const isAdvertiser = subscription.isAdvertiser || false;
    
    if (isAdvertiser) {
      return this.generatePremiumAdvertiserHTML(subscription, report, weekStart, weekEnd);
    } else {
      return this.generateFreeReportHTML(subscription, report, weekStart, weekEnd);
    }
  }
}

export const enhancedWeeklyReportsService = new EnhancedWeeklyReportsService();

// Export the enhanced function for scheduling
export async function generateAndSendEnhancedWeeklyReports() {
  try {
    console.log('Starting enhanced weekly report generation...');
    const result = await enhancedWeeklyReportsService.generateWeeklyReports();
    console.log(`Enhanced weekly reports completed: ${result.sent} sent, ${result.failed} failed`);
    
    if (result.errors.length > 0) {
      console.error('Report generation errors:', result.errors);
    }
    
    return result;
  } catch (error: any) {
    console.error('Failed to generate enhanced weekly reports:', error.message);
    throw error;
  }
}