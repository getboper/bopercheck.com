import { db } from "../db";
import { aiTrainingFeedback, priceChecks } from "../../shared/schema";
import { desc, gte, sql } from "drizzle-orm";

interface AnalysisQuality {
  discountCodesFound: number;
  secondHandOptionsFound: number;
  localBusinessesFound: number;
  priceAccuracy: number;
  completeness: number;
}

interface OptimizationMetrics {
  avgDiscountCodesPerSearch: number;
  avgSecondHandOptions: number;
  avgLocalBusinesses: number;
  userSatisfactionScore: number;
  analysisDepth: number;
}

export class AIOptimizationService {
  
  // Analyze recent performance and identify improvement areas
  async analyzePerformance(): Promise<OptimizationMetrics> {
    try {
      // Get recent price checks from last 7 days
      const recentChecks = await db
        .select()
        .from(priceChecks)
        .where(gte(priceChecks.createdAt, new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)))
        .orderBy(desc(priceChecks.createdAt))
        .limit(100);

      // Calculate performance metrics
      let totalDiscountCodes = 0;
      let totalSecondHand = 0;
      let totalLocalBusinesses = 0;
      let totalCompleteness = 0;

      for (const check of recentChecks) {
        const result = check.result as any;
        if (result) {
          totalDiscountCodes += result.discounts?.length || 0;
          totalSecondHand += result.secondHand?.length || 0;
          totalLocalBusinesses += result.localBusinesses?.length || 0;
          
          // Calculate completeness score
          let completeness = 0;
          if (result.stores?.length > 0) completeness += 25;
          if (result.discounts?.length > 0) completeness += 25;
          if (result.secondHand?.length > 0) completeness += 25;
          if (result.analysis && result.analysis.length > 50) completeness += 25;
          totalCompleteness += completeness;
        }
      }

      const count = recentChecks.length || 1;
      
      return {
        avgDiscountCodesPerSearch: totalDiscountCodes / count,
        avgSecondHandOptions: totalSecondHand / count,
        avgLocalBusinesses: totalLocalBusinesses / count,
        userSatisfactionScore: totalCompleteness / count,
        analysisDepth: totalCompleteness / count
      };
    } catch (error) {
      console.error('Error analyzing AI performance:', error);
      return {
        avgDiscountCodesPerSearch: 0,
        avgSecondHandOptions: 0,
        avgLocalBusinesses: 0,
        userSatisfactionScore: 0,
        analysisDepth: 0
      };
    }
  }

  // Generate enhanced prompt based on performance analysis
  async generateOptimizedPrompt(basePrompt: string, item: string, location?: string): Promise<string> {
    const metrics = await this.analyzePerformance();
    
    let optimizations = [];
    
    // Add specific optimizations based on current performance gaps
    if (metrics.avgDiscountCodesPerSearch < 2) {
      optimizations.push(`
CRITICAL: Focus heavily on finding ACTIVE discount codes. Search for:
- Current promotional codes for ${item}
- Seasonal sales and clearance codes
- First-time customer discounts
- Newsletter signup bonuses
- Social media exclusive codes
- Student/NHS/Military discounts
- Cashback portal offers (TopCashback, Quidco, Airpoints)
REQUIREMENT: Find at least 3-4 working discount codes or explain why none exist.`);
    }

    if (metrics.avgSecondHandOptions < 1.5) {
      optimizations.push(`
CRITICAL: Thoroughly search second-hand markets. Include:
- eBay Buy It Now current listings with specific prices
- Facebook Marketplace typical pricing for your area
- CEX/CeX current stock and prices
- Amazon Warehouse deals
- Manufacturer refurbished options
- Local second-hand electronics/furniture stores
REQUIREMENT: Find at least 2-3 second-hand options with real pricing.`);
    }

    if (metrics.avgLocalBusinesses < 1 && location) {
      optimizations.push(`
CRITICAL: Find competitive local businesses in ${location}. Include:
- Independent retailers offering better deals than chains
- Local installers with competitive rates
- Trade suppliers open to public
- Local service providers with special offers
- Community marketplace deals
REQUIREMENT: Find at least 2 local businesses with contact details and pricing.`);
    }

    if (metrics.analysisDepth < 75) {
      optimizations.push(`
CRITICAL: Provide comprehensive analysis including:
- Detailed price comparison with pros/cons
- Best value recommendations for different budgets
- Installation timeline and what's included
- Warranty comparisons
- Hidden costs to watch for
- Best time to buy recommendations
REQUIREMENT: Analysis must be detailed and actionable.`);
    }

    // Combine base prompt with optimizations
    const optimizedPrompt = `${basePrompt}

PERFORMANCE OPTIMIZATION REQUIREMENTS:
${optimizations.join('\n')}

QUALITY STANDARDS:
- Every search MUST find discount codes or explain their absence
- Every search MUST include second-hand pricing from multiple sources
- Every search MUST provide actionable recommendations
- Analysis MUST be comprehensive and detailed
- All prices MUST be current and realistic for UK market

CONTINUOUS IMPROVEMENT: This analysis will be evaluated for completeness and accuracy. Strive to exceed previous performance standards.`;

    return optimizedPrompt;
  }

  // Track analysis quality for future optimization
  async trackAnalysisQuality(searchId: number, result: any): Promise<void> {
    try {
      const quality: AnalysisQuality = {
        discountCodesFound: result.discounts?.length || 0,
        secondHandOptionsFound: result.secondHand?.length || 0,
        localBusinessesFound: result.localBusinesses?.length || 0,
        priceAccuracy: this.calculatePriceAccuracy(result),
        completeness: this.calculateCompleteness(result)
      };

      // Store quality metrics for learning
      await db.insert(aiTrainingFeedback).values({
        searchId,
        feedbackType: 'quality_metrics',
        feedbackData: quality,
        createdAt: new Date()
      });

    } catch (error) {
      console.error('Error tracking analysis quality:', error);
    }
  }

  private calculatePriceAccuracy(result: any): number {
    // Score based on realistic UK pricing
    let score = 0;
    if (result.stores?.length > 0) score += 30;
    if (result.priceRange?.min > 0 && result.priceRange?.max > result.priceRange.min) score += 30;
    if (result.averagePrice > 0) score += 20;
    if (result.secondHand?.length > 0) score += 20;
    return score;
  }

  private calculateCompleteness(result: any): number {
    let score = 0;
    if (result.stores?.length >= 3) score += 20;
    if (result.discounts?.length >= 2) score += 20;
    if (result.secondHand?.length >= 2) score += 20;
    if (result.localBusinesses?.length >= 1) score += 15;
    if (result.analysis && result.analysis.length > 100) score += 15;
    if (result.installation) score += 10;
    return score;
  }

  // Get performance insights for admin dashboard
  async getPerformanceInsights(): Promise<any> {
    const metrics = await this.analyzePerformance();
    
    return {
      currentMetrics: metrics,
      recommendations: this.generateRecommendations(metrics),
      trends: await this.calculateTrends()
    };
  }

  private generateRecommendations(metrics: OptimizationMetrics): string[] {
    const recommendations = [];
    
    if (metrics.avgDiscountCodesPerSearch < 2) {
      recommendations.push("Enhance discount code detection - current average is below target");
    }
    
    if (metrics.avgSecondHandOptions < 1.5) {
      recommendations.push("Improve second-hand market analysis - expand platform coverage");
    }
    
    if (metrics.avgLocalBusinesses < 1) {
      recommendations.push("Strengthen local business discovery - enhance location-based search");
    }
    
    if (metrics.userSatisfactionScore < 80) {
      recommendations.push("Increase analysis depth and accuracy - user satisfaction below target");
    }
    
    return recommendations;
  }

  private async calculateTrends(): Promise<any> {
    // Calculate 7-day vs 30-day performance trends
    try {
      const recent = await this.getMetricsForPeriod(7);
      const historical = await this.getMetricsForPeriod(30);
      
      return {
        discountCodeTrend: this.calculateTrend(recent.avgDiscountCodesPerSearch, historical.avgDiscountCodesPerSearch),
        secondHandTrend: this.calculateTrend(recent.avgSecondHandOptions, historical.avgSecondHandOptions),
        satisfactionTrend: this.calculateTrend(recent.userSatisfactionScore, historical.userSatisfactionScore)
      };
    } catch (error) {
      return { error: 'Unable to calculate trends' };
    }
  }

  private async getMetricsForPeriod(days: number): Promise<OptimizationMetrics> {
    const checks = await db
      .select()
      .from(priceChecks)
      .where(gte(priceChecks.createdAt, new Date(Date.now() - days * 24 * 60 * 60 * 1000)))
      .limit(50);

    // Calculate metrics for this period
    let totalDiscountCodes = 0;
    let totalSecondHand = 0;
    let totalSatisfaction = 0;

    for (const check of checks) {
      const result = check.result as any;
      if (result) {
        totalDiscountCodes += result.discounts?.length || 0;
        totalSecondHand += result.secondHand?.length || 0;
        
        let satisfaction = 0;
        if (result.stores?.length > 0) satisfaction += 25;
        if (result.discounts?.length > 0) satisfaction += 25;
        if (result.secondHand?.length > 0) satisfaction += 25;
        if (result.analysis?.length > 50) satisfaction += 25;
        totalSatisfaction += satisfaction;
      }
    }

    const count = checks.length || 1;
    return {
      avgDiscountCodesPerSearch: totalDiscountCodes / count,
      avgSecondHandOptions: totalSecondHand / count,
      avgLocalBusinesses: 0,
      userSatisfactionScore: totalSatisfaction / count,
      analysisDepth: totalSatisfaction / count
    };
  }

  private calculateTrend(recent: number, historical: number): string {
    if (recent > historical * 1.1) return 'improving';
    if (recent < historical * 0.9) return 'declining';
    return 'stable';
  }
}

export const aiOptimization = new AIOptimizationService();