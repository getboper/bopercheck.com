import type { Express } from "express";
import { db } from "./db";
// Using direct SQL for business contacts to avoid schema conflicts
import { sql, desc, eq, and } from "drizzle-orm";
import { MailService } from '@sendgrid/mail';

// Set up SendGrid
const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

export function registerBusinessContactsRoutes(app: Express) {
  
  // Get all business contacts
  app.get("/api/admin/business-contacts", async (req, res) => {
    if (!(req.session as any).adminUser) {
      return res.status(401).json({ message: "Admin authentication required" });
    }

    try {
      const result = await db.execute(sql`
        SELECT * FROM business_contacts 
        ORDER BY created_at DESC
      `);
      
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching business contacts:', error);
      res.status(500).json({ error: 'Failed to fetch business contacts' });
    }
  });

  // Add new business contact
  app.post("/api/admin/business-contacts", async (req, res) => {
    if (!(req.session as any).adminUser) {
      return res.status(401).json({ message: "Admin authentication required" });
    }

    try {
      const { businessName, email, phone, website, location, category, notes } = req.body;
      
      const result = await db.execute(sql`
        INSERT INTO business_contacts (
          business_name, email, phone, website, location, category, notes, source
        ) VALUES (
          ${businessName}, ${email}, ${phone || null}, ${website || null}, 
          ${location || null}, ${category || null}, ${notes || null}, 'manual'
        ) RETURNING *
      `);
      
      res.json(result.rows[0]);
    } catch (error) {
      console.error('Error adding business contact:', error);
      res.status(500).json({ error: 'Failed to add business contact' });
    }
  });

  // Update business contact
  app.put("/api/admin/business-contacts/:id", async (req, res) => {
    if (!(req.session as any).adminUser) {
      return res.status(401).json({ message: "Admin authentication required" });
    }

    try {
      const { id } = req.params;
      const { businessName, email, phone, website, location, category, notes, status } = req.body;
      
      const result = await db.execute(sql`
        UPDATE business_contacts SET 
          business_name = ${businessName},
          email = ${email},
          phone = ${phone || null},
          website = ${website || null},
          location = ${location || null},
          category = ${category || null},
          notes = ${notes || null},
          status = ${status || 'active'},
          updated_at = NOW()
        WHERE id = ${parseInt(id)}
        RETURNING *
      `);
      
      res.json(result.rows[0]);
    } catch (error) {
      console.error('Error updating business contact:', error);
      res.status(500).json({ error: 'Failed to update business contact' });
    }
  });

  // Delete business contact
  app.delete("/api/admin/business-contacts/:id", async (req, res) => {
    if (!(req.session as any).adminUser) {
      return res.status(401).json({ message: "Admin authentication required" });
    }

    try {
      const { id } = req.params;
      
      await db.execute(sql`
        DELETE FROM business_contacts WHERE id = ${parseInt(id)}
      `);
      
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting business contact:', error);
      res.status(500).json({ error: 'Failed to delete business contact' });
    }
  });

  // Send outreach email to specific contact
  app.post("/api/admin/business-contacts/:id/send-email", async (req, res) => {
    if (!(req.session as any).adminUser) {
      return res.status(401).json({ message: "Admin authentication required" });
    }

    try {
      const { id } = req.params;
      const { customMessage } = req.body;
      
      // Get contact details
      const result = await db.execute(sql`
        SELECT * FROM business_contacts WHERE id = ${parseInt(id)}
      `);
      
      const contact = result.rows[0];
      if (!contact) {
        return res.status(404).json({ error: 'Contact not found' });
      }

      if (!process.env.SENDGRID_API_KEY) {
        return res.status(500).json({ error: 'Email service not configured' });
      }

      // Generate personalized email content
      const emailContent = generateBusinessOutreachEmail(
        contact.business_name as string, 
        (contact.category as string) || 'your services',
        contact.location as string,
        customMessage
      );

      // Send email via SendGrid
      await mailService.send({
        to: contact.email as string,
        from: 'hello@bopercheck.com',
        subject: `Business opportunity - ${contact.business_name}`,
        html: emailContent
      });

      // Update contact record
      await db.execute(sql`
        UPDATE business_contacts SET 
          email_sent = true,
          email_sent_at = NOW(),
          status = 'contacted',
          updated_at = NOW()
        WHERE id = ${parseInt(id)}
      `);

      res.json({ success: true, message: 'Email sent successfully' });
    } catch (error) {
      console.error('Error sending email:', error);
      res.status(500).json({ error: 'Failed to send email' });
    }
  });

  // Send bulk emails to selected contacts
  app.post("/api/admin/business-contacts/bulk-send", async (req, res) => {
    if (!(req.session as any).adminUser) {
      return res.status(401).json({ message: "Admin authentication required" });
    }

    try {
      const { contactIds, customMessage } = req.body;
      
      if (!process.env.SENDGRID_API_KEY) {
        return res.status(500).json({ error: 'Email service not configured' });
      }

      const results = [];
      
      for (const contactId of contactIds) {
        try {
          const result = await db.execute(sql`
            SELECT * FROM business_contacts WHERE id = ${contactId} AND email_sent = false
          `);
          
          const contact = result.rows[0];
          if (contact) {
            const emailContent = generateBusinessOutreachEmail(
              contact.business_name as string,
              (contact.category as string) || 'your services',
              contact.location as string,
              customMessage
            );

            await mailService.send({
              to: contact.email as string,
              from: 'hello@bopercheck.com',
              subject: `Business opportunity - ${contact.business_name}`,
              html: emailContent
            });

            await db.execute(sql`
              UPDATE business_contacts SET 
                email_sent = true,
                email_sent_at = NOW(),
                status = 'contacted',
                updated_at = NOW()
              WHERE id = ${contactId}
            `);

            results.push({ contactId, success: true, email: contact.email });
          }
        } catch (error) {
          results.push({ contactId, success: false, error: (error as Error).message });
        }
      }

      res.json({ 
        success: true, 
        results,
        totalSent: results.filter(r => r.success).length
      });
    } catch (error) {
      console.error('Error sending bulk emails:', error);
      res.status(500).json({ error: 'Failed to send bulk emails' });
    }
  });
}

// Generate personalized business outreach email
function generateBusinessOutreachEmail(
  businessName: string, 
  category: string, 
  location?: string,
  customMessage?: string
): string {
  const locationText = location ? ` in ${location}` : '';
  
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Business Partnership Opportunity from BoperCheck</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; line-height: 1.6; margin: 0; padding: 20px; background: #f8fafc; color: #334155; }
    .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07); }
    .logo-header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 25px 30px; text-align: center; }
    .logo { display: inline-flex; align-items: center; gap: 12px; margin-bottom: 15px; }
    .logo-icon { width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold; }
    .logo-text { font-size: 24px; font-weight: bold; letter-spacing: -0.5px; }
    .header-subtitle { font-size: 16px; opacity: 0.9; margin: 0; }
    .content { padding: 30px; }
    .highlight { background: #dcfce7; border-left: 4px solid #16a34a; padding: 20px; margin: 25px 0; border-radius: 6px; }
    .cta-box { background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border: 1px solid #0ea5e9; border-radius: 8px; padding: 25px; margin: 30px 0; text-align: center; }
    .cta-button { background: #0ea5e9; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 15px 0; font-weight: 600; }
    .footer { background: #f8fafc; padding: 25px; text-align: center; color: #64748b; font-size: 13px; border-top: 1px solid #e2e8f0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo-header">
      <div class="logo">
        <div class="logo-icon">B</div>
        <div class="logo-text">BoperCheck</div>
      </div>
      <p class="header-subtitle">Business Partnership Opportunity for ${businessName}</p>
    </div>
    
    <div class="content">
      <p>Dear ${businessName} team,</p>
      
      <p>We're reaching out regarding a potential partnership opportunity that could help connect your business with customers actively searching for ${category}${locationText}.</p>
      
      ${customMessage ? `<div class="highlight"><p>${customMessage}</p></div>` : ''}
      
      <p>BoperCheck is an AI-powered price comparison platform that helps UK consumers find the best deals and services. We're looking to partner with quality local businesses to:</p>
      
      <ul>
        <li>Increase your visibility to potential customers</li>
        <li>Drive qualified leads to your business</li>
        <li>Provide competitive market insights</li>
        <li>Help you reach customers actively looking to purchase</li>
      </ul>

      <div class="cta-box">
        <h3>Partnership Benefits</h3>
        <p>Starting from just £35/month, you can:</p>
        <ul style="text-align: left; display: inline-block;">
          <li>Appear in 50+ relevant customer searches monthly</li>
          <li>Get detailed performance analytics</li>
          <li>Receive qualified customer inquiries</li>
          <li>Access market intelligence reports</li>
        </ul>
        <a href="https://bopercheck.com/business" class="cta-button">Learn More About Partnership</a>
      </div>

      <p>If you're interested in learning more about how BoperCheck can help grow your business, I'd be happy to arrange a brief call to discuss the opportunity.</p>
      
      <p>Best regards,<br>
      BoperCheck Partnership Team</p>
    </div>
    
    <div class="footer">
      <p>BoperCheck - AI-powered price comparison for UK consumers</p>
      <p><a href="https://bopercheck.com">bopercheck.com</a> | <a href="mailto:hello@bopercheck.com">hello@bopercheck.com</a></p>
      <div class="unsubscribe">
        <p>If you'd prefer not to receive future partnership opportunities, please reply with "UNSUBSCRIBE"</p>
      </div>
    </div>
  </div>
</body>
</html>`;
}