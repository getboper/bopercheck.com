import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element not found");
}

const root = createRoot(rootElement);
root.render(<App />);

// Auto-healing: Enhanced error tracking
window.addEventListener('error', (event) => {
  console.error('Runtime error caught:', event.error);
  
  // Attempt automatic recovery for common issues
  if (event.error?.message?.includes('Cannot read property')) {
    window.location.reload();
  }
});

window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
  event.preventDefault();
});
