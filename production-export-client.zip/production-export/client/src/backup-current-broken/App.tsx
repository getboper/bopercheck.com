import React, { useState } from 'react'
import LandingPage from './components/LandingPage'
import VoucherPot from './components/VoucherPot'
import AdvertiserDashboard from './components/AdvertiserDashboard'
import { useReviewTrigger } from './hooks/useReviewTrigger'

type Page = 'landing' | 'voucher-pot' | 'advertiser'

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing')
  const { isModalOpen, searchCount, trackSearchActivity, closeModal, resetSearchCount } = useReviewTrigger()

  const navigateTo = (page: Page) => {
    setCurrentPage(page)
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'voucher-pot':
        return (
          <VoucherPot 
            onBackToDemo={() => navigateTo('landing')}
          />
        )
      case 'advertiser':
        return (
          <AdvertiserDashboard 
            onBackToHome={() => navigateTo('landing')}
            onReportSignup={(email, businessName) => {
              console.log('Report signup:', { email, businessName })
            }}
            onPromoSignup={() => console.log('Premium advertising signup')}
          />
        )
      case 'landing':
      default:
        return (
          <LandingPage 
            onShopperClick={() => navigateTo('voucher-pot')}
            onBusinessClick={() => navigateTo('advertiser')}
          />
        )
    }
  }

  return (
    <div>
      {/* Navigation for testing */}
      <div className="fixed top-4 right-4 z-50 flex gap-2 bg-white p-2 rounded-lg shadow-md">
        <button 
          className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300"
          onClick={() => navigateTo('landing')}
        >
          Landing
        </button>
        <button 
          className="px-3 py-1 text-sm bg-yellow-200 rounded hover:bg-yellow-300"
          onClick={() => navigateTo('voucher-pot')}
        >
          Voucher Pot
        </button>
        <button 
          className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300"
          onClick={() => navigateTo('advertiser')}
        >
          Business
        </button>
      </div>
      
      {renderPage()}
    </div>
  )
}

export default App