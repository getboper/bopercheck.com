import React, { useState, useEffect } from 'react'

interface Voucher {
  id: string
  code: string
  brand: string
  value: number
  description: string
  expiryDate: Date
  isUsed: boolean
  category: string
  terms: string
  minSpend?: number
}

interface VoucherWalletProps {
  userId?: string
  onShareVoucher?: (voucherId: string) => void
  onRedeemVoucher?: (voucherId: string) => void
}

const VoucherWallet: React.FC<VoucherWalletProps> = ({ userId, onShareVoucher, onRedeemVoucher }) => {
  const [vouchers, setVouchers] = useState<Voucher[]>([])
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [showExpired, setShowExpired] = useState(false)

  useEffect(() => {
    loadUserVouchers()
  }, [userId])

  const loadUserVouchers = () => {
    // Mock voucher data - replace with actual Firestore fetch
    const mockVouchers: Voucher[] = [
      {
        id: 'v1',
        code: 'SAVE20TECH',
        brand: 'Currys PC World',
        value: 20,
        description: '£20 off electronics over £100',
        expiryDate: new Date('2024-12-31'),
        isUsed: false,
        category: 'electronics',
        terms: 'Valid on electronics over £100. Cannot be combined with other offers.',
        minSpend: 100
      },
      {
        id: 'v2',
        code: 'FASHION15',
        brand: 'Next',
        value: 15,
        description: '£15 off fashion items',
        expiryDate: new Date('2024-11-30'),
        isUsed: false,
        category: 'fashion',
        terms: 'Valid on full price items only. Excludes sale items.'
      },
      {
        id: 'v3',
        code: 'GROCERY10',
        brand: 'Tesco',
        value: 10,
        description: '£10 off your weekly shop',
        expiryDate: new Date('2024-10-15'),
        isUsed: true,
        category: 'grocery',
        terms: 'Minimum spend £50. Valid in-store and online.'
      },
      {
        id: 'v4',
        code: 'DINING25',
        brand: 'Just Eat',
        value: 25,
        description: '£25 off food delivery',
        expiryDate: new Date('2024-09-20'),
        isUsed: false,
        category: 'dining',
        terms: 'Valid on orders over £40. Delivery fees may apply.'
      }
    ]
    setVouchers(mockVouchers)
  }

  const getTotalValue = () => {
    return vouchers
      .filter(v => !v.isUsed && !isExpired(v))
      .reduce((sum, v) => sum + v.value, 0)
  }

  const isExpired = (voucher: Voucher) => {
    return new Date() > voucher.expiryDate
  }

  const getDaysUntilExpiry = (voucher: Voucher) => {
    const days = Math.ceil((voucher.expiryDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    return days
  }

  const getFilteredVouchers = () => {
    return vouchers.filter(voucher => {
      const categoryMatch = selectedCategory === 'all' || voucher.category === selectedCategory
      const expiredMatch = showExpired || !isExpired(voucher)
      return categoryMatch && expiredMatch
    })
  }

  const handleShareVoucher = (voucherId: string) => {
    if (navigator.share) {
      const voucher = vouchers.find(v => v.id === voucherId)
      if (voucher) {
        navigator.share({
          title: `${voucher.brand} Voucher`,
          text: `Check out this ${voucher.brand} voucher: ${voucher.description}`,
          url: `${window.location.origin}/voucher/${voucher.id}`
        })
      }
    } else {
      // Fallback for browsers without Web Share API
      const voucher = vouchers.find(v => v.id === voucherId)
      if (voucher) {
        navigator.clipboard.writeText(`${voucher.brand}: ${voucher.description} - Code: ${voucher.code}`)
        alert('Voucher details copied to clipboard!')
      }
    }
    onShareVoucher?.(voucherId)
  }

  const handleRedeemVoucher = (voucherId: string) => {
    setVouchers(prev => prev.map(v => 
      v.id === voucherId ? { ...v, isUsed: true } : v
    ))
    onRedeemVoucher?.(voucherId)
  }

  const categories = ['all', 'electronics', 'fashion', 'grocery', 'dining']

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2" style={{ color: "#0f172a" }}>
          Your Voucher Wallet 💳
        </h2>
        <div 
          className="text-2xl font-bold mb-4"
          style={{ color: "#059669" }}
        >
          Total Value: £{getTotalValue()}
        </div>
        <p className="text-gray-600">
          {vouchers.filter(v => !v.isUsed && !isExpired(v)).length} active vouchers available
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex gap-2">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
        
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={showExpired}
            onChange={(e) => setShowExpired(e.target.checked)}
            className="rounded"
          />
          <span className="text-sm text-gray-600">Show expired</span>
        </label>
      </div>

      {/* Voucher Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {getFilteredVouchers().map(voucher => {
          const expired = isExpired(voucher)
          const daysLeft = getDaysUntilExpiry(voucher)
          
          return (
            <div
              key={voucher.id}
              className={`rounded-xl p-6 border-2 transition-all ${
                voucher.isUsed 
                  ? 'bg-gray-100 border-gray-300 opacity-60'
                  : expired
                  ? 'bg-red-50 border-red-200'
                  : 'bg-white border-blue-200 hover:border-blue-400 hover:shadow-lg'
              }`}
            >
              {/* Brand Header */}
              <div className="flex justify-between items-start mb-3">
                <h3 className="font-bold text-lg" style={{ color: "#0f172a" }}>
                  {voucher.brand}
                </h3>
                <div 
                  className="text-2xl font-bold"
                  style={{ color: "#059669" }}
                >
                  £{voucher.value}
                </div>
              </div>

              {/* Description */}
              <p className="text-gray-700 mb-3 text-sm">
                {voucher.description}
              </p>

              {/* Voucher Code */}
              <div 
                className="bg-gray-100 p-3 rounded-lg mb-3 font-mono text-center"
                style={{ border: "2px dashed #d1d5db" }}
              >
                <div className="text-xs text-gray-500 mb-1">VOUCHER CODE</div>
                <div className="font-bold text-lg">{voucher.code}</div>
              </div>

              {/* Expiry Status */}
              <div className="mb-4">
                {expired ? (
                  <div className="text-red-600 text-sm font-medium">
                    ❌ Expired {Math.abs(daysLeft)} days ago
                  </div>
                ) : voucher.isUsed ? (
                  <div className="text-gray-500 text-sm font-medium">
                    ✅ Used
                  </div>
                ) : daysLeft <= 7 ? (
                  <div className="text-orange-600 text-sm font-medium">
                    ⚠️ Expires in {daysLeft} days
                  </div>
                ) : (
                  <div className="text-green-600 text-sm font-medium">
                    ✅ Valid for {daysLeft} more days
                  </div>
                )}
              </div>

              {/* Terms */}
              <div className="text-xs text-gray-500 mb-4 line-clamp-2">
                {voucher.terms}
              </div>

              {/* Action Buttons */}
              {!voucher.isUsed && !expired && (
                <div className="flex gap-2">
                  <button
                    onClick={() => handleRedeemVoucher(voucher.id)}
                    className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    Use Now
                  </button>
                  <button
                    onClick={() => handleShareVoucher(voucher.id)}
                    className="bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors text-sm font-medium"
                  >
                    Share
                  </button>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {getFilteredVouchers().length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🎫</div>
          <h3 className="text-xl font-bold mb-2" style={{ color: "#0f172a" }}>
            No vouchers found
          </h3>
          <p className="text-gray-600">
            {selectedCategory === 'all' 
              ? 'Start earning vouchers by completing activities!'
              : `No vouchers in the ${selectedCategory} category.`
            }
          </p>
        </div>
      )}
    </div>
  )
}

export default VoucherWallet