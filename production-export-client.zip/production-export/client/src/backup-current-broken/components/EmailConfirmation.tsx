import React, { useState, useEffect } from 'react'

interface EmailConfirmationProps {
  userEmail?: string
  onConfirmationComplete?: (isConfirmed: boolean) => void
  showModal?: boolean
  onClose?: () => void
}

interface ConfirmationStatus {
  isConfirmed: boolean
  confirmationDate?: Date
  resendCount: number
  lastResendTime?: Date
}

const EmailConfirmation: React.FC<EmailConfirmationProps> = ({
  userEmail,
  onConfirmationComplete,
  showModal = false,
  onClose
}) => {
  const [email, setEmail] = useState(userEmail || '')
  const [confirmationCode, setConfirmationCode] = useState('')
  const [status, setStatus] = useState<ConfirmationStatus>({
    isConfirmed: false,
    resendCount: 0
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [step, setStep] = useState<'email' | 'code' | 'confirmed'>('email')

  useEffect(() => {
    if (userEmail) {
      setEmail(userEmail)
      setStep('code')
    }
  }, [userEmail])

  const isValidEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  }

  const handleSendConfirmation = async () => {
    if (!isValidEmail(email)) {
      setError('Please enter a valid email address')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      // Send confirmation email via SendGrid
      const response = await fetch('/api/sendgrid/confirmation-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          type: 'email_confirmation'
        })
      })

      if (response.ok) {
        setStatus(prev => ({
          ...prev,
          resendCount: prev.resendCount + 1,
          lastResendTime: new Date()
        }))
        setStep('code')
      } else {
        throw new Error('Failed to send confirmation email')
      }
    } catch (error) {
      console.error('Email confirmation error:', error)
      setError('Failed to send confirmation email. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleVerifyCode = async () => {
    if (confirmationCode.length !== 6) {
      setError('Please enter a 6-digit confirmation code')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      // Verify confirmation code
      const response = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          code: confirmationCode
        })
      })

      if (response.ok) {
        setStatus(prev => ({
          ...prev,
          isConfirmed: true,
          confirmationDate: new Date()
        }))
        setStep('confirmed')
        onConfirmationComplete?.(true)
      } else {
        throw new Error('Invalid confirmation code')
      }
    } catch (error) {
      console.error('Code verification error:', error)
      setError('Invalid confirmation code. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleResendCode = () => {
    if (status.resendCount >= 3) {
      setError('Maximum resend attempts reached. Please try again later.')
      return
    }

    const now = new Date()
    if (status.lastResendTime) {
      const timeDiff = (now.getTime() - status.lastResendTime.getTime()) / 1000
      if (timeDiff < 60) {
        setError(`Please wait ${Math.ceil(60 - timeDiff)} seconds before resending`)
        return
      }
    }

    handleSendConfirmation()
  }

  const renderEmailStep = () => (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <div className="text-4xl mb-2">📧</div>
        <h3 className="text-xl font-bold mb-2" style={{ color: "#0f172a" }}>
          Confirm Your Email
        </h3>
        <p className="text-gray-600">
          We'll send you a 6-digit code to verify your email address
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Email Address
        </label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="your@email.com"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading}
        />
      </div>

      {error && (
        <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded text-sm">
          {error}
        </div>
      )}

      <button
        onClick={handleSendConfirmation}
        disabled={isLoading || !email}
        className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed font-medium"
      >
        {isLoading ? 'Sending...' : 'Send Confirmation Code'}
      </button>
    </div>
  )

  const renderCodeStep = () => (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <div className="text-4xl mb-2">🔢</div>
        <h3 className="text-xl font-bold mb-2" style={{ color: "#0f172a" }}>
          Enter Confirmation Code
        </h3>
        <p className="text-gray-600">
          We sent a 6-digit code to <span className="font-medium">{email}</span>
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          6-Digit Code
        </label>
        <input
          type="text"
          value={confirmationCode}
          onChange={(e) => setConfirmationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
          placeholder="123456"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-center text-2xl tracking-widest"
          disabled={isLoading}
          maxLength={6}
        />
      </div>

      {error && (
        <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded text-sm">
          {error}
        </div>
      )}

      <button
        onClick={handleVerifyCode}
        disabled={isLoading || confirmationCode.length !== 6}
        className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed font-medium"
      >
        {isLoading ? 'Verifying...' : 'Verify Code'}
      </button>

      <div className="text-center">
        <button
          onClick={handleResendCode}
          disabled={isLoading || status.resendCount >= 3}
          className="text-blue-600 hover:text-blue-800 text-sm disabled:text-gray-400 disabled:cursor-not-allowed"
        >
          Didn't receive the code? Resend ({3 - status.resendCount} attempts left)
        </button>
      </div>

      <button
        onClick={() => setStep('email')}
        className="w-full text-gray-600 hover:text-gray-800 text-sm"
      >
        ← Change email address
      </button>
    </div>
  )

  const renderConfirmedStep = () => (
    <div className="space-y-4 text-center">
      <div className="text-6xl mb-4">✅</div>
      <h3 className="text-xl font-bold mb-2" style={{ color: "#059669" }}>
        Email Confirmed!
      </h3>
      <p className="text-gray-600 mb-6">
        Your email address has been successfully verified. You now have access to all BoperCheck features.
      </p>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
        <h4 className="font-bold text-green-800 mb-2">What's unlocked:</h4>
        <ul className="text-sm text-green-700 space-y-1 text-left">
          <li>• Premium voucher notifications</li>
          <li>• Weekly market reports</li>
          <li>• Exclusive download access</li>
          <li>• Priority customer support</li>
        </ul>
      </div>

      {onClose && (
        <button
          onClick={onClose}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          Continue to BoperCheck
        </button>
      )}
    </div>
  )

  if (showModal) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
          {step === 'email' && renderEmailStep()}
          {step === 'code' && renderCodeStep()}
          {step === 'confirmed' && renderConfirmedStep()}
          
          {step !== 'confirmed' && onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto">
      {step === 'email' && renderEmailStep()}
      {step === 'code' && renderCodeStep()}
      {step === 'confirmed' && renderConfirmedStep()}
    </div>
  )
}

export default EmailConfirmation