import React, { useState, useEffect } from 'react'

interface VoucherDropProps {
  onGoToDashboard?: () => void
  customVouchers?: string[]
}

const VoucherDrop: React.FC<VoucherDropProps> = ({
  onGoToDashboard,
  customVouchers
}) => {
  const [vouchers, setVouchers] = useState<string[]>([])

  const possibleVouchers = [
    "10% off your next garden equipment purchase 🌿",
    "Free delivery on all home improvement items 🚚",
    "£5 off decking cleaner at ToolHub 🧽",
    "Exclusive BoperCheck user deal: 15% off outdoor lighting 💡",
    "Buy 1 get 1 free on power washers at JetPro ⚡",
    "£20 off driveway sealing when booked online 🛣️"
  ]

  useEffect(() => {
    if (customVouchers && customVouchers.length > 0) {
      setVouchers(customVouchers)
    } else {
      // Generate random vouchers
      const randomCount = Math.floor(Math.random() * 3) + 1
      const shuffled = [...possibleVouchers].sort(() => 0.5 - Math.random())
      const selected = shuffled.slice(0, randomCount)
      setVouchers(selected)
    }
  }, [customVouchers])

  const handleGoToDashboard = () => {
    console.log('Navigate to dashboard')
    onGoToDashboard?.()
  }

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-8"
      style={{ 
        fontFamily: "'Segoe UI', sans-serif",
        background: "#f0fdf4"
      }}
    >
      <div 
        className="max-w-3xl mx-auto rounded-3xl p-8 text-center"
        style={{ 
          background: "white",
          boxShadow: "0 10px 24px rgba(0,0,0,0.08)"
        }}
      >
        <h1 className="text-3xl mb-4">
          🎁 Voucher Drop!
        </h1>
        
        <p 
          className="mb-6"
          style={{ color: "#065f46" }}
        >
          Based on your search, we've found some exclusive offers for you:
        </p>
        
        <div className="mb-8">
          {vouchers.map((voucher, index) => (
            <div 
              key={index}
              className="p-4 my-4 rounded-2xl text-lg"
              style={{ 
                background: "#ecfdf5",
                border: "2px dashed #10b981",
                color: "#065f46"
              }}
            >
              {voucher}
            </div>
          ))}
        </div>
        
        <button 
          onClick={handleGoToDashboard}
          className="mt-8 py-3 px-6 rounded-lg text-white border-none text-base cursor-pointer transition-colors duration-200"
          style={{ background: "#10b981" }}
          onMouseOver={(e) => e.currentTarget.style.background = "#059669"}
          onMouseOut={(e) => e.currentTarget.style.background = "#10b981"}
        >
          Go to Dashboard
        </button>
      </div>
    </div>
  )
}

export default VoucherDrop