import React, { useState, useEffect } from 'react'

interface LockedDownload {
  id: string
  title: string
  description: string
  fileType: 'pdf' | 'excel' | 'word' | 'image'
  fileSize: string
  category: string
  unlockMethod: 'credits' | 'review' | 'share' | 'referral'
  unlockCost?: number
  downloadUrl: string
  thumbnailUrl?: string
  isUnlocked: boolean
  downloadCount: number
  rating: number
  tags: string[]
}

interface DownloadLockerProps {
  userBalance: number
  onUnlock?: (downloadId: string, method: string, cost?: number) => void
  onBalanceUpdate?: (newBalance: number) => void
}

const DownloadLocker: React.FC<DownloadLockerProps> = ({
  userBalance,
  onUnlock,
  onBalanceUpdate
}) => {
  const [downloads, setDownloads] = useState<LockedDownload[]>([])
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedUnlockMethod, setSelectedUnlockMethod] = useState('all')
  const [showUnlockModal, setShowUnlockModal] = useState<string | null>(null)

  useEffect(() => {
    loadDownloads()
  }, [])

  const loadDownloads = () => {
    const mockDownloads: LockedDownload[] = [
      {
        id: 'dl1',
        title: 'Price Comparison Spreadsheet Template',
        description: 'Ready-to-use Excel template for tracking competitor prices and calculating savings.',
        fileType: 'excel',
        fileSize: '1.2 MB',
        category: 'templates',
        unlockMethod: 'credits',
        unlockCost: 3,
        downloadUrl: '/downloads/price-comparison-template.xlsx',
        isUnlocked: false,
        downloadCount: 247,
        rating: 4.8,
        tags: ['excel', 'business', 'analysis']
      },
      {
        id: 'dl2',
        title: 'Voucher Hunting Guide PDF',
        description: 'Complete 25-page guide to finding and maximizing discount vouchers online.',
        fileType: 'pdf',
        fileSize: '3.4 MB',
        category: 'guides',
        unlockMethod: 'review',
        downloadUrl: '/downloads/voucher-hunting-guide.pdf',
        isUnlocked: true,
        downloadCount: 512,
        rating: 4.9,
        tags: ['vouchers', 'savings', 'guide']
      },
      {
        id: 'dl3',
        title: 'Black Friday Shopping Checklist',
        description: 'Printable PDF checklist to maximize your Black Friday savings.',
        fileType: 'pdf',
        fileSize: '0.8 MB',
        category: 'seasonal',
        unlockMethod: 'share',
        downloadUrl: '/downloads/black-friday-checklist.pdf',
        isUnlocked: false,
        downloadCount: 189,
        rating: 4.6,
        tags: ['seasonal', 'checklist', 'planning']
      },
      {
        id: 'dl4',
        title: 'Budget Tracker Spreadsheet',
        description: 'Advanced Excel budget tracker with automated calculations and charts.',
        fileType: 'excel',
        fileSize: '2.1 MB',
        category: 'tools',
        unlockMethod: 'credits',
        unlockCost: 5,
        downloadUrl: '/downloads/budget-tracker.xlsx',
        isUnlocked: false,
        downloadCount: 341,
        rating: 4.7,
        tags: ['budgeting', 'finance', 'tracking']
      },
      {
        id: 'dl5',
        title: 'Local Business Contact Template',
        description: 'Professional Word template for contacting local businesses about price matching.',
        fileType: 'word',
        fileSize: '0.5 MB',
        category: 'templates',
        unlockMethod: 'referral',
        downloadUrl: '/downloads/business-contact-template.docx',
        isUnlocked: false,
        downloadCount: 156,
        rating: 4.4,
        tags: ['business', 'template', 'communication']
      },
      {
        id: 'dl6',
        title: 'Savings Goal Infographic Pack',
        description: 'Collection of motivational infographics to track your savings journey.',
        fileType: 'image',
        fileSize: '4.7 MB',
        category: 'inspiration',
        unlockMethod: 'credits',
        unlockCost: 2,
        downloadUrl: '/downloads/savings-infographics.zip',
        isUnlocked: false,
        downloadCount: 298,
        rating: 4.5,
        tags: ['motivation', 'graphics', 'goals']
      }
    ]
    setDownloads(mockDownloads)
  }

  const getFilteredDownloads = () => {
    return downloads.filter(download => {
      const categoryMatch = selectedCategory === 'all' || download.category === selectedCategory
      const methodMatch = selectedUnlockMethod === 'all' || download.unlockMethod === selectedUnlockMethod
      return categoryMatch && methodMatch
    })
  }

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case 'pdf': return '📄'
      case 'excel': return '📊'
      case 'word': return '📝'
      case 'image': return '🖼️'
      default: return '📁'
    }
  }

  const getUnlockMethodBadge = (method: string, cost?: number) => {
    switch (method) {
      case 'credits':
        return { text: `£${cost} Credits`, color: '#8b5cf6', bg: '#f3e8ff' }
      case 'review':
        return { text: 'Write Review', color: '#3b82f6', bg: '#eff6ff' }
      case 'share':
        return { text: 'Share Required', color: '#10b981', bg: '#f0fdf4' }
      case 'referral':
        return { text: 'Refer Friend', color: '#f59e0b', bg: '#fffbeb' }
      default:
        return { text: 'Unknown', color: '#6b7280', bg: '#f9fafb' }
    }
  }

  const handleUnlock = async (downloadId: string) => {
    const download = downloads.find(d => d.id === downloadId)
    if (!download) return

    if (download.unlockMethod === 'credits' && download.unlockCost) {
      if (userBalance < download.unlockCost) {
        alert(`You need £${download.unlockCost - userBalance} more credits to unlock this download.`)
        return
      }
      
      const newBalance = userBalance - download.unlockCost
      onBalanceUpdate?.(newBalance)
    }

    setDownloads(prev => prev.map(d => 
      d.id === downloadId ? { ...d, isUnlocked: true } : d
    ))

    onUnlock?.(downloadId, download.unlockMethod, download.unlockCost)
    setShowUnlockModal(null)
  }

  const handleDownload = (download: LockedDownload) => {
    if (!download.isUnlocked) return

    // Create download link
    const link = document.createElement('a')
    link.href = download.downloadUrl
    link.download = `${download.title.replace(/\s+/g, '-').toLowerCase()}.${download.fileType}`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    // Update download count
    setDownloads(prev => prev.map(d => 
      d.id === download.id ? { ...d, downloadCount: d.downloadCount + 1 } : d
    ))
  }

  const categories = ['all', 'templates', 'guides', 'seasonal', 'tools', 'inspiration']
  const unlockMethods = ['all', 'credits', 'review', 'share', 'referral']

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2" style={{ color: "#0f172a" }}>
          Download Locker 🔒
        </h2>
        <div className="flex items-center gap-4 mb-4">
          <div className="text-lg font-bold" style={{ color: "#059669" }}>
            Your Balance: £{userBalance.toFixed(2)}
          </div>
          <div className="text-sm text-gray-600">
            {downloads.filter(d => d.isUnlocked).length} of {downloads.length} downloads unlocked
          </div>
        </div>
        <p className="text-gray-600">
          Unlock premium downloads using credits or by completing activities
        </p>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Category
          </label>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Unlock Method
          </label>
          <select
            value={selectedUnlockMethod}
            onChange={(e) => setSelectedUnlockMethod(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {unlockMethods.map(method => (
              <option key={method} value={method}>
                {method.charAt(0).toUpperCase() + method.slice(1)}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Downloads Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {getFilteredDownloads().map(download => {
          const methodBadge = getUnlockMethodBadge(download.unlockMethod, download.unlockCost)
          
          return (
            <div
              key={download.id}
              className={`rounded-xl p-6 border-2 transition-all ${
                download.isUnlocked
                  ? 'border-green-200 bg-green-50'
                  : 'border-gray-200 bg-white hover:border-blue-400 hover:shadow-lg'
              }`}
            >
              {/* File Icon & Status */}
              <div className="flex justify-between items-start mb-4">
                <div className="text-4xl">{getFileIcon(download.fileType)}</div>
                <div className="flex flex-col items-end gap-2">
                  {download.isUnlocked ? (
                    <div className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      ✅ Unlocked
                    </div>
                  ) : (
                    <div 
                      className="px-2 py-1 rounded-full text-xs font-medium"
                      style={{ 
                        backgroundColor: methodBadge.bg,
                        color: methodBadge.color
                      }}
                    >
                      🔒 {methodBadge.text}
                    </div>
                  )}
                </div>
              </div>

              {/* Title & Description */}
              <h3 className="font-bold text-lg mb-2" style={{ color: "#0f172a" }}>
                {download.title}
              </h3>
              <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                {download.description}
              </p>

              {/* File Details */}
              <div className="space-y-2 mb-4 text-sm text-gray-500">
                <div className="flex justify-between">
                  <span>Size:</span>
                  <span>{download.fileSize}</span>
                </div>
                <div className="flex justify-between">
                  <span>Downloads:</span>
                  <span>{download.downloadCount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Rating:</span>
                  <span>{'⭐'.repeat(Math.floor(download.rating))} {download.rating}</span>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 mb-4">
                {download.tags.slice(0, 3).map(tag => (
                  <span
                    key={tag}
                    className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Action Button */}
              {download.isUnlocked ? (
                <button
                  onClick={() => handleDownload(download)}
                  className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors font-medium"
                >
                  Download Now
                </button>
              ) : (
                <button
                  onClick={() => setShowUnlockModal(download.id)}
                  className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Unlock Download
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* Unlock Modal */}
      {showUnlockModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            {(() => {
              const download = downloads.find(d => d.id === showUnlockModal)
              if (!download) return null
              
              const methodBadge = getUnlockMethodBadge(download.unlockMethod, download.unlockCost)
              
              return (
                <>
                  <h3 className="text-xl font-bold mb-4" style={{ color: "#0f172a" }}>
                    Unlock "{download.title}"?
                  </h3>
                  
                  <div className="mb-4">
                    <div 
                      className="p-3 rounded-lg text-center font-medium"
                      style={{ 
                        backgroundColor: methodBadge.bg,
                        color: methodBadge.color
                      }}
                    >
                      Required: {methodBadge.text}
                    </div>
                  </div>

                  {download.unlockMethod === 'credits' && download.unlockCost && (
                    <div className="space-y-2 mb-6 text-sm">
                      <div className="flex justify-between">
                        <span>Cost:</span>
                        <span className="font-bold">£{download.unlockCost}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Your Balance:</span>
                        <span>£{userBalance.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between border-t pt-2">
                        <span>After Purchase:</span>
                        <span className="font-bold">£{(userBalance - download.unlockCost).toFixed(2)}</span>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowUnlockModal(null)}
                      className="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleUnlock(showUnlockModal)}
                      disabled={download.unlockMethod === 'credits' && download.unlockCost && userBalance < download.unlockCost}
                      className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                      {download.unlockMethod === 'credits' ? 'Purchase' : 'Unlock'}
                    </button>
                  </div>
                </>
              )
            })()}
          </div>
        </div>
      )}

      {getFilteredDownloads().length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">📁</div>
          <h3 className="text-xl font-bold mb-2" style={{ color: "#0f172a" }}>
            No downloads found
          </h3>
          <p className="text-gray-600">
            Try adjusting your filters to see more downloads.
          </p>
        </div>
      )}
    </div>
  )
}

export default DownloadLocker