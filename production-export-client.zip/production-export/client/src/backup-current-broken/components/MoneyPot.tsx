import React from 'react'

interface MoneyPotProps {
  currentSavings?: number
  totalSavings?: number
  onKeepSaving?: () => void
  onReferAndEarn?: () => void
  onClaimVoucher?: () => void
}

const MoneyPot: React.FC<MoneyPotProps> = ({
  currentSavings = 8.40,
  totalSavings = 42.60,
  onKeepSaving,
  onReferAndEarn,
  onClaimVoucher
}) => {
  const handleKeepSaving = () => {
    console.log('Navigate to price-checker')
    onKeepSaving?.()
  }

  const handleReferAndEarn = () => {
    alert('Referral link copied!')
    onReferAndEarn?.()
  }

  const handleClaimVoucher = () => {
    alert('Voucher added to your pot!')
    onClaimVoucher?.()
  }

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-8"
      style={{ 
        fontFamily: "'Segoe UI', sans-serif",
        background: "#f9fafb"
      }}
    >
      <div 
        className="max-w-2xl mx-auto rounded-3xl p-8 text-center"
        style={{ 
          background: "white",
          boxShadow: "0 10px 24px rgba(0,0,0,0.08)"
        }}
      >
        <h1 className="text-3xl mb-2">
          🏦 Your BoperCheck Money Pot
        </h1>
        <p className="text-xl text-gray-600 mb-4">
          This search just saved you:
        </p>
        <div 
          className="text-5xl font-bold my-4"
          style={{ color: "#10b981" }}
        >
          £{currentSavings.toFixed(2)}
        </div>

        <div 
          className="mt-4 p-4 rounded-xl"
          style={{ background: "#ecfdf5" }}
        >
          <p className="mb-0" style={{ color: "#065f46" }}>
            Your total savings:
          </p>
          <div 
            className="text-3xl font-bold"
            style={{ color: "#065f46" }}
          >
            £{totalSavings.toFixed(2)}
          </div>
        </div>

        <div 
          className="mt-8 p-4 rounded-xl"
          style={{ background: "#fef3c7" }}
        >
          <p className="mb-4 text-lg">
            🎁 You unlocked a new voucher!
          </p>
          <button 
            className="bg-indigo-600 text-white border-none py-3 px-6 rounded-lg text-base cursor-pointer transition-colors duration-200 hover:bg-indigo-700"
            onClick={handleClaimVoucher}
          >
            Claim It Now
          </button>
        </div>

        <div className="flex justify-center gap-4 mt-8 flex-wrap">
          <button 
            className="bg-indigo-600 text-white border-none py-3 px-6 rounded-lg text-base cursor-pointer transition-colors duration-200 hover:bg-indigo-700"
            onClick={handleKeepSaving}
          >
            🔁 Keep Saving
          </button>
          <button 
            className="bg-indigo-600 text-white border-none py-3 px-6 rounded-lg text-base cursor-pointer transition-colors duration-200 hover:bg-indigo-700"
            onClick={handleReferAndEarn}
          >
            🎉 Refer & Earn
          </button>
        </div>
      </div>
    </div>
  )
}

export default MoneyPot