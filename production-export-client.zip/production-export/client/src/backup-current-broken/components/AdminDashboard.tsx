import React from 'react'

interface AdminDashboardProps {
  totalSearches?: number
  newSignups?: number
  vouchersRedeemed?: number
  topSearchTerm?: string
  systemStatus?: 'operational' | 'warning' | 'error'
  lastSyncTime?: string
  onBackToHome?: () => void
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({
  totalSearches = 194,
  newSignups = 34,
  vouchersRedeemed = 56,
  topSearchTerm = "Decking cleaner",
  systemStatus = 'operational',
  lastSyncTime = '3 mins ago',
  onBackToHome
}) => {
  const getStatusColor = () => {
    switch (systemStatus) {
      case 'operational': return '#16a34a'
      case 'warning': return '#eab308'
      case 'error': return '#dc2626'
      default: return '#16a34a'
    }
  }

  const getStatusText = () => {
    switch (systemStatus) {
      case 'operational': return 'All systems functional'
      case 'warning': return 'Some issues detected'
      case 'error': return 'System errors present'
      default: return 'All systems functional'
    }
  }

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-8"
      style={{ 
        fontFamily: "'Segoe UI', sans-serif",
        background: "#f1f5f9"
      }}
    >
      <div 
        className="max-w-4xl mx-auto rounded-3xl p-8 text-center"
        style={{ 
          background: "white",
          boxShadow: "0 10px 24px rgba(0,0,0,0.08)"
        }}
      >
        <h1 className="text-3xl mb-8">
          📊 BoperCheck Admin Dashboard
        </h1>

        {/* Metrics Grid */}
        <div className="flex flex-wrap gap-6 justify-center mb-8">
          <div 
            className="rounded-xl p-6 w-56"
            style={{ 
              background: "#e0f2fe",
              boxShadow: "0 6px 14px rgba(0,0,0,0.05)"
            }}
          >
            <h2 
              className="text-lg mb-2"
              style={{ color: "#0369a1" }}
            >
              🔍 Total Searches This Week
            </h2>
            <p 
              className="text-3xl font-bold"
              style={{ color: "#0c4a6e" }}
            >
              {totalSearches}
            </p>
          </div>

          <div 
            className="rounded-xl p-6 w-56"
            style={{ 
              background: "#e0f2fe",
              boxShadow: "0 6px 14px rgba(0,0,0,0.05)"
            }}
          >
            <h2 
              className="text-lg mb-2"
              style={{ color: "#0369a1" }}
            >
              👤 New User Signups
            </h2>
            <p 
              className="text-3xl font-bold"
              style={{ color: "#0c4a6e" }}
            >
              {newSignups}
            </p>
          </div>

          <div 
            className="rounded-xl p-6 w-56"
            style={{ 
              background: "#e0f2fe",
              boxShadow: "0 6px 14px rgba(0,0,0,0.05)"
            }}
          >
            <h2 
              className="text-lg mb-2"
              style={{ color: "#0369a1" }}
            >
              🎁 Vouchers Redeemed
            </h2>
            <p 
              className="text-3xl font-bold"
              style={{ color: "#0c4a6e" }}
            >
              {vouchersRedeemed}
            </p>
          </div>

          <div 
            className="rounded-xl p-6 w-56"
            style={{ 
              background: "#e0f2fe",
              boxShadow: "0 6px 14px rgba(0,0,0,0.05)"
            }}
          >
            <h2 
              className="text-lg mb-2"
              style={{ color: "#0369a1" }}
            >
              📈 Top Search Term
            </h2>
            <p 
              className="text-3xl font-bold"
              style={{ color: "#0c4a6e" }}
            >
              "{topSearchTerm}"
            </p>
          </div>
        </div>

        {/* System Status */}
        <div 
          className="mt-8 p-4 rounded-xl"
          style={{ background: "#f0fdf4" }}
        >
          <h3 className="text-lg">
            ✅ System Status: {" "}
            <span style={{ color: getStatusColor() }}>
              {getStatusText()}
            </span>
          </h3>
          <p className="mt-2 text-gray-600">
            Last synced: {lastSyncTime}
          </p>
        </div>

        {/* Back Navigation */}
        <div className="mt-8">
          <button 
            onClick={onBackToHome}
            className="py-2 px-4 text-sm bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors duration-200"
          >
            ← Back to Home
          </button>
        </div>
      </div>
    </div>
  )
}

export default AdminDashboard