import React from 'react'

interface WeeklyReportProps {
  businessName?: string
  location?: string
  searchCount?: number
  exposureRate?: number
  topKeyword?: string
  suggestedBoost?: number
  onFeatureBusiness?: () => void
  onBackToDashboard?: () => void
}

const WeeklyReport: React.FC<WeeklyReportProps> = ({
  businessName = "Sparkle Window Cleaning",
  location = "Plymouth",
  searchCount = 47,
  exposureRate = 78,
  topKeyword = "gutter and fascia cleaning",
  suggestedBoost = 22,
  onFeatureBusiness,
  onBackToDashboard
}) => {
  const handleFeatureBusiness = () => {
    alert('Upgrade page coming soon')
    onFeatureBusiness?.()
  }

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-8"
      style={{ 
        fontFamily: "'Segoe UI', sans-serif",
        background: "#f0f4ff"
      }}
    >
      <div 
        className="max-w-3xl mx-auto rounded-3xl p-8 text-center"
        style={{ 
          background: "white",
          boxShadow: "0 8px 20px rgba(0,0,0,0.08)"
        }}
      >
        <h1 
          className="text-3xl mb-4"
          style={{ color: "#1e3a8a" }}
        >
          📊 Your Weekly BoperCheck Report
        </h1>
        
        <p className="mb-2">
          <strong>Business:</strong> {businessName}
        </p>
        <p className="mb-6">
          <strong>Location:</strong> {location}
        </p>
        
        <div 
          className="p-6 rounded-2xl my-6 text-left"
          style={{ 
            background: "#ecfdf5",
            border: "2px dashed #10b981"
          }}
        >
          <p 
            className="text-base my-2"
            style={{ color: "#065f46" }}
          >
            👀 <strong>Searches for your service:</strong> {searchCount}
          </p>
          <p 
            className="text-base my-2"
            style={{ color: "#065f46" }}
          >
            📍 <strong>Local exposure rate:</strong> {exposureRate}%
          </p>
          <p 
            className="text-base my-2"
            style={{ color: "#065f46" }}
          >
            🏆 <strong>Top keyword opportunity:</strong> "{topKeyword}"
          </p>
          <p 
            className="text-base my-2"
            style={{ color: "#065f46" }}
          >
            📈 <strong>Suggested Boost:</strong> +{suggestedBoost}% click-through with ad upgrade
          </p>
        </div>
        
        <p 
          className="text-lg mb-4"
          style={{ color: "#4338ca" }}
        >
          🎯 Want to appear first next week?
        </p>
        
        <button 
          onClick={handleFeatureBusiness}
          className="py-3 px-6 text-base rounded-lg cursor-pointer transition-colors duration-200 text-white border-none"
          style={{ background: "#4f46e5" }}
          onMouseOver={(e) => e.currentTarget.style.background = "#4338ca"}
          onMouseOut={(e) => e.currentTarget.style.background = "#4f46e5"}
        >
          Feature My Business
        </button>

        {/* Back Navigation */}
        <div className="mt-8">
          <button 
            onClick={onBackToDashboard}
            className="py-2 px-4 text-sm bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors duration-200"
          >
            ← Back to Business Hub
          </button>
        </div>
      </div>
    </div>
  )
}

export default WeeklyReport