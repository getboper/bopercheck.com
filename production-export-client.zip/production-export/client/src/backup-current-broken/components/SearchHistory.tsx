import React, { useState, useEffect } from 'react'

interface SearchHistoryItem {
  id: string
  query: string
  category: string
  timestamp: Date
  results: number
  bestPrice: number
  savings: number
  isFavorite: boolean
  location?: string
}

interface SearchHistoryProps {
  onSearchAgain?: (query: string) => void
  onClearHistory?: () => void
  maxItems?: number
}

const SearchHistory: React.FC<SearchHistoryProps> = ({
  onSearchAgain,
  onClearHistory,
  maxItems = 50
}) => {
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([])
  const [filteredHistory, setFilteredHistory] = useState<SearchHistoryItem[]>([])
  const [searchFilter, setSearchFilter] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [sortBy, setSortBy] = useState<'recent' | 'savings' | 'alphabetical'>('recent')
  const [showStats, setShowStats] = useState(false)

  useEffect(() => {
    loadSearchHistory()
  }, [])

  useEffect(() => {
    applyFilters()
  }, [searchHistory, searchFilter, categoryFilter, sortBy])

  const loadSearchHistory = () => {
    // Mock search history data - replace with actual API call
    const mockHistory: SearchHistoryItem[] = [
      {
        id: '1',
        query: 'iPhone 15 Pro',
        category: 'electronics',
        timestamp: new Date('2024-06-10T14:30:00'),
        results: 12,
        bestPrice: 999,
        savings: 150,
        isFavorite: true,
        location: 'Newcastle'
      },
      {
        id: '2',
        query: 'Samsung TV 55 inch',
        category: 'electronics',
        timestamp: new Date('2024-06-10T11:15:00'),
        results: 8,
        bestPrice: 649,
        savings: 200,
        isFavorite: false,
        location: 'Newcastle'
      },
      {
        id: '3',
        query: 'Nike Air Max shoes',
        category: 'fashion',
        timestamp: new Date('2024-06-09T16:45:00'),
        results: 15,
        bestPrice: 89,
        savings: 35,
        isFavorite: true,
        location: 'Newcastle'
      },
      {
        id: '4',
        query: 'Coffee machine',
        category: 'home',
        timestamp: new Date('2024-06-09T09:20:00'),
        results: 9,
        bestPrice: 129,
        savings: 70,
        isFavorite: false,
        location: 'Newcastle'
      },
      {
        id: '5',
        query: 'Gaming laptop RTX',
        category: 'electronics',
        timestamp: new Date('2024-06-08T13:10:00'),
        results: 6,
        bestPrice: 1299,
        savings: 300,
        isFavorite: true,
        location: 'Newcastle'
      },
      {
        id: '6',
        query: 'Winter jacket',
        category: 'fashion',
        timestamp: new Date('2024-06-07T18:30:00'),
        results: 11,
        bestPrice: 65,
        savings: 25,
        isFavorite: false,
        location: 'Newcastle'
      }
    ]
    setSearchHistory(mockHistory)
  }

  const applyFilters = () => {
    let filtered = [...searchHistory]

    // Apply text filter
    if (searchFilter) {
      filtered = filtered.filter(item =>
        item.query.toLowerCase().includes(searchFilter.toLowerCase())
      )
    }

    // Apply category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(item => item.category === categoryFilter)
    }

    // Apply sorting
    switch (sortBy) {
      case 'recent':
        filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
        break
      case 'savings':
        filtered.sort((a, b) => b.savings - a.savings)
        break
      case 'alphabetical':
        filtered.sort((a, b) => a.query.localeCompare(b.query))
        break
    }

    setFilteredHistory(filtered.slice(0, maxItems))
  }

  const toggleFavorite = (id: string) => {
    setSearchHistory(prev => prev.map(item =>
      item.id === id ? { ...item, isFavorite: !item.isFavorite } : item
    ))
  }

  const removeFromHistory = (id: string) => {
    setSearchHistory(prev => prev.filter(item => item.id !== id))
  }

  const getSearchStats = () => {
    const totalSearches = searchHistory.length
    const totalSavings = searchHistory.reduce((sum, item) => sum + item.savings, 0)
    const averageSavings = totalSavings / totalSearches || 0
    const categoryCounts = searchHistory.reduce((acc, item) => {
      acc[item.category] = (acc[item.category] || 0) + 1
      return acc
    }, {} as Record<string, number>)
    const mostSearchedCategory = Object.entries(categoryCounts)
      .sort(([,a], [,b]) => b - a)[0]?.[0] || 'None'

    return {
      totalSearches,
      totalSavings,
      averageSavings,
      mostSearchedCategory,
      favoriteCount: searchHistory.filter(item => item.isFavorite).length
    }
  }

  const formatTimeAgo = (date: Date) => {
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffMinutes = Math.floor(diffMs / (1000 * 60))

    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`
    if (diffMinutes > 0) return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago`
    return 'Just now'
  }

  const stats = getSearchStats()
  const categories = ['all', 'electronics', 'fashion', 'home', 'automotive', 'books']

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: "#0f172a" }}>
            Search History
          </h2>
          <p className="text-gray-600">
            Track your price comparison searches and savings
          </p>
        </div>
        <button
          onClick={() => setShowStats(!showStats)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          {showStats ? 'Hide Stats' : 'Show Stats'}
        </button>
      </div>

      {/* Statistics Panel */}
      {showStats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <div className="bg-blue-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.totalSearches}</div>
            <div className="text-sm text-blue-700">Total Searches</div>
          </div>
          <div className="bg-green-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-green-600">£{stats.totalSavings}</div>
            <div className="text-sm text-green-700">Total Savings</div>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-purple-600">£{stats.averageSavings.toFixed(0)}</div>
            <div className="text-sm text-purple-700">Avg. Savings</div>
          </div>
          <div className="bg-orange-50 p-4 rounded-lg text-center">
            <div className="text-2xl font-bold text-orange-600">{stats.favoriteCount}</div>
            <div className="text-sm text-orange-700">Favorites</div>
          </div>
          <div className="bg-pink-50 p-4 rounded-lg text-center">
            <div className="text-lg font-bold text-pink-600 capitalize">{stats.mostSearchedCategory}</div>
            <div className="text-sm text-pink-700">Top Category</div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Search Queries
          </label>
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Filter by query..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Sort By
          </label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="recent">Most Recent</option>
            <option value="savings">Highest Savings</option>
            <option value="alphabetical">A-Z</option>
          </select>
        </div>

        <div className="flex items-end">
          <button
            onClick={() => {
              setSearchHistory([])
              onClearHistory?.()
            }}
            className="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors"
          >
            Clear History
          </button>
        </div>
      </div>

      {/* Search History List */}
      <div className="space-y-3">
        {filteredHistory.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-4xl mb-4">🔍</div>
            <h3 className="text-lg font-bold mb-2" style={{ color: "#0f172a" }}>
              No search history found
            </h3>
            <p className="text-gray-600">
              {searchFilter || categoryFilter !== 'all' 
                ? 'No searches match your current filters'
                : 'Start searching to build your history'
              }
            </p>
          </div>
        ) : (
          filteredHistory.map(item => (
            <div
              key={item.id}
              className="bg-white border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-md transition-all"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-bold text-lg" style={{ color: "#0f172a" }}>
                      {item.query}
                    </h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      item.category === 'electronics' ? 'bg-blue-100 text-blue-700' :
                      item.category === 'fashion' ? 'bg-pink-100 text-pink-700' :
                      item.category === 'home' ? 'bg-green-100 text-green-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {item.category}
                    </span>
                    {item.isFavorite && (
                      <span className="text-yellow-500 text-sm">⭐</span>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-3">
                    <div>
                      <span className="font-medium">Best Price:</span> £{item.bestPrice}
                    </div>
                    <div>
                      <span className="font-medium">Savings:</span> 
                      <span className="text-green-600 font-bold"> £{item.savings}</span>
                    </div>
                    <div>
                      <span className="font-medium">Results:</span> {item.results}
                    </div>
                    <div>
                      <span className="font-medium">When:</span> {formatTimeAgo(item.timestamp)}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => toggleFavorite(item.id)}
                    className={`p-2 rounded-lg transition-colors ${
                      item.isFavorite 
                        ? 'bg-yellow-100 text-yellow-600 hover:bg-yellow-200' 
                        : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                    }`}
                    title={item.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    ⭐
                  </button>
                  
                  <button
                    onClick={() => onSearchAgain?.(item.query)}
                    className="bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    Search Again
                  </button>
                  
                  <button
                    onClick={() => removeFromHistory(item.id)}
                    className="bg-gray-200 text-gray-600 px-3 py-2 rounded-lg hover:bg-gray-300 transition-colors text-sm"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Export Options */}
      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h4 className="font-bold mb-2" style={{ color: "#0f172a" }}>
          Export Your Data
        </h4>
        <p className="text-sm text-gray-600 mb-3">
          Download your search history and savings data
        </p>
        <div className="flex gap-2">
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm">
            Export as CSV
          </button>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
            Export as PDF
          </button>
        </div>
      </div>
    </div>
  )
}

export default SearchHistory