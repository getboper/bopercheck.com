import React from 'react'

interface LandingPageProps {
  onShopperClick?: () => void
  onBusinessClick?: () => void
}

const LandingPage: React.FC<LandingPageProps> = ({
  onShopperClick,
  onBusinessClick
}) => {
  const handleShopperClick = () => {
    console.log('Navigate to price-checker')
    onShopperClick?.()
  }

  const handleBusinessClick = () => {
    console.log('Navigate to advertiser')
    onBusinessClick?.()
  }

  return (
    <div className="min-h-screen flex items-center justify-center" 
         style={{ 
           fontFamily: "'Segoe UI', sans-serif",
           background: "linear-gradient(145deg, #ffffff, #f0f4ff)"
         }}>
      <div className="text-center max-w-4xl mx-auto p-8">
        <h1 className="text-4xl mb-2 text-gray-900 font-normal">
          Welcome to BoperCheck
        </h1>
        <p className="text-xl mb-8 text-gray-700">
          What would you like to do?
        </p>
        
        <div className="flex gap-8 flex-wrap justify-center">
          {/* Shopper CTA Box */}
          <div 
            className="w-80 p-8 rounded-3xl cursor-pointer transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lg"
            style={{ 
              backgroundColor: '#ecfdf5',
              boxShadow: '0 8px 24px rgba(0,0,0,0.08)'
            }}
            onClick={handleShopperClick}
          >
            <h2 className="text-2xl mb-2 text-gray-900">
              🛍️ I'm Here to Save Money
            </h2>
            <p className="text-base text-gray-700 mb-5">
              Check prices, earn vouchers, and grow your savings pot.
            </p>
            <button 
              className="bg-indigo-600 text-white border-none py-3 px-6 text-base rounded-lg cursor-pointer transition-colors duration-200 hover:bg-indigo-700"
            >
              Start Saving
            </button>
          </div>

          {/* Business CTA Box */}
          <div 
            className="w-80 p-8 rounded-3xl cursor-pointer transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lg"
            style={{ 
              backgroundColor: '#fef3c7',
              boxShadow: '0 8px 24px rgba(0,0,0,0.08)'
            }}
            onClick={handleBusinessClick}
          >
            <h2 className="text-2xl mb-2 text-gray-900">
              📢 I'm a Local Business
            </h2>
            <p className="text-base text-gray-700 mb-5">
              Claim free weekly reports and advertise where it matters.
            </p>
            <button 
              className="bg-indigo-600 text-white border-none py-3 px-6 text-base rounded-lg cursor-pointer transition-colors duration-200 hover:bg-indigo-700"
            >
              Get My Free Report
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LandingPage