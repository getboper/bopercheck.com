import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Gift, Users, Zap, Crown, Share2, Trophy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { SocialFollowButtons } from "@/components/social/TikTokIntegration";
import { trackSocialProof } from "@/lib/tiktokPixel";

export default function ViralFeatures() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleReferralSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/referral-signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      if (response.ok) {
        toast({
          title: "Welcome to BoperCheck Rewards!",
          description: "Check your email for your personal referral link"
        });
        setEmail("");
      } else {
        throw new Error('Signup failed');
      }
    } catch (error) {
      toast({
        title: "Signup failed",
        description: "Please try again or contact support",
        variant: "destructive"
      });
    }

    setIsSubmitting(false);
  };

  const viralFeatures = [
    {
      icon: <Gift className="w-6 h-6 text-green-600" />,
      title: "Refer & Earn Credits",
      description: "Get 1 free credit for each friend who uses BoperCheck",
      action: "Start Referring",
      color: "green"
    },
    {
      icon: <Users className="w-6 h-6 text-blue-600" />,
      title: "Group Savings Challenge",
      description: "Team up with friends to find the best deals together",
      action: "Create Group",
      color: "blue"
    },
    {
      icon: <Crown className="w-6 h-6 text-purple-600" />,
      title: "Savings Leaderboard",
      description: "Compete for the top spot and win monthly prizes",
      action: "Join Competition",
      color: "purple"
    },
    {
      icon: <Zap className="w-6 h-6 text-yellow-600" />,
      title: "Daily Deal Alerts",
      description: "Get notified about flash sales and limited offers",
      action: "Enable Alerts",
      color: "yellow"
    }
  ];

  const achievements = [
    { name: "First Saver", description: "Complete your first price check", points: 10 },
    { name: "Deal Hunter", description: "Find 5 discount codes", points: 25 },
    { name: "Social Saver", description: "Share 3 amazing deals", points: 15 },
    { name: "Bargain Master", description: "Save over £100 total", points: 50 },
    { name: "Community Builder", description: "Refer 10 friends", points: 100 }
  ];

  return (
    <div className="space-y-8">
      {/* Referral Program Header */}
      <Card className="bg-gradient-to-r from-green-100 to-blue-100 border-green-300">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-green-800">
            BoperCheck Rewards Program
          </CardTitle>
          <p className="text-green-700">
            Earn credits, compete with friends, and unlock exclusive benefits
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleReferralSignup} className="flex gap-2 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email to join"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1"
            />
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="bg-green-600 hover:bg-green-700"
            >
              {isSubmitting ? "Joining..." : "Join Now"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Viral Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {viralFeatures.map((feature, index) => (
          <Card key={index} className={`border-${feature.color}-200 hover:shadow-lg transition-shadow`}>
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className={`p-3 bg-${feature.color}-100 rounded-lg`}>
                  {feature.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{feature.description}</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className={`border-${feature.color}-300 text-${feature.color}-700 hover:bg-${feature.color}-50`}
                  >
                    {feature.action}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Achievements System */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-600" />
            Savings Achievements
          </CardTitle>
          <p className="text-gray-600">Unlock rewards as you save money and help others</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {achievements.map((achievement, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                    <Trophy className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div>
                    <div className="font-medium">{achievement.name}</div>
                    <div className="text-sm text-gray-600">{achievement.description}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-yellow-600">{achievement.points} pts</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Social Sharing Incentives */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-6 text-center">
          <Share2 className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-blue-900 mb-2">
            Share Your Savings Success
          </h3>
          <p className="text-blue-700 mb-4">
            Show off your deals and inspire others to save money
          </p>
          <div className="flex justify-center gap-3">
            <Button className="bg-blue-600 hover:bg-blue-700">
              Share My Savings
            </Button>
            <Button variant="outline" className="border-blue-300 text-blue-700">
              View Success Stories
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Social Follow Section */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="p-6 text-center">
          <Trophy className="w-12 h-12 text-purple-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-purple-900 mb-2">
            Follow for Daily Tips
          </h3>
          <p className="text-purple-700 mb-4">
            Get exclusive money-saving tips and deals on social media
          </p>
          <SocialFollowButtons className="justify-center" />
        </CardContent>
      </Card>
    </div>
  );
};