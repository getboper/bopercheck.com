import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    // Mark that there was a loading issue
    localStorage.setItem('bopercheck_loading_issues', 'true');
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('BoperCheck Error Boundary caught an error:', error, errorInfo);
    
    // Log the error for admin monitoring
    try {
      fetch('/api/admin/log-error', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: error.message,
          stack: error.stack,
          componentStack: errorInfo.componentStack,
          url: window.location.href,
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString()
        })
      }).catch(() => {
        // Silently fail if logging doesn't work
      });
    } catch (e) {
      // Ignore logging errors
    }
  }

  handleReload = () => {
    // Clear cache and reload
    localStorage.setItem('bopercheck_cache_cleared', Date.now().toString());
    window.location.reload();
  };

  handleGoHome = () => {
    // Clear cache and go to home
    localStorage.setItem('bopercheck_cache_cleared', Date.now().toString());
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
          <Card className="max-w-md w-full">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 p-3 bg-red-100 rounded-full w-fit">
                <AlertTriangle className="h-8 w-8 text-red-600" />
              </div>
              <CardTitle className="text-xl text-gray-900">
                Oops! Something went wrong
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 text-center">
                BoperCheck encountered an error. This might be due to cached data causing conflicts.
              </p>
              
              <div className="space-y-2">
                <Button 
                  onClick={this.handleReload}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Clear Cache & Reload
                </Button>
                
                <Button 
                  onClick={this.handleGoHome}
                  variant="outline"
                  className="w-full"
                >
                  <Home className="h-4 w-4 mr-2" />
                  Go to Homepage
                </Button>
              </div>

              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">
                  <strong>Alternative solutions:</strong>
                </p>
                <ul className="text-xs text-gray-500 space-y-1">
                  <li>• Try opening BoperCheck.com in incognito/private mode</li>
                  <li>• Clear your browser cache manually (Ctrl+Shift+Delete)</li>
                  <li>• Try a different browser</li>
                </ul>
              </div>

              {this.state.error && (
                <details className="text-xs text-gray-400">
                  <summary className="cursor-pointer">Technical details</summary>
                  <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto">
                    {this.state.error.message}
                  </pre>
                </details>
              )}
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}