import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Link } from "wouter";

interface FAQItemProps {
  question: string;
  answer: string;
  value: string;
}

const FAQItem = ({ question, answer, value }: FAQItemProps) => {
  return (
    <AccordionItem value={value}>
      <AccordionTrigger className="text-left font-semibold text-lg">
        {question}
      </AccordionTrigger>
      <AccordionContent>
        <p className="text-muted-foreground">{answer}</p>
      </AccordionContent>
    </AccordionItem>
  );
};

const FAQ = () => {
  const faqItems: FAQItemProps[] = [
    {
      question: "Is BoperCheck really free to use?",
      answer: "Yes! BoperCheck is completely free with unlimited price searches forever. No sign-up required, no hidden fees, no credits needed for searches. You can check prices for any product or service as many times as you want. We also offer premium add-ons like PDF downloads (£0.99) and priority results (£1.99) when you need them.",
      value: "item-1"
    },
    {
      question: "How accurate are the price comparisons?",
      answer: "Our AI analyzes real-time data from major UK retailers including Amazon, Currys, Argos, and local suppliers. We provide accurate deal ratings, market comparisons, and highlight the best online prices, second-hand options, and available discount codes for each search.",
      value: "item-2"
    },
    {
      question: "Can I check prices for services, not just products?",
      answer: "Absolutely! BoperCheck works for both products and services. Whether you need to price check home improvements, professional services, or local trades, our AI provides market analysis and recommendations. We'll show local suppliers with ratings and contact details.",
      value: "item-3"
    },
    {
      question: "How do local supplier recommendations work?",
      answer: "When you search for services or products, we automatically show relevant local businesses in your area with ratings, contact information, and pricing insights. This helps you find trusted local suppliers alongside online options for the best deals.",
      value: "item-4"
    },
    {
      question: "What premium features are available?",
      answer: "Our premium features include PDF reports (£0.99) for detailed analysis you can save and share, Priority support (£1.99) for faster responses, and Bundle packages (£4.99) combining multiple premium features. All searches remain free regardless of premium upgrades.",
      value: "item-5"
    },
    {
      question: "Is my search data private and secure?",
      answer: "Yes, we take privacy seriously. Your search data is only used to provide price analysis and improve our service. We never sell personal data to third parties. Searches are processed securely and you control what information you share.",
      value: "item-6"
    }
  ];

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-16">Frequently Asked Questions</h2>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="divide-y">
            {faqItems.map((item) => (
              <FAQItem key={item.value} {...item} />
            ))}
          </Accordion>
          
          <div className="max-w-3xl mx-auto mt-10 text-center">
            <p className="text-muted-foreground">
              Still have questions? <Link href="/contact" className="text-primary hover:underline">Contact our support team</Link>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
