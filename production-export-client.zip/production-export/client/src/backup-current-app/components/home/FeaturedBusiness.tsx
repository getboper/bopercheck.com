import React from "react";
import { Building, ExternalLink, Award, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export function FeaturedBusiness() {
  // In a real implementation, this data would come from an API or database
  const featuredBusiness = {
    name: "Premium Outdoor Living",
    tagline: "Quality garden furniture & decking solutions",
    description: "We specialize in high-quality outdoor living solutions, from custom decking to premium garden furniture. All our products come with a 15-year guarantee and professional installation.",
    logo: null, // Placeholder for logo image URL
    image: null, // Placeholder for business image URL
    website: "premiumoutdoorliving.co.uk",
    phone: "07700 900000",
    location: "Plymouth, England",
    categories: ["Garden & Outdoor", "Home Improvement", "Furniture"]
  };

  return (
    <div className="py-12 px-4 md:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Award className="h-6 w-6 text-amber-500" />
          <h2 className="text-2xl md:text-3xl font-bold">Featured Business of the Month</h2>
        </div>
        
        <div className="bg-gradient-to-br from-amber-50 via-amber-50 to-orange-50 rounded-xl border-2 border-amber-200 overflow-hidden shadow-md">
          <div className="flex flex-col lg:flex-row">
            {/* Left column for logo & image */}
            <div className="lg:w-1/3 flex flex-col">
              <div className="bg-white p-6 flex items-center justify-center h-48">
                {featuredBusiness.logo ? (
                  <img 
                    src={featuredBusiness.logo} 
                    alt={`${featuredBusiness.name} logo`}
                    className="max-h-full max-w-full object-contain"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-center">
                    <Building className="h-20 w-20 text-amber-300 mb-2" />
                    <h3 className="text-xl font-bold text-gray-800">{featuredBusiness.name}</h3>
                  </div>
                )}
              </div>
              
              <div className="flex-grow bg-amber-100 p-4">
                {featuredBusiness.image ? (
                  <img 
                    src={featuredBusiness.image} 
                    alt={`${featuredBusiness.name}`}
                    className="w-full h-full object-cover rounded-md"
                  />
                ) : (
                  <div className="w-full h-full bg-amber-200/50 rounded-md flex items-center justify-center">
                    <span className="text-amber-800 font-medium">Business Showcase Image</span>
                  </div>
                )}
              </div>
            </div>
            
            {/* Right column for business info */}
            <div className="lg:w-2/3 p-6 lg:p-8">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-amber-500 text-white text-xs px-2 py-1 rounded-full uppercase font-bold tracking-wide">
                      Featured
                    </span>
                    <span className="text-gray-500 text-sm">May 2025</span>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">{featuredBusiness.name}</h3>
                  <p className="text-amber-800 font-medium mb-4">{featuredBusiness.tagline}</p>
                </div>
                
                <div className="hidden md:flex items-center gap-2">
                  {featuredBusiness.categories.map((category, index) => (
                    <span 
                      key={index} 
                      className="bg-amber-100 text-amber-800 text-xs font-medium px-2.5 py-0.5 rounded"
                    >
                      {category}
                    </span>
                  ))}
                </div>
              </div>
              
              <p className="text-gray-600 mb-6">
                {featuredBusiness.description}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-amber-600" />
                  <span className="text-gray-700">{featuredBusiness.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-amber-600" />
                  <span className="text-gray-700">{featuredBusiness.phone}</span>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row gap-4">
                <Button className="bg-amber-500 hover:bg-amber-600 text-white">
                  Visit Website
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" className="border-amber-500 text-amber-600 hover:bg-amber-50">
                  Check Prices & Reviews
                </Button>
              </div>
              
              <div className="mt-6 pt-6 border-t border-amber-200">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-xs text-gray-500">
                      Want to be featured? <a href="/business" className="text-amber-600 hover:underline">Join our business program</a>
                    </span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-amber-600 text-sm mr-2">5 ★★★★★</span>
                    <span className="text-xs text-gray-500">Customer Rating</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}