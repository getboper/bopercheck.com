import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Check, FileText, Zap, Package } from "lucide-react";

const Pricing = () => {
  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Free Unlimited Searches + Premium Add-ons
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Get unlimited price checks completely free. Add premium features when you need them.
          </p>
        </div>

        {/* Free Tier */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 border-2 border-green-500">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold mb-2">Free Forever</h3>
              <div className="text-4xl font-bold text-green-600 mb-2">£0</div>
              <p className="text-muted-foreground">Unlimited price checks, always free</p>
            </div>
            <ul className="space-y-3 mb-6 max-w-md mx-auto">
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                <span>Unlimited price comparisons</span>
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                <span>AI-powered analysis</span>
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                <span>Local supplier recommendations</span>
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                <span>Deal rating scores</span>
              </li>
            </ul>
            <div className="text-center">
              <Link href="/">
                <Button className="bg-green-600 hover:bg-green-700 text-white px-8 py-3">
                  Start Free Searches
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Premium Add-ons */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold mb-4">Premium Add-ons</h3>
          <p className="text-muted-foreground">Enhance your results when you need extra features</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {/* PDF Download */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border hover:shadow-xl transition">
            <div className="text-center mb-4">
              <FileText className="h-12 w-12 text-blue-500 mx-auto mb-3" />
              <h4 className="text-xl font-bold mb-2">PDF Download</h4>
              <div className="text-2xl font-bold text-blue-600">£0.99</div>
            </div>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-blue-500 mr-2" />
                <span>Professional PDF report</span>
              </li>
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-blue-500 mr-2" />
                <span>Save and share results</span>
              </li>
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-blue-500 mr-2" />
                <span>Detailed supplier contacts</span>
              </li>
            </ul>
          </div>

          {/* Priority Result */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-2 border-orange-500 hover:shadow-xl transition relative">
            <div className="absolute top-0 right-0 bg-orange-500 text-white px-3 py-1 rounded-bl-lg text-xs font-medium">
              Most Popular
            </div>
            <div className="text-center mb-4">
              <Zap className="h-12 w-12 text-orange-500 mx-auto mb-3" />
              <h4 className="text-xl font-bold mb-2">Priority Result</h4>
              <div className="text-2xl font-bold text-orange-600">£1.99</div>
            </div>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-orange-500 mr-2" />
                <span>Instant premium analysis</span>
              </li>
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-orange-500 mr-2" />
                <span>Extended supplier network</span>
              </li>
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-orange-500 mr-2" />
                <span>Advanced price insights</span>
              </li>
            </ul>
          </div>

          {/* Bundle */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border hover:shadow-xl transition">
            <div className="text-center mb-4">
              <Package className="h-12 w-12 text-purple-500 mx-auto mb-3" />
              <h4 className="text-xl font-bold mb-2">Bundle Deal</h4>
              <div className="text-2xl font-bold text-purple-600">£4.99</div>
              <div className="text-sm text-muted-foreground">(Save £1.98)</div>
            </div>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-purple-500 mr-2" />
                <span>3 PDF Downloads</span>
              </li>
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-purple-500 mr-2" />
                <span>3 Priority Results</span>
              </li>
              <li className="flex items-center text-sm">
                <Check className="h-4 w-4 text-purple-500 mr-2" />
                <span>Best value option</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground">
            Add premium features on any search result when you need them
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;