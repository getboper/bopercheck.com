import { Star, StarHalf } from "lucide-react";

interface TestimonialProps {
  quote: string;
  name: string;
  location: string;
  rating: number;
  initials: string;
}

const Testimonial = ({ quote, name, location, rating, initials }: TestimonialProps) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 !== 0;
  
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg">
      <div className="flex items-center mb-4">
        <div className="text-yellow-400 flex">
          {Array.from({ length: fullStars }).map((_, i) => (
            <Star key={i} className="h-5 w-5 fill-current" />
          ))}
          {hasHalfStar && (
            <StarHalf className="h-5 w-5 fill-current" />
          )}
        </div>
      </div>
      <p className="text-muted-foreground mb-4">{quote}</p>
      <div className="flex items-center">
        <div className="bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center mr-3">
          <span className="font-medium text-gray-700">{initials}</span>
        </div>
        <div>
          <p className="font-medium">{name}</p>
          <p className="text-sm text-gray-500">{location}</p>
        </div>
      </div>
    </div>
  );
};

const Testimonials = () => {
  const testimonials: TestimonialProps[] = [
    {
      quote: "Saved me £200 on my new laptop purchase! The AI found a deal I would have never discovered on my own. Brilliant service.",
      name: "James D.",
      location: "London, UK",
      rating: 5,
      initials: "JD"
    },
    {
      quote: "I use BoperCheck before any major purchase. It helped me negotiate a better price for furniture by showing accurate market rates.",
      name: "Sarah M.",
      location: "Manchester, UK",
      rating: 4.5,
      initials: "SM"
    },
    {
      quote: "So easy to use and surprisingly accurate! I compared prices for wedding venues and saved nearly £1,000. Worth every penny.",
      name: "Chris T.",
      location: "Edinburgh, UK",
      rating: 5,
      initials: "CT"
    }
  ];

  return (
    <section className="py-20 gradient-bg">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-16">What Our Users Say</h2>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Testimonial key={index} {...testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
