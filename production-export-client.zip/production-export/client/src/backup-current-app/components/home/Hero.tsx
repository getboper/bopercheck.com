import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { categoryIcons } from "@/lib/utils";
import CategoryIcon from "@/components/ui/category-icon";
import { FaRobot, FaMoneyBillWave, FaRegPlayCircle, FaShoppingBag } from "react-icons/fa";
import { MdTextFields } from "react-icons/md";

const Hero = () => {
  const [itemInput, setItemInput] = useState("");
  const [, navigate] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (itemInput.trim()) {
      navigate(`/price-check?item=${encodeURIComponent(itemInput.trim())}`);
    }
  };

  const handleHowItWorks = () => {
    const howItWorksSection = document.getElementById('how-it-works');
    if (howItWorksSection) {
      howItWorksSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const categories = Object.keys(categoryIcons).slice(0, 4);

  return (
    <section className="relative overflow-hidden">
      {/* Gradient background with more vibrant colors */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-500 to-pink-500 opacity-90"></div>
      
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex flex-col items-center">
            <div className="w-full">

              
              <h1 className="text-xl md:text-2xl text-white/90 mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-green-400 bg-clip-text text-transparent font-bold animate-pulse">
                  Search for any price, find the best deals, and save money on everything you buy - completely free
                </span>
              </h1>
              
              {/* Primary search form - main CTA */}
              <div className="max-w-2xl mx-auto">
                <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8 border border-gray-200 relative overflow-hidden">
                  {/* High-gloss effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-white/40 via-transparent to-transparent rounded-3xl pointer-events-none"></div>
                  <div className="absolute top-0 left-0 w-full h-1/3 bg-gradient-to-b from-white/20 to-transparent rounded-t-3xl pointer-events-none"></div>
                  
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                      How much is that item? Who sells it cheapest? Find out instantly.
                    </h3>
                    <form onSubmit={handleSubmit} className="mb-6">
                      <Input
                        type="text"
                        placeholder="Enter item or service (e.g. iPhone 12 Pro, Dyson vacuum)"
                        className="w-full px-6 py-5 rounded-2xl text-lg text-gray-900 focus:outline-none focus:ring-3 focus:ring-green-400 border-2 border-gray-200 shadow-inner mb-4 bg-white"
                        value={itemInput}
                        onChange={(e) => setItemInput(e.target.value)}
                      />
                      <Button 
                        type="submit" 
                        className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-5 px-8 rounded-2xl transition text-xl shadow-xl transform hover:scale-105"
                      >
                        Check Price Now
                      </Button>
                    </form>
                    
                    <div className="flex justify-center gap-8">
                      <div className="flex flex-col items-center text-gray-700">
                        <div className="bg-blue-100 p-4 rounded-full mb-2">
                          <MdTextFields size={28} className="text-blue-600" />
                        </div>
                        <span className="text-sm font-medium">Enter Text</span>
                      </div>
                      
                      <div className="flex flex-col items-center text-gray-700">
                        <div className="bg-green-100 p-4 rounded-full mb-2">
                          <FaMoneyBillWave size={28} className="text-green-600" />
                        </div>
                        <span className="text-sm font-medium">Save Money</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* USA Launch Banner - Larger Flag Display */}
                <div className="mt-4 max-w-lg mx-auto">
                  <a 
                    href="/usa-launch" 
                    className="block w-full p-6 rounded-lg border border-red-300 hover:border-red-400 transition-all duration-300 transform hover:scale-102 usa-flag-banner relative overflow-hidden min-h-[80px]"
                    style={{
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1235 650'%3E%3Cpath fill='%23B22234' d='M0 0h1235v50H0zM0 100h1235v50H0zM0 200h1235v50H0zM0 300h1235v50H0zM0 400h1235v50H0zM0 500h1235v50H0zM0 600h1235v50H0z'/%3E%3Cpath fill='white' d='M0 50h1235v50H0zM0 150h1235v50H0zM0 250h1235v50H0zM0 350h1235v50H0zM0 450h1235v50H0zM0 550h1235v50H0z'/%3E%3Cpath fill='%23002868' d='M0 0h494v350H0z'/%3E%3Cg fill='white'%3E%3Cg id='s18'%3E%3Cg id='s9'%3E%3Cg id='s5'%3E%3Cg id='s4'%3E%3Cpath id='s' d='m247,90 0,0-5.5,16.87L254.33,100l-16.87,5.5L247,90 254.33,100 237.46,106.87 254.33,100z'/%3E%3Cuse href='%23s' y='140'/%3E%3Cuse href='%23s' y='280'/%3E%3C/g%3E%3Cuse href='%23s4' x='-123.5' y='70'/%3E%3C/g%3E%3Cuse href='%23s5' x='-247' y='140'/%3E%3C/g%3E%3Cuse href='%23s9' x='123.5'/%3E%3C/g%3E%3Cuse href='%23s18' x='-494'/%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center',
                      backgroundRepeat: 'no-repeat'
                    }}
                  >
                    <div className="flex items-center justify-center relative z-10">
                      <div className="bg-black bg-opacity-60 px-4 py-2 rounded backdrop-blur-sm">
                        <span className="text-sm font-bold text-white drop-shadow-lg">
                          USA LAUNCH COMING SOON - Register Interest
                        </span>
                      </div>
                    </div>
                  </a>
                </div>
              </div>

              <div className="flex justify-center mb-6">
                <Button 
                  onClick={handleHowItWorks}
                  variant="outline" 
                  className="bg-white/10 hover:bg-white/20 text-white border-white/20 font-semibold py-3 px-6 rounded-xl text-lg flex items-center gap-2"
                >
                  <FaRegPlayCircle /> Watch How It Works
                </Button>
              </div>

              <p className="text-white/80 text-lg">
                No sign-up needed - search for free
              </p>
            </div>
          </div>
          
          {/* Universal benefits instead of specific categories */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto mt-12">
            <div className="bg-white/10 hover:bg-white/20 rounded-xl p-4 flex flex-col items-center transition transform hover:scale-105 backdrop-blur-sm border border-white/10">
              <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-4 rounded-full mb-3 shadow-lg">
                <FaMoneyBillWave className="text-white text-2xl" />
              </div>
              <span className="text-white font-medium">Save Money</span>
            </div>
            
            <div className="bg-white/10 hover:bg-white/20 rounded-xl p-4 flex flex-col items-center transition transform hover:scale-105 backdrop-blur-sm border border-white/10">
              <div className="bg-gradient-to-br from-blue-400 to-indigo-500 p-4 rounded-full mb-3 shadow-lg">
                <FaRobot className="text-white text-2xl" />
              </div>
              <span className="text-white font-medium">AI Powered</span>
            </div>
            
            <div className="bg-white/10 hover:bg-white/20 rounded-xl p-4 flex flex-col items-center transition transform hover:scale-105 backdrop-blur-sm border border-white/10">
              <div className="bg-gradient-to-br from-purple-400 to-pink-500 p-4 rounded-full mb-3 shadow-lg">
                <FaShoppingBag className="text-white text-2xl" />
              </div>
              <span className="text-white font-medium">Any Product</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
