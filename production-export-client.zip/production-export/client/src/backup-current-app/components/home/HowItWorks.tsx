import { cn } from "@/lib/utils";
import { FaCamera, FaRobot, FaShoppingBag, FaStar, FaArrowRight } from "react-icons/fa";

interface StepProps {
  number: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  gradient: string;
  imageSrc: string;
}

const Step = ({ number, title, description, icon, gradient, imageSrc }: StepProps) => {
  return (
    <div className="relative group">
      {/* Connecting line between steps (only visible on desktop) */}
      {number < 3 && (
        <div className="hidden md:block absolute top-16 right-0 w-full h-2 z-0">
          <div className="h-0.5 w-full bg-gradient-to-r from-transparent via-gray-200 to-transparent relative">
            <div className="absolute -right-2 top-1/2 transform -translate-y-1/2">
              <FaArrowRight className="text-gray-300 text-xl" />
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-white rounded-2xl p-6 shadow-xl border border-gray-100 transition-all duration-300 group-hover:shadow-2xl group-hover:-translate-y-1 h-full flex flex-col z-10 relative">
        {/* Glossy number indicator */}
        <div className={cn("absolute -top-5 -left-2 rounded-full w-16 h-16 flex items-center justify-center shadow-lg", gradient)}>
          <span className="text-2xl font-bold text-white">{number}</span>
        </div>
        
        {/* Icon with gradient background */}
        <div className="mb-6 mt-6 flex justify-center">
          <div className={cn("rounded-full w-20 h-20 flex items-center justify-center shadow-md", gradient)}>
            {icon}
          </div>
        </div>
        
        <h3 className="text-2xl font-bold mb-3 text-center">{title}</h3>
        <p className="text-gray-600 mb-6 text-center">{description}</p>
        
        {/* Image with rounded corners and glossy effect */}
        <div className="mt-auto rounded-xl overflow-hidden shadow-lg border border-gray-100 group-hover:shadow-xl transition-all duration-300">
          <div 
            className="w-full h-48 bg-cover bg-center transform transition-transform duration-500 group-hover:scale-105"
            style={{ backgroundImage: `url(${imageSrc})` }}
          >
            <div className="w-full h-full bg-gradient-to-t from-black/20 to-transparent flex items-end">
              <div className="p-3 flex items-center gap-1">
                <FaStar className="text-yellow-400" />
                <FaStar className="text-yellow-400" />
                <FaStar className="text-yellow-400" />
                <FaStar className="text-yellow-400" />
                <FaStar className="text-yellow-400" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const HowItWorks = () => {
  const steps: StepProps[] = [
    {
      number: 1,
      title: "Snap or Type",
      description: "Upload a photo or describe the item you want to price check. No jargon needed!",
      icon: <FaCamera className="text-white text-3xl" />,
      gradient: "bg-gradient-to-br from-blue-500 to-indigo-600",
      imageSrc: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
    },
    {
      number: 2,
      title: "AI Does the Work",
      description: "Our AI instantly scans thousands of prices to find what you should really pay.",
      icon: <FaRobot className="text-white text-3xl" />,
      gradient: "bg-gradient-to-br from-purple-500 to-pink-600",
      imageSrc: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
    },
    {
      number: 3,
      title: "Shop Smarter",
      description: "See if it's a deal or dud in seconds. We'll even show where to buy it cheaper!",
      icon: <FaShoppingBag className="text-white text-3xl" />,
      gradient: "bg-gradient-to-br from-green-500 to-emerald-600",
      imageSrc: "https://images.unsplash.com/photo-1579621970588-a35d0e7ab9b6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">How It Works</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Stop overpaying for stuff! Our AI compares prices across the internet in seconds
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-12 max-w-6xl mx-auto px-4">
          {steps.map((step) => (
            <Step key={step.number} {...step} />
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a href="/price-check" className="inline-block bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-8 rounded-xl text-lg shadow-lg transform transition hover:-translate-y-1">
            Try It Now - It's Free!
          </a>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
