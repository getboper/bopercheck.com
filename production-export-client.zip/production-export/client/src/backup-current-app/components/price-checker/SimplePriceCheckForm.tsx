import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { PriceAnalysisResult, analyzePriceWithAI } from "@/lib/anthropic";
import { trackPriceAnalysis } from "@/lib/firebaseAnalytics";
import { Loader2, RefreshCcw } from "lucide-react";
import PriceResults from "./PriceResults";
import SafariErrorHandler from "@/lib/safariErrorHandler";
import { BusinessSignupCTA } from "@/components/business/BusinessSignupCTA";

const formSchema = z.object({
  item: z.string().min(2, { message: "Please enter what you're looking for" }),
  description: z.string().optional(),
  budget: z.union([
    z.number().positive().optional(),
    z.string().optional().transform(val => val === "" ? undefined : Number(val))
  ]),
  location: z.string().optional()
});

type FormValues = z.infer<typeof formSchema>;

interface SimplePriceCheckFormProps {
  initialItem?: string;
}

const SimplePriceCheckForm = ({ initialItem }: SimplePriceCheckFormProps) => {
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [results, setResults] = useState<PriceAnalysisResult | null>(null);
  
  const { toast } = useToast();
  const { user } = useAuth();
  const safariHandler = SafariErrorHandler.getInstance();

  useEffect(() => {
    // Initialize Safari error handling for this component
    safariHandler.initialize();
  }, []);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      item: initialItem || "",
      description: "",
      budget: undefined,
      location: ""
    }
  });

  // Update form when initialItem changes
  useEffect(() => {
    if (initialItem) {
      form.setValue("item", initialItem);
    }
  }, [initialItem, form]);

  const onSubmit = async (values: FormValues) => {
    try {
      setIsAnalyzing(true);
      
      // Clear caches to prevent stale data
      // Cache clearing handled server-side
      
      const analysisResult = await analyzePriceWithAI(
        values.item,
        values.description,
        undefined, // category
        values.budget as number,
        undefined, // imageBase64 disabled
        true, // always enable installation detection - AI handles automatically
        values.location || ""
      );
      
      // Track the price analysis in both Firebase and Google Analytics
      trackPriceAnalysis(
        values.item, 
        values.description || 'general',
        values.budget as number
      );
      
      // Also track in Google Analytics directly
      if (typeof window !== 'undefined' && window.gtag) {
        window.gtag('event', 'price_check_completed', {
          event_category: 'engagement',
          event_label: values.item,
          custom_parameter_1: values.item,
          value: values.budget || 0
        });
        console.log('Price check tracked in Google Analytics:', values.item);
      }
      
      // Mark free credit as used for guests
      if (!user) {
        localStorage.setItem('usedFreeCredit', 'true');
      }
      
      // Save the price check - database storage is now handled by the server
      if (user) {
        console.log("Price check saved for user:", user.uid);
      } else {
        // Also save to localStorage for local persistence
        const guestChecks = JSON.parse(localStorage.getItem('guestChecks') || '[]');
        guestChecks.push({
          item: values.item,
          timestamp: new Date().toISOString(),
          location: values.location || "",
          result: analysisResult
        });
        localStorage.setItem('guestChecks', JSON.stringify(guestChecks));
        console.log("Price check saved for guest to localStorage");
      }
      
      setResults(analysisResult);
      setIsAnalyzing(false);
    } catch (error) {
      console.error("Error during price analysis:", error);
      
      const errorMessage = error instanceof Error ? error.message : String(error);
      
      // Detect critical errors that indicate system issues
      const isCriticalError = errorMessage.includes('Method is not a valid HTTP token') || 
                             errorMessage.includes('Analysis failed') ||
                             errorMessage.includes('HTTP error! status: 500') ||
                             errorMessage.includes('Failed to fetch');
      
      // Handle Safari-specific cache errors
      safariHandler.handleError(error as Error);
      
      // Show appropriate error message based on browser and error type
      const userAgent = navigator.userAgent.toLowerCase();
      const isSafariMobile = userAgent.includes('safari') && (userAgent.includes('iphone') || userAgent.includes('ipad'));
      
      if (isSafariMobile && (isCriticalError || safariHandler.shouldShowCachePrompt())) {
        toast({
          title: "Safari Cache Issue",
          description: "Please clear your Safari cache and try again. Tap Settings → Safari → Clear History and Website Data.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Analysis failed",
          description: "Please try again or contact support if the problem persists.",
          variant: "destructive"
        });
      }
      
      setIsAnalyzing(false);
    }
  };

  const handleNewSearch = () => {
    setResults(null);
    form.reset();
  };

  if (results) {
    return (
      <>
        <PriceResults 
          results={results} 
          itemName={form.getValues("item")}
          onNewSearch={handleNewSearch}
        />
        {/* Show business CTA after results to capture business interest */}
        <BusinessSignupCTA 
          category="general" 
          itemType={results.productName || form.getValues("item")}
        />
      </>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-8">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="item"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-lg font-semibold">What are you looking for?</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="e.g., wireless headphones, laptop stand, coffee machine"
                    className="text-lg py-3 rounded-xl"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Additional details (optional)</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Any specific requirements, features, or preferences..."
                    className="rounded-xl"
                    rows={3}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="budget"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Budget (optional)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number"
                      placeholder="£100"
                      className="rounded-xl"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location (optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g., London, Manchester"
                      className="rounded-xl"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription className="text-xs">
                    For local business recommendations
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>



          <Button 
            type="submit" 
            disabled={isAnalyzing}
            className="w-full bg-green-500 hover:bg-green-600 text-white py-4 rounded-xl text-lg font-semibold shadow-lg"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Analyzing prices...
              </>
            ) : (
              "Check Prices"
            )}
          </Button>
        </form>


      </Form>
    </div>
  );
};

export default SimplePriceCheckForm;