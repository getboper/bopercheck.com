import { useState } from "react";
import { 
  Download, 
  Mail, 
  Share2, 
  RefreshCcw, 
  ExternalLink,
  MapPin,
  Store,
  ShoppingBag,
  Search,
  Home,
  Info
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DealRating } from "./DealRating";
import { formatCurrency } from "@/lib/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { BusinessSignupCTA } from "@/components/business/BusinessSignupCTA";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "@/hooks/use-location";
import { generatePDF } from "@/lib/utils";
import { PriceAnalysisResult } from "@/lib/anthropic";

interface PriceResultPageProps {
  result: PriceAnalysisResult;
  itemName: string;
  onNewSearch: () => void;
}

export function PriceResultPage({ result, itemName, onNewSearch }: PriceResultPageProps) {
  const [isSending, setIsSending] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [showReferral, setShowReferral] = useState(false);
  const { toast } = useToast();
  const { city, region } = useLocation();
  
  // Sort stores by price
  const sortedStores = [...result.stores].sort((a, b) => a.price - b.price);
  const hasLocalStores = sortedStores.some(store => (store.name || '').includes("Local"));
  
  // Handle PDF download
  const handleDownloadPDF = () => {
    setIsDownloading(true);
    try {
      generatePDF({
        itemName,
        result,
        date: new Date().toLocaleDateString(),
        location: city ? `${city}, ${region}` : "Your location"
      });
      
      toast({
        title: "PDF Generated Successfully",
        description: "Your price report has been downloaded",
      });
      
      setShowReferral(true);
    } catch (error) {
      console.error("PDF generation error:", error);
      toast({
        title: "Failed to generate PDF",
        description: "Please try again or contact support",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };
  
  // Handle share via email
  const handleShareViaEmail = () => {
    setIsSending(true);
    
    // Simulate email sending
    setTimeout(() => {
      toast({
        title: "Results Sent!",
        description: "Check your email for the price report",
      });
      setIsSending(false);
      setShowReferral(true);
    }, 1500);
  };
  
  return (
    <div className="container max-w-4xl">
      {/* Main result card */}
      <Card className="bg-white shadow-md mb-8">
        <CardHeader className="border-b pt-6 pb-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-bold">{itemName}</h2>
              <p className="text-gray-500">Price Analysis Results</p>
            </div>
            <DealRating rating={result.dealRating} size="lg" />
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {/* Price overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card className="bg-green-50 border-green-100">
              <CardContent className="pt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600 text-sm">Best Price</span>
                  <Badge className="bg-green-500">SAVE {formatCurrency(result.marketValue - result.lowestPrice, result.currency)}</Badge>
                </div>
                <div className="text-2xl font-bold text-green-700">{formatCurrency(result.lowestPrice, result.currency)}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-4">
                <span className="text-gray-600 text-sm mb-2 block">Average Market Price</span>
                <div className="text-2xl font-bold">{formatCurrency(result.marketValue, result.currency)}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-4">
                <span className="text-gray-600 text-sm mb-2 block">Premium Price</span>
                <div className="text-2xl font-bold">{formatCurrency(result.priceRange.max, result.currency)}</div>
              </CardContent>
            </Card>
          </div>
          
          {/* Analysis */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-2">Analysis</h3>
            <p className="text-gray-700">{result.analysis}</p>
          </div>
          
          {/* Where to buy section */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Where to Buy</h3>
              {hasLocalStores && (
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="h-4 w-4 mr-1" />
                  {city ? `${city}, ${region}` : "Showing local options"}
                </div>
              )}
            </div>
            
            <div className="space-y-4">
              {sortedStores.map((store, index) => (
                <Card key={index} className={`overflow-hidden ${index === 0 ? 'border-green-300 bg-green-50' : ''}`}>
                  <CardContent className="p-0">
                    <div className="grid grid-cols-1 md:grid-cols-3">
                      <div className="p-4 flex items-center">
                        <div className="mr-3">
                          {store.name.includes("Local") ? (
                            <div className="bg-blue-100 p-2 rounded-lg">
                              <Store className="h-6 w-6 text-blue-600" />
                            </div>
                          ) : (
                            <div className="bg-purple-100 p-2 rounded-lg">
                              <ShoppingBag className="h-6 w-6 text-purple-600" />
                            </div>
                          )}
                        </div>
                        <div>
                          <h4 className="font-medium">{store.name || 'Store'}</h4>
                          {(store.name || '').includes("Local") && (
                            <Badge variant="outline" className="text-xs">
                              Local Business
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="p-4 border-t md:border-t-0 md:border-l border-r-0 md:border-r">
                        <div className="text-sm text-gray-500 mb-1">Price</div>
                        <div className="font-bold text-lg">
                          {formatCurrency(store.price, result.currency)}
                          {index === 0 && (
                            <Badge className="ml-2 bg-green-500">BEST DEAL</Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="p-4 border-t md:border-t-0 border-l-0 md:border-l">
                        <div className="flex justify-between items-center h-full">
                          <div className="text-sm">
                            {store.notes || ''}
                          </div>
                          <a 
                            href={store.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="ml-2 flex-shrink-0"
                          >
                            <Button size="sm" variant="outline" className="gap-1">
                              <ExternalLink className="h-4 w-4" />
                              Visit
                            </Button>
                          </a>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Call to action for businesses */}
          <div className="mt-10 mb-4">
            <Separator className="mb-6" />
            <BusinessSignupCTA />
          </div>
          
          {/* Action buttons */}
          <div className="mt-10">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                onClick={handleDownloadPDF}
                disabled={isDownloading}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                <Download className="mr-2 h-4 w-4" />
                {isDownloading ? "Generating..." : "Download PDF"}
              </Button>
              
              <Button
                onClick={handleShareViaEmail}
                disabled={isSending}
                variant="outline"
                className="border-indigo-300 text-indigo-600 hover:bg-indigo-50"
              >
                <Mail className="mr-2 h-4 w-4" />
                {isSending ? "Sending..." : "Email Results"}
              </Button>
              
              <Button
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: `BoperCheck: ${itemName} Price Analysis`,
                      text: `The best price for ${itemName} is ${formatCurrency(result.lowestPrice, result.currency)}. Check out the full analysis!`,
                      url: window.location.href,
                    }).catch(err => console.error('Error sharing:', err));
                  } else {
                    // Fallback: copy to clipboard
                    navigator.clipboard.writeText(window.location.href);
                    toast({
                      title: "Link Copied",
                      description: "Share link copied to clipboard",
                    });
                  }
                  setShowReferral(true);
                }}
                variant="outline"
              >
                <Share2 className="mr-2 h-4 w-4" />
                Share Results
              </Button>
              
              <Button
                onClick={onNewSearch}
                variant="outline"
              >
                <RefreshCcw className="mr-2 h-4 w-4" />
                Check Another
              </Button>
            </div>
          </div>
          
          {/* Referral prompt */}
          {showReferral && (
            <Alert className="mt-8 bg-green-50 border-green-200">
              <AlertDescription className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="text-center sm:text-left">
                  <p className="font-semibold text-green-800">Loved your result? Invite a friend, you both get credits for premium features!</p>
                </div>
                <Button 
                  className="bg-green-600 hover:bg-green-700 whitespace-nowrap"
                  onClick={() => window.location.href = '/referral'}
                >
                  Get Premium Credits
                </Button>
              </AlertDescription>
            </Alert>
          )}
          
          {/* Navigation buttons */}
          <div className="mt-12 pt-8 border-t border-gray-200">
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                onClick={onNewSearch}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg font-semibold w-full sm:w-auto"
              >
                <Search className="mr-2 h-5 w-5" />
                Start New Search
              </Button>
              
              <Button
                onClick={() => window.location.href = '/'}
                size="lg"
                variant="outline"
                className="border-gray-300 text-gray-700 hover:bg-gray-50 px-8 py-3 text-lg font-semibold w-full sm:w-auto"
              >
                <Home className="mr-2 h-5 w-5" />
                Back to Home
              </Button>
            </div>
          </div>

          {/* Business advertising tooltip */}
          <div className="mt-8 p-6 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <Info className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-amber-800 mb-2">Why BoperCheck ads work better</h4>
                <p className="text-amber-700 text-sm">
                  Your ad is only shown when someone nearby is actively searching for your service – no wasted spend, no guessing.
                </p>
                <Button
                  onClick={() => window.location.href = '/business'}
                  size="sm"
                  className="mt-3 bg-amber-600 hover:bg-amber-700 text-white"
                >
                  Get Featured Today
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}