import { useState, useRef, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
// Image functionality temporarily disabled for stability
// import { convertFileToBase64 } from "@/lib/utils";
// import { compressImage, fileToBase64, isValidImage } from "@/lib/imageUtils";
import { PriceAnalysisResult, analyzePriceWithAI } from "@/lib/anthropic";
import { trackPriceAnalysis } from "@/lib/firebaseAnalytics";
import { Camera, Loader2, UploadIcon, Smartphone, MoveRight, RefreshCcw, AlertTriangle } from "lucide-react";
import PriceResults from "./PriceResults";
import { apiRequest } from "@/lib/queryClient";

const formSchema = z.object({
  item: z.string().min(2, { message: "Please enter what you're looking for" }),
  description: z.string().optional(),
  budget: z.union([
    z.number().positive().optional(),
    z.string().optional().transform(val => val === "" ? undefined : Number(val))
  ]),
  imageFile: z.any().optional(),
  includeInstallation: z.boolean().default(false),
  location: z.string().optional()
});

type FormValues = z.infer<typeof formSchema>;

const PriceCheckForm = () => {
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [isLoadingAnimation, setIsLoadingAnimation] = useState<boolean>(false);
  // Image functionality temporarily disabled for stability
  // const [imagePreview, setImagePreview] = useState<string | null>(null);
  // const [additionalImages, setAdditionalImages] = useState<File[]>([]);
  // const [additionalImagePreviews, setAdditionalImagePreviews] = useState<string[]>([]);
  const [results, setResults] = useState<PriceAnalysisResult | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [guestId, setGuestId] = useState<string | null>(null);
  
  const { toast } = useToast();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const itemInputRef = useRef<HTMLInputElement>(null);

  // Failed search logging function
  const logFailedSearch = async (values: FormValues, error: any, errorType: string) => {
    try {
      await apiRequest("POST", "/api/failed-searches", {
        searchQuery: values.item,
        description: values.description || "",
        budget: values.budget?.toString() || "",
        location: values.location || "",
        errorType,
        errorMessage: error?.message || error?.toString() || "Unknown error",
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
        userId: user?.uid || null,
        guestId: guestId
      });
    } catch (logError) {
      console.error("Failed to log search error:", logError);
    }
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      item: "",
      description: "",
      budget: undefined,
      imageFile: undefined,
      includeInstallation: false,
      location: ""
    }
  });

  // Auto-focus input field on load
  useEffect(() => {
    if (itemInputRef.current) {
      itemInputRef.current.focus();
    }
    
    // Get or create guest ID from localStorage
    const storedGuestId = localStorage.getItem('guestId');
    if (storedGuestId) {
      setGuestId(storedGuestId);
    } else {
      const newGuestId = crypto.randomUUID();
      localStorage.setItem('guestId', newGuestId);
      setGuestId(newGuestId);
      
      // Track if guest used free credit
      localStorage.setItem('usedFreeCredit', 'false');
    }
  }, []);

  // Image upload functionality disabled for stability
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // Disabled
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      // Get the first file as the main preview
      const mainFile = e.dataTransfer.files[0];
      processFile(mainFile);
      
      // Process any additional files (up to 4 more, for a total of 5)
      if (e.dataTransfer.files.length > 1) {
        const additionalFiles = Array.from(e.dataTransfer.files).slice(1, 5);
        setAdditionalImages(additionalFiles);
        
        // Reset previous previews
        setAdditionalImagePreviews([]);
        
        // Create previews for additional images
        additionalFiles.forEach(async (file) => {
          try {
            const reader = new FileReader();
            reader.onload = () => {
              setAdditionalImagePreviews(prev => [...prev, reader.result as string]);
            };
            reader.readAsDataURL(file);
          } catch (error) {
            console.error('Error creating preview for additional image:', error);
          }
        });
        
        toast({
          title: `${additionalFiles.length + 1} images uploaded`,
          description: `Main image plus ${additionalFiles.length} additional image${additionalFiles.length > 1 ? 's' : ''}`,
        });
      }
    }
  };
  
  const processFile = async (file: File) => {
    // Check file type
    if (!isValidImage(file)) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file (JPG, PNG, WebP, GIF)",
        variant: "destructive"
      });
      return;
    }
    
    try {
      // Show loading state
      setIsLoadingAnimation(true);
      
      // Compress image to optimize for AI processing
      let processedFile = file;
      
      // Only compress if larger than 1MB
      if (file.size > 1024 * 1024) {
        processedFile = await compressImage(file, 1, 1200);
        
        // If still too large after compression
        if (processedFile.size > 5 * 1024 * 1024) {
          toast({
            title: "File too large",
            description: "Please select a smaller image (under 5MB)",
            variant: "destructive"
          });
          setIsLoadingAnimation(false);
          return;
        }
        
        toast({
          title: "Image optimized",
          description: `Compressed from ${(file.size / (1024 * 1024)).toFixed(1)}MB to ${(processedFile.size / (1024 * 1024)).toFixed(1)}MB`,
        });
      }
      
      form.setValue("imageFile", processedFile);
      
      // Create image preview
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
        setIsLoadingAnimation(false);
      };
      reader.readAsDataURL(processedFile);
    } catch (error) {
      console.error('Error processing image:', error);
      toast({
        title: "Image processing failed",
        description: "Please try a different image",
        variant: "destructive"
      });
      setIsLoadingAnimation(false);
    }
  };

  const onSubmit = async (values: FormValues) => {
    // Always allow free checks for testing
    // Remove credit check restriction for now
    
    try {
      setIsAnalyzing(true);
      setIsLoadingAnimation(true);
      
      // Display loading animation for at least 2 seconds
      setTimeout(() => {
        runAIAnalysis(values);
      }, 2000);
      
    } catch (error) {
      console.error(error);
      setIsAnalyzing(false);
      
      // Log failed search for admin monitoring
      logFailedSearch(values, error, "form_submission_error");
      
      toast({
        title: "Something went wrong",
        description: "We couldn't analyze the price. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  const runAIAnalysis = async (values: FormValues) => {
    try {
      // Convert primary image to base64 if present
      let imageBase64 = undefined;
      if (values.imageFile) {
        imageBase64 = await convertFileToBase64(values.imageFile);
      }
      
      // Prepare additional images if present
      let additionalImagesBase64 = [];
      if (additionalImages.length > 0) {
        additionalImagesBase64 = await Promise.all(
          additionalImages.map(file => convertFileToBase64(file))
        );
      }
      
      // Call AI service to analyze price with installation and location options
      const analysisResult = await analyzePriceWithAI(
        values.item,
        values.description || "",
        "", // No category needed in simplified flow
        values.budget as number | undefined,
        imageBase64,
        values.includeInstallation,
        values.location || ""
      );
      
      // Track the price analysis in both Firebase and Google Analytics
      trackPriceAnalysis(
        values.item, 
        values.description || 'general',
        values.budget as number
      );
      
      // Also track in Google Analytics directly
      if (typeof window !== 'undefined' && window.gtag) {
        window.gtag('event', 'price_check_completed', {
          event_category: 'engagement',
          event_label: values.item,
          custom_parameter_1: values.item,
          value: values.budget || 0
        });
        console.log('Price check tracked in Google Analytics:', values.item);
      }
      
      // Track in TikTok Pixel
      import('@/lib/tiktokPixel').then(({ trackPriceCheck }) => {
        trackPriceCheck(values.item, 'general');
      });
      
      // All searches are free - no credit tracking needed
      
      // Save the price check - database storage is now handled by the server
      if (user) {
        console.log("Price check saved for user:", user.uid);
      } else {
        // Also save to localStorage for local persistence
        const guestChecks = JSON.parse(localStorage.getItem('guestChecks') || '[]');
        guestChecks.push({
          item: values.item,
          timestamp: new Date().toISOString(),
          includeInstallation: values.includeInstallation,
          location: values.location || "",
          result: analysisResult
        });
        localStorage.setItem('guestChecks', JSON.stringify(guestChecks));
        console.log("Price check saved to database and localStorage for guest");
      }
      
      setResults(analysisResult);
      setIsLoadingAnimation(false);
      
    } catch (error) {
      console.error(error);
      
      // Log failed search for admin monitoring
      logFailedSearch(values, error, "ai_analysis_error");
      
      toast({
        title: "Analysis failed",
        description: "We couldn't analyze this item right now. Please try again.",
        variant: "destructive"
      });
      setIsLoadingAnimation(false);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const startNewSearch = () => {
    form.reset();
    setImagePreview(null);
    setResults(null);
    
    // Auto-focus on the input field
    setTimeout(() => {
      if (itemInputRef.current) {
        itemInputRef.current.focus();
      }
    }, 0);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {!results ? (
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
          <div className="p-6 md:p-8">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
              {isAnalyzing ? "Scanning market prices..." : "What are you looking to price check?"}
            </h2>
            
            {isLoadingAnimation ? (
              // Loading Animation
              <div className="flex flex-col items-center justify-center py-10">
                <div className="relative w-24 h-24 mb-8">
                  <div className="absolute inset-0 border-4 border-gray-200 border-t-green-500 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Smartphone className="h-10 w-10 text-green-500" />
                  </div>
                </div>
                <div className="space-y-2 text-center">
                  <p className="text-xl font-medium">Finding the best prices</p>
                  <p className="text-gray-500">Comparing online and retail stores...</p>
                </div>
              </div>
            ) : (
              // Input Form
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="item"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-lg font-medium">
                          What are you looking for? <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g. white kitchen fitted in Plymouth, carpet for living room..." 
                            className="w-full px-4 py-6 text-lg rounded-xl border-2 border-gray-200 focus:border-green-500"
                            {...field}
                            ref={field.ref}
                          />
                        </FormControl>
                        <FormDescription>
                          Text description required - we need context to provide accurate pricing
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-medium">
                            Details (optional)
                          </FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Color, size, model number..." 
                              className="min-h-[100px] rounded-xl border-2 border-gray-200 focus:border-green-500"
                              {...field}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="budget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-medium">
                            Your budget (optional)
                          </FormLabel>
                          <div className="relative">
                            <span className="absolute left-4 top-[38px] text-gray-500 text-lg">£</span>
                            <FormControl>
                              <Input 
                                type="number"
                                placeholder="0"
                                className="w-full h-[100px] pl-10 text-lg rounded-xl border-2 border-gray-200 focus:border-green-500" 
                                {...field}
                                onChange={(e) => {
                                  const value = e.target.value ? parseFloat(e.target.value) : "";
                                  field.onChange(value);
                                }}
                              />
                            </FormControl>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="includeInstallation"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border-2 border-gray-200 p-4 my-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="text-lg font-medium">
                            Include installation/fitting quotes
                          </FormLabel>
                          <FormDescription>
                            Get prices for both the product and professional installation services
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem className="mb-4">
                        <FormLabel className="text-lg font-medium">
                          Your location (for local business recommendations)
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g. Birmingham, UK or B15 2TT"
                            className="w-full text-lg rounded-xl border-2 border-gray-200 focus:border-green-500"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Enter your city or postcode to find local suppliers and installers
                        </FormDescription>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="imageFile"
                    render={() => (
                      <FormItem>
                        <FormLabel className="text-lg font-medium mb-2">
                          Add photo for enhanced results (optional)
                        </FormLabel>
                        <div 
                          className={`
                            relative 
                            border-2 
                            ${isDragging ? 'border-green-500 bg-green-50' : imagePreview ? 'border-green-500' : 'border-dashed border-gray-300'}
                            rounded-xl 
                            p-8 
                            text-center 
                            transition-all
                            cursor-pointer
                            hover:border-green-500
                            hover:bg-green-50/50
                            min-h-[200px]
                            flex
                            items-center
                            justify-center
                          `}
                          onClick={() => fileInputRef.current?.click()}
                          onDragOver={handleDragOver}
                          onDragLeave={handleDragLeave}
                          onDrop={handleDrop}
                        >
                          <input 
                            type="file"
                            ref={fileInputRef}
                            className="hidden"
                            accept="image/*"
                            onChange={handleFileChange}
                          />
                          
                          {imagePreview ? (
                            <div className="flex flex-col items-center">
                              <img 
                                src={imagePreview} 
                                alt="Preview" 
                                className="max-h-48 max-w-full rounded-lg mb-2" 
                              />
                              <p className="text-gray-500 mt-2">Tap to change photo</p>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center w-full">
                              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-4">
                                <Camera className="h-8 w-8 text-white" />
                              </div>
                              <p className="text-lg font-medium mb-2">
                                Drop your photo here or tap to browse
                              </p>
                              <p className="text-gray-500">
                                For more accurate pricing, upload a clear image
                              </p>
                            </div>
                          )}
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit"
                    className="w-full bg-green-500 hover:bg-green-600 text-white font-bold text-lg py-6 rounded-xl transition shadow-lg flex items-center justify-center"
                    disabled={isAnalyzing}
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        Check My Price
                        <MoveRight className="ml-2 h-5 w-5" />
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            )}
            
            <div className="mt-6 text-center">
              <p className="text-gray-500">
                Search for free, no sign-up required
              </p>
            </div>
          </div>
        </div>
      ) : (
        // Show results when available
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
          <PriceResults 
            results={results} 
            itemName={form.getValues().item}
            onNewSearch={startNewSearch}
          />
          
          {!user && (
            <div className="p-6 bg-green-50 border-t border-green-100">
              <div className="flex flex-col items-center text-center">
                <h3 className="text-lg font-bold text-green-800 mb-2">
                  Loved your result? Invite a friend and you both get a free credit!
                </h3>
                <div className="flex flex-wrap gap-4 justify-center mt-2">
                  <Button
                    onClick={() => window.location.href = '/signup'}
                    className="bg-green-600 hover:bg-green-700 text-white min-w-[150px]"
                  >
                    Sign Up Now
                  </Button>
                  <Button
                    onClick={startNewSearch}
                    variant="outline"
                    className="bg-white border-green-500 text-green-500 hover:bg-green-50 min-w-[150px]"
                  >
                    <RefreshCcw className="mr-2 h-4 w-4" />
                    Try Another
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PriceCheckForm;
