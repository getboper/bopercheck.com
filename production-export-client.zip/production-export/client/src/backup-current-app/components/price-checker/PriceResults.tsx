import { useState, useEffect, lazy, Suspense } from "react";
import { formatCurrency, generatePDF, getDealBadgeColor, getDealLabel, generateStars, convertRatingToNumber } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { PriceAnalysisResult } from "@/lib/anthropic";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "@/hooks/use-location";
import { BusinessSignupCTA } from "@/components/business/BusinessSignupCTA";
import { apiRequest } from "@/lib/queryClient";
import ViralCTA from "@/components/viral/ViralCTA";
import { trackViralShare } from "@/lib/tiktokPixel";

const VoucherValidationStatus = lazy(() => import("@/components/VoucherValidationStatus"));
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Star, 
  StarHalf, 
  Download, 
  Share2, 
  Mail, 
  ExternalLink, 
  ShoppingBag, 
  Tag, 
  TrendingDown, 
  RefreshCw,
  MapPin,
  Info,
  X,
  Megaphone,
  Target,
  Users
} from "lucide-react";

interface PriceResultsProps {
  results: PriceAnalysisResult;
  itemName: string;
  onNewSearch: () => void;
}

const PriceResults = ({ results, itemName, onNewSearch }: PriceResultsProps) => {
  const { 
    marketValue, 
    averagePrice, 
    lowestPrice, 
    priceRange, 
    dealRating, 
    stores, 
    currency,
    analysis,
    installation,
    localBusinesses,
    productImages,
    secondHandOptions,
    discounts,
    vouchers,
    installerInfo
  } = results;

  const { user } = useAuth();
  const { toast } = useToast();
  const { city, region, country, loading: locationLoading } = useLocation();
  const dealBadgeColor = getDealBadgeColor(dealRating);
  const dealLabel = getDealLabel(dealRating);
  const numericRating = convertRatingToNumber(dealRating);
  const stars = generateStars(numericRating);

  const handleDownload = () => {
    try {
      generatePDF({
        itemName,
        results,
        date: new Date().toLocaleDateString()
      });
      
      // Track PDF download in TikTok Pixel
      import('@/lib/tiktokPixel').then(({ trackPDFDownload }) => {
        trackPDFDownload(itemName);
      });
      
      toast({
        title: "PDF Generated",
        description: "Your price analysis PDF has been downloaded!",
      });
    } catch (error) {
      console.error("PDF generation error:", error);
      toast({
        title: "Download Failed",
        description: "Could not generate PDF. Please try again.",
        variant: "destructive"
      });
    }
  };

  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [emailAddress, setEmailAddress] = useState("");
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [showRatingDialog, setShowRatingDialog] = useState(false);
  const [userRating, setUserRating] = useState(0);
  const [userReview, setUserReview] = useState("");
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);
  const [showAdvertiserCTA, setShowAdvertiserCTA] = useState(true);
  const [searchRating, setSearchRating] = useState(0);
  const [hasRatedSearch, setHasRatedSearch] = useState(false);
  const [showThankYou, setShowThankYou] = useState(false);
  
  const handleSearchRating = (rating: number) => {
    setSearchRating(rating);
    setHasRatedSearch(true);
    toast({
      title: "Thank you!",
      description: "Your rating helps us improve our search results.",
    });
  };

  const handleRatingSubmit = async () => {
    if (userRating === 0) {
      toast({
        title: "Rating Required",
        description: "Please select a star rating before submitting.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmittingRating(true);
    try {
      const response = await apiRequest("POST", "/api/submit-rating", {
        rating: userRating,
        review: userReview,
        itemName: itemName,
        searchQuery: itemName
      });

      if (response.ok) {
        // Show thank you message first
        setShowThankYou(true);
        
        // Hide the rating dialog after a short delay
        setTimeout(() => {
          setShowRatingDialog(false);
          setShowThankYou(false);
          setUserRating(0);
          setUserReview("");
        }, 2500);
        
        toast({
          title: "🎉 Thank You!",
          description: "Your rating helps us improve BoperCheck for everyone!",
        });
      } else {
        throw new Error("Failed to submit rating");
      }
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "Unable to submit your rating. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmittingRating(false);
    }
  };
  
  const handleVoucherDownload = async (discount: any) => {
    try {
      // Show payment confirmation dialog
      const paymentConfirmed = window.confirm(
        `Premium Feature: Download ${discount.store} voucher for £0.99?\n\nIncludes:\n• Exclusive discount codes\n• Verified voucher access\n• Priority customer support\n\nClick OK to proceed to secure checkout.`
      );
      
      if (!paymentConfirmed) {
        return;
      }
      
      // Redirect to Stripe checkout page
      const checkoutUrl = `/voucher-checkout?store=${encodeURIComponent(discount.store)}&code=${encodeURIComponent(discount.code)}&discount=${encodeURIComponent(discount.discount)}&item=${encodeURIComponent(itemName)}`;
      
      window.location.href = checkoutUrl;
    } catch (error) {
      console.error("Voucher checkout error:", error);
      toast({
        title: "Checkout Error",
        description: "Unable to proceed to checkout. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  const handleEmailResults = () => {
    // Show email dialog instead of requiring sign-up
    setShowEmailDialog(true);
  };
  
  const sendEmail = () => {
    if (!emailAddress || !emailAddress.includes('@')) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive"
      });
      return;
    }
    
    setIsSendingEmail(true);
    
    // In a real implementation, this would call an API endpoint
    setTimeout(() => {
      setIsSendingEmail(false);
      setShowEmailDialog(false);
      
      toast({
        title: "Results Emailed",
        description: `We've sent this analysis to ${emailAddress}!`,
      });
      
      // Clear email after sending
      setEmailAddress("");
    }, 1000);
  };

  const handleShare = () => {
    // Track viral sharing
    trackViralShare('native_share', 'price_result', itemName);
    
    if (navigator.share) {
      navigator.share({
        title: `BoperCheck Price Analysis: ${itemName}`,
        text: `I found ${itemName} for ${formatCurrency(lowestPrice, currency)}! Check out my BoperCheck price analysis.`,
        url: window.location.href,
      }).catch(err => {
        console.log('Error sharing:', err);
        handleCopyLink();
      });
    } else {
      handleCopyLink();
    }
  };
  
  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href)
      .then(() => {
        toast({
          title: "Link Copied",
          description: "Share link copied to clipboard!",
        });
      })
      .catch(() => {
        toast({
          title: "Copy Failed",
          description: "Couldn't copy link to clipboard.",
          variant: "destructive"
        });
      });
  };

  const getPriceDifferencePercent = () => {
    if (!marketValue || !lowestPrice || marketValue <= 0 || lowestPrice <= 0 || isNaN(marketValue) || isNaN(lowestPrice)) {
      return 0;
    }
    const percentage = Math.round(((marketValue - lowestPrice) / marketValue) * 100);
    return isNaN(percentage) ? 0 : Math.max(0, percentage);
  };

  return (
    <div className="p-6 md:p-8">
      {/* Advertiser CTA Popup - Prominent placement */}
      {showAdvertiserCTA && (
        <Card className="mb-6 border-2 border-blue-500 bg-gradient-to-r from-blue-50 to-purple-50 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3 flex-1">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Megaphone className="h-5 w-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-blue-900 mb-1">Want YOUR business featured here?</h3>
                  <p className="text-sm text-blue-800 mb-2">
                    Thousands of users see these search results daily. <strong>Advertise your products right here!</strong>
                  </p>
                  <div className="flex items-center gap-4 text-xs text-blue-700">
                    <span className="flex items-center gap-1">
                      <Target className="h-3 w-3" />
                      Targeted audience
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      High-intent shoppers
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  size="sm" 
                  className="bg-blue-600 hover:bg-blue-700 text-white font-medium"
                  onClick={() => window.open('/business', '_blank')}
                >
                  Advertise Here
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => setShowAdvertiserCTA(false)}
                  className="text-blue-600 hover:text-blue-800"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Title and Success Icon */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center rounded-full bg-green-500 p-4 mb-4">
          <svg className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h2 className="text-2xl md:text-3xl font-bold mb-2">Price Check Complete</h2>
        <p className="text-gray-600 text-lg">
          Results for <span className="font-medium">{itemName}</span>
        </p>
        
        {/* Search Result Rating */}
        <div className="mt-4 p-4 bg-gray-50 rounded-lg border">
          <div className="flex items-center justify-center gap-4">
            <span className="text-sm font-medium text-gray-700">Rate this search result:</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  onClick={() => handleSearchRating(rating)}
                  className={`p-1 transition-colors ${
                    searchRating >= rating || (!hasRatedSearch && rating <= 4)
                      ? 'text-yellow-400 hover:text-yellow-500' 
                      : 'text-gray-300 hover:text-yellow-300'
                  }`}
                  disabled={hasRatedSearch}
                >
                  <Star className={`h-5 w-5 ${searchRating >= rating ? 'fill-current' : ''}`} />
                </button>
              ))}
            </div>
            {hasRatedSearch && (
              <span className="text-sm text-green-600 font-medium">Thank you!</span>
            )}
          </div>
        </div>
      </div>
      
      {/* Deal Rating Highlight */}
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6 mb-8 shadow-md border border-gray-100">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center mb-2">
              <h3 className="text-xl font-bold text-gray-800 mr-3">Deal Rating</h3>
              <span className={`px-4 py-2 rounded-full text-white text-lg font-bold shadow-lg ${dealBadgeColor} border-2 border-white`}>
                {dealLabel}
              </span>
            </div>
            <div className="flex mb-2">
              {Array.from({ length: stars.full }).map((_, i) => (
                <Star key={`full-${i}`} className="h-6 w-6 text-yellow-400 fill-current" />
              ))}
              {stars.half > 0 && (
                <StarHalf className="h-6 w-6 text-yellow-400 fill-current" />
              )}
              {Array.from({ length: stars.empty }).map((_, i) => (
                <Star key={`empty-${i}`} className="h-6 w-6 text-gray-300" />
              ))}
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-3xl font-bold text-green-600">{formatCurrency(lowestPrice, currency)}</div>
            <div className="text-sm text-gray-500">Lowest price available</div>
            {stores && stores.length > 0 && (
              <div className="text-xs text-gray-400 mt-1">
                from {stores.find(s => s.price === lowestPrice)?.name || 'store'}
              </div>
            )}
          </div>
        </div>
        
        {/* Price Analysis Summary */}
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col items-center p-3 rounded-lg bg-blue-50">
              <Tag className="text-blue-600 mb-2" />
              <div className="text-xl font-bold text-gray-800">{formatCurrency(marketValue, currency)}</div>
              <div className="text-xs text-gray-500">Market Value</div>
            </div>
            
            <div className="flex flex-col items-center p-3 rounded-lg bg-purple-50">
              <ShoppingBag className="text-purple-600 mb-2" />
              <div className="text-xl font-bold text-gray-800">{formatCurrency(averagePrice, currency)}</div>
              <div className="text-xs text-gray-500">Average Price</div>
            </div>
            
            <div className="flex flex-col items-center p-3 rounded-lg bg-green-50">
              <TrendingDown className="text-green-600 mb-2" />
              <div className="text-xl font-bold text-green-600">
                Save {getPriceDifferencePercent()}%
              </div>
              <div className="text-xs text-gray-500">Potential Savings</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Discount Codes with Validation or No Discounts Message */}
      {(vouchers && vouchers.length > 0) || (discounts && discounts.length > 0) ? (
        <div className="mb-8">
          <h3 className="font-bold text-xl mb-4 flex items-center">
            <svg className="h-5 w-5 mr-2 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
            </svg>
            Verified Discount Codes
          </h3>
          
          {/* Voucher Validation Status */}
          <Suspense fallback={
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
              <div className="animate-pulse flex space-x-4">
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            </div>
          }>
            <VoucherValidationStatus vouchers={(vouchers || discounts || []).map((voucher: any) => ({
              store: voucher.store || 'General',
              code: voucher.code,
              discount: voucher.discount,
              description: voucher.description,
              expiryDate: voucher.expiryDate || '',
              minSpend: voucher.minSpend || 0
            }))} />
          </Suspense>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(vouchers || discounts || []).map((discount: any, index: number) => (
              <div key={index} className="bg-gradient-to-r from-red-50 to-pink-50 rounded-xl p-4 border border-red-200">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-gray-800">{discount.store || 'General Discount'}</h4>
                  <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                    {discount.discount}
                  </span>
                </div>
                <div className="bg-white rounded px-3 py-2 mb-2 font-mono text-lg font-bold text-center border-2 border-dashed border-red-300">
                  {discount.code}
                </div>
                <p className="text-sm text-gray-600 mb-2">{discount.description}</p>
                <div className="flex justify-between items-center text-xs text-gray-500 mb-2">
                  {discount.minSpend && <span>Min spend: {formatCurrency(discount.minSpend, currency)}</span>}
                  {discount.expiryDate && <span>Expires: {discount.expiryDate}</span>}
                </div>
                <Button
                  onClick={() => handleVoucherDownload(discount)}
                  size="sm"
                  className="w-full bg-red-500 hover:bg-red-600 text-white"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Voucher (£0.99)
                </Button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="mb-8">
          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 border-2 border-dashed border-orange-200 rounded-xl p-6 text-center">
            <div className="text-4xl mb-3">😫</div>
            <h3 className="font-bold text-xl text-orange-800 mb-2">Oh no... no discount offers found!</h3>
            <p className="text-orange-700 mb-3">
              Our AI couldn't find any active voucher codes or special offers for this search.
            </p>
            <p className="text-sm text-orange-600">
              Don't worry - the prices above are still great deals! Check back later as new offers appear daily.
            </p>
          </div>
        </div>
      )}

      {/* Analysis Explanation */}
      <div className="mb-8 bg-white rounded-xl p-6 shadow-md border border-gray-100">
        <h3 className="font-bold text-xl mb-3 flex items-center">
          <Info className="w-5 h-5 mr-2 text-blue-500" />
          Price Analysis
        </h3>
        <p className="text-gray-600 mb-4">{analysis}</p>
        <div className="flex flex-wrap gap-2">
          <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
            Price Range: {priceRange ? `${formatCurrency(priceRange.min, currency)} - ${formatCurrency(priceRange.max, currency)}` : 'Contact for quotes'}
          </span>
        </div>
      </div>
      
      {/* Where to Buy */}
      <div className="mb-8">
        <h3 className="font-bold text-xl mb-4 flex items-center">
          <ShoppingBag className="h-5 w-5 mr-2 text-green-500" />
          Where to Buy ({stores?.length || 0} stores found)
        </h3>
        {!stores || stores.length === 0 ? (
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
            <p className="text-yellow-800">No store information available for this search.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {stores.map((store, index) => (
            <div key={index} className="border border-gray-200 hover:border-green-400 rounded-xl p-4 flex justify-between items-center transition-all shadow-sm hover:shadow">
              <div>
                <h4 className="font-bold text-gray-800">{store.name}</h4>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    (store.notes || '').toLowerCase().includes('installation') ||
                    (store.notes || '').toLowerCase().includes('fitting') ||
                    (store.notes || '').toLowerCase().includes('installer')
                    ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {(store.notes || '').toLowerCase().includes('installation') ||
                     (store.notes || '').toLowerCase().includes('fitting') ||
                     (store.notes || '').toLowerCase().includes('installer')
                     ? 'Installation Service' : 'Supplier'}
                  </span>
                  {(store.notes || '').toLowerCase().includes('local') && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-800">
                      Local Business
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600">{store.notes}</p>
              </div>
              <div className="text-right">
                <div className="mb-1">
                  {store.originalPrice && store.originalPrice > store.price && (
                    <p className="text-sm text-gray-400 line-through">
                      {formatCurrency(store.originalPrice, currency)}
                    </p>
                  )}
                  <p className={`font-bold text-lg ${store.price === lowestPrice ? 'text-green-600' : 'text-gray-800'}`}>
                    {formatCurrency(store.price, currency)}
                    {store.price === lowestPrice && (
                      <span className="text-xs ml-2 bg-green-100 text-green-800 px-2 py-1 rounded-full">
                        LOWEST PRICE
                      </span>
                    )}
                  </p>
                  {store.discountCode && (
                    <p className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded mt-1">
                      Code: {store.discountCode}
                    </p>
                  )}
                </div>
                <a 
                  href={store.link} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-sm text-blue-600 hover:text-blue-800 flex items-center justify-end mt-1 hover:underline"
                >
                  Go to Store <ExternalLink className="ml-1 h-3 w-3" />
                </a>
              </div>
            </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Second-Hand Options */}
      {secondHandOptions && secondHandOptions.length > 0 && (
        <div className="mb-8">
          <h3 className="font-bold text-xl mb-4 flex items-center">
            <svg className="h-5 w-5 mr-2 text-orange-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Second-Hand & Marketplace Options
          </h3>
          <div className="space-y-4">
            {secondHandOptions.map((option, index) => (
              <div key={index} className="border border-orange-200 hover:border-orange-400 rounded-xl p-4 bg-orange-50 transition-all shadow-sm hover:shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-gray-800">{option.platform}</h4>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-orange-100 text-orange-800">
                        {option.condition} Condition
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{option.notes}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Range: {option.priceRange ? `${formatCurrency(option.priceRange.min, currency)} - ${formatCurrency(option.priceRange.max, currency)}` : 'Contact for pricing'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg text-orange-600">
                      {formatCurrency(option.averagePrice, currency)}
                    </p>
                    <p className="text-xs text-gray-500">Average price</p>
                    <a 
                      href={option.link} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center justify-end mt-1 hover:underline"
                    >
                      Browse <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Button 
          variant="outline" 
          onClick={handleDownload}
          className="bg-white hover:bg-gray-50 border border-gray-200 text-gray-800 py-6 rounded-xl flex items-center justify-center shadow-sm"
        >
          <Download className="mr-2 h-5 w-5 text-green-600" /> 
          Download PDF
        </Button>
        
        <Button 
          variant="outline"
          onClick={handleEmailResults}
          className="bg-white hover:bg-gray-50 border border-gray-200 text-gray-800 py-6 rounded-xl flex items-center justify-center shadow-sm"
        >
          <Mail className="mr-2 h-5 w-5 text-blue-600" /> 
          Email Results
        </Button>
        
        <Button 
          onClick={onNewSearch}
          className="bg-green-500 hover:bg-green-600 text-white py-6 rounded-xl flex items-center justify-center shadow-md"
        >
          <RefreshCw className="mr-2 h-5 w-5" /> 
          Check Another Price
        </Button>
        
        <Button 
          onClick={() => setShowRatingDialog(true)}
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-6 rounded-xl flex items-center justify-center shadow-lg animate-pulse border-2 border-purple-300"
        >
          <Star className="mr-2 h-5 w-5 text-white animate-bounce" />
          Rate & Review
        </Button>
      </div>
      
      {/* Installer Information Section */}
      {installerInfo && installerInfo.localInstallers && (
        <div className="mb-8">
          <h3 className="font-bold text-xl mb-4 flex items-center">
            <svg className="h-5 w-5 mr-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Local Installation Services
          </h3>
          
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 mb-6 border border-blue-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{installerInfo.diyDifficulty}</div>
                <div className="text-sm text-gray-600">Difficulty Level</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{installerInfo.estimatedTime}</div>
                <div className="text-sm text-gray-600">Installation Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{installerInfo.localInstallers.length} Found</div>
                <div className="text-sm text-gray-600">Local Professionals</div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {installerInfo.localInstallers.map((installer, index) => (
              <div key={index} className="bg-white border border-gray-200 hover:border-blue-400 rounded-xl p-6 transition-all shadow-sm hover:shadow-md">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="font-bold text-lg text-gray-800">{installer.name}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium ml-1">{installer.rating.toFixed(1)}</span>
                      </div>
                      <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded">
                        {installer.certification}
                      </span>
                      <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded">
                        {installer.experience}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-blue-600">{installer.priceRange}</div>
                    <div className="text-sm text-gray-500">Installation Cost</div>
                  </div>
                </div>
                
                <div className="mb-3">
                  <h5 className="font-semibold text-gray-700 mb-2">Services Offered:</h5>
                  <div className="flex flex-wrap gap-2">
                    {installer.services.map((service, serviceIndex) => (
                      <span key={serviceIndex} className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">
                        {service}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="text-sm text-blue-600 font-medium">
                    📞 {installer.phone}
                  </div>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                    Contact Installer
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          {installerInfo.installationSteps && (
            <div className="mt-6 bg-gray-50 rounded-xl p-6">
              <h4 className="font-bold text-lg mb-3">Installation Process:</h4>
              <ol className="space-y-2">
                {installerInfo.installationSteps.map((step, index) => (
                  <li key={index} className="flex items-start">
                    <span className="bg-blue-600 text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center mr-3 mt-0.5">
                      {index + 1}
                    </span>
                    <span className="text-gray-700">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>
      )}

      {/* Installation Section */}
      {installation && (
        <div className="mb-8">
          <h3 className="font-bold text-xl mb-4 flex items-center">
            <svg className="h-5 w-5 mr-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Installation & Fitting
          </h3>
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="flex flex-col items-center p-3 rounded-lg bg-blue-50">
                <div className="text-xl font-bold text-gray-800">
                  {installation.averageCost && installation.averageCost > 0 ? 
                    formatCurrency(installation.averageCost, currency) : 
                    'Varies by project'
                  }
                </div>
                <div className="text-xs text-gray-500">Average Installation Cost</div>
              </div>
              
              <div className="flex flex-col items-center p-3 rounded-lg bg-purple-50">
                <div className="text-xl font-bold text-gray-800">
                  {installation.costRange && installation.costRange.min > 0 && installation.costRange.max > 0 ? 
                    `${formatCurrency(installation.costRange.min, currency)} - ${formatCurrency(installation.costRange.max, currency)}` :
                    'Request quotes'
                  }
                </div>
                <div className="text-xs text-gray-500">Price Range</div>
              </div>
              
              <div className="flex flex-col items-center p-3 rounded-lg bg-green-50">
                <div className="text-xl font-bold text-gray-800">
                  {installation.timeEstimate || 'Same day possible'}
                </div>
                <div className="text-xs text-gray-500">Time Estimate</div>
              </div>
            </div>
            
            <div className="mb-3">
              <div className="flex items-center mb-2">
                <h4 className="font-semibold">Difficulty Level:</h4>
                <span className={`ml-2 px-2 py-0.5 rounded-full text-sm ${
                  (installation.difficultyLevel || '').toLowerCase().includes('easy') ? 'bg-green-100 text-green-800' :
                  (installation.difficultyLevel || '').toLowerCase().includes('moderate') ? 'bg-yellow-100 text-yellow-800' :
                  (installation.difficultyLevel || '').toLowerCase().includes('difficult') ? 'bg-orange-100 text-orange-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {installation.difficultyLevel || 'Unknown'}
                </span>
              </div>
              <p className="text-gray-600">{installation.notes || ''}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Local Business Recommendations */}
      {localBusinesses && localBusinesses.length > 0 && (
        <div className="mb-8">
          <h3 className="font-bold text-xl mb-4 flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-green-500" />
            Local Business Recommendations
          </h3>
          
          <div className="space-y-4">
            {localBusinesses.map((business, index) => (
              <div key={index} className="border border-gray-200 hover:border-green-400 rounded-xl p-4 transition-all shadow-sm hover:shadow">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-gray-800">{business.name || 'Business'}</h4>
                  <div className="flex items-center">
                    {business.rating && (
                      <div className="flex items-center bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded mr-2">
                        <Star className="h-3 w-3 mr-1 fill-current" />
                        {business.rating.toFixed(1)}
                      </div>
                    )}
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      (business.serviceType || '').toLowerCase().includes('both') ? 'bg-purple-100 text-purple-800' :
                      (business.serviceType || '').toLowerCase().includes('installer') ? 'bg-blue-100 text-blue-800' :
                      'bg-amber-100 text-amber-800'
                    }`}>
                      {business.serviceType || 'Service Provider'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-start mb-2">
                  <MapPin className="h-4 w-4 text-gray-500 mt-0.5 mr-1 flex-shrink-0" />
                  <p className="text-sm text-gray-600">{business.location || 'Location not specified'} {business.distance && `(${business.distance})`}</p>
                </div>
                
                <p className="text-sm text-gray-600 mb-2">{business.notes || ''}</p>
                
                {/* Installation Pricing Section */}
                {(business.installationPrice || business.installationPriceRange) && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-2">
                    <h5 className="font-semibold text-blue-900 text-sm mb-1">Installation/Fitting Charges</h5>
                    {business.installationPrice ? (
                      <div className="text-lg font-bold text-blue-700">
                        {formatCurrency(business.installationPrice, currency)}
                        {business.suppliesIncluded && (
                          <span className="text-xs ml-2 bg-green-100 text-green-800 px-2 py-1 rounded">
                            Materials Included
                          </span>
                        )}
                      </div>
                    ) : business.installationPriceRange && (
                      <div className="text-lg font-bold text-blue-700">
                        {business.installationPriceRange && business.installationPriceRange.min > 0 && business.installationPriceRange.max > 0 ? 
                          `${formatCurrency(business.installationPriceRange.min, currency)} - ${formatCurrency(business.installationPriceRange.max, currency)}` : 
                          'Call for estimate'
                        }
                        {business.suppliesIncluded && (
                          <span className="text-xs ml-2 bg-green-100 text-green-800 px-2 py-1 rounded">
                            Materials Included
                          </span>
                        )}
                      </div>
                    )}
                    <p className="text-xs text-blue-600 mt-1">
                      Contact for detailed quote and availability
                    </p>
                  </div>
                )}
                
                <div className="text-sm text-blue-600 space-y-1">
                  {typeof business.contactInfo === 'string' ? (
                    business.contactInfo
                  ) : (
                    <>
                      {business.contactInfo?.phone && (
                        <div>Phone: {business.contactInfo.phone}</div>
                      )}
                      {business.contactInfo?.website && (
                        <div>Website: {business.contactInfo.website}</div>
                      )}
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4 text-sm text-gray-500 italic">
            Local business data is provided as a convenience only. We recommend contacting businesses directly to confirm availability, pricing, and services.
          </div>
        </div>
      )}
      

      
      {/* Business Signup CTA */}
      <BusinessSignupCTA 
        itemType={itemName.split(' ')[0]} 
        category={results.analysis?.toLowerCase().includes('electronics') ? 'electronics' : 
                 results.analysis?.toLowerCase().includes('furniture') ? 'furniture' : 
                 results.analysis?.toLowerCase().includes('clothing') ? 'clothing' : undefined} 
      />
      
      {/* Share Section */}
      <div className="text-center mt-8 mb-6">
        <Button
          variant="ghost"
          onClick={handleShare}
          className="text-blue-600 hover:text-blue-800 hover:bg-blue-50 flex items-center mx-auto"
        >
          <Share2 className="mr-2 h-4 w-4" /> 
          Share these results
        </Button>
      </div>
      
      {/* Email Dialog */}
      <Dialog open={showEmailDialog} onOpenChange={setShowEmailDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Email Price Check Results</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={emailAddress}
                onChange={(e) => setEmailAddress(e.target.value)}
              />
            </div>
            <div>
              <p className="text-sm text-gray-500">
                We'll send the complete price analysis for <span className="font-medium">{itemName}</span> to this email address.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setShowEmailDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={sendEmail}
              className="bg-green-500 hover:bg-green-600 text-white"
              disabled={isSendingEmail}
            >
              {isSendingEmail ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                'Send Email'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rating Dialog */}
      <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
        <DialogContent className="sm:max-w-md">
          {showThankYou ? (
            // Thank You Screen
            <div className="text-center py-8">
              <div className="mb-6">
                <div className="inline-flex items-center justify-center rounded-full bg-green-100 p-4 mb-4 animate-bounce">
                  <svg className="h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h2>
                <p className="text-gray-600 mb-4">
                  Your feedback helps us make BoperCheck better for everyone.
                </p>
                <div className="flex justify-center mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-6 h-6 ${
                        star <= userRating
                          ? 'text-yellow-400 fill-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <div className="text-lg font-semibold text-green-600 animate-pulse">
                  Rating submitted successfully!
                </div>
              </div>
            </div>
          ) : (
            // Rating Form
            <>
              <DialogHeader>
                <DialogTitle>Rate Your Experience</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>How satisfied were you with your price analysis?</Label>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setUserRating(star)}
                        className="focus:outline-none transition-colors"
                      >
                        <Star
                          className={`w-8 h-8 ${
                            star <= userRating
                              ? 'text-yellow-400 fill-yellow-400'
                              : 'text-gray-300 hover:text-yellow-200'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="review">Tell us about your experience (Optional)</Label>
                  <Textarea
                    id="review"
                    value={userReview}
                    onChange={(e) => setUserReview(e.target.value)}
                    placeholder="Your feedback helps us improve..."
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="ghost"
                  onClick={() => setShowRatingDialog(false)}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleRatingSubmit}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white"
                  disabled={isSubmittingRating}
                >
                  {isSubmittingRating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    'Submit Rating'
                  )}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PriceResults;