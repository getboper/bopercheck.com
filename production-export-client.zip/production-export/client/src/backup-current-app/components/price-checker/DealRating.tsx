import { Star, StarHalf } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn, getDealBadgeColor, getDealLabel } from "@/lib/utils";

interface DealRatingProps {
  rating: number; // 1-5 scale
  showLabel?: boolean;
  showStars?: boolean;
  size?: "sm" | "md" | "lg";
  variant?: "badge" | "stars" | "both";
}

export function DealRating({ 
  rating, 
  showLabel = true, 
  showStars = true,
  size = "md",
  variant = "both"
}: DealRatingProps) {
  // For a 1-5 rating, determine full and half stars
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  // Determine star size based on prop
  const starSize = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-6 h-6"
  }[size];

  // Get deal label (text description) and color
  const dealLabel = getDealLabel(rating);
  const badgeColor = getDealBadgeColor(rating);

  return (
    <div className="flex items-center gap-2">
      {(variant === "stars" || variant === "both") && showStars && (
        <div className="flex">
          {[...Array(fullStars)].map((_, i) => (
            <Star key={`full-${i}`} className={cn("text-yellow-400 fill-yellow-400", starSize)} />
          ))}
          {hasHalfStar && (
            <StarHalf className={cn("text-yellow-400 fill-yellow-400", starSize)} />
          )}
          {[...Array(emptyStars)].map((_, i) => (
            <Star key={`empty-${i}`} className={cn("text-gray-200", starSize)} />
          ))}
        </div>
      )}
      
      {(variant === "badge" || variant === "both") && showLabel && (
        <Badge className={cn("font-medium", badgeColor)}>
          {dealLabel}
        </Badge>
      )}
    </div>
  );
}