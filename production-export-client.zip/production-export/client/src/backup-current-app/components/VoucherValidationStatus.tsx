import React, { useState, useEffect } from 'react';
import { CheckCircle, AlertTriangle, Shield, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface VoucherValidation {
  isValid: boolean;
  store: string;
  code: string;
  discount: string;
  description: string;
  expiryDate: string;
  minSpend: number;
  maxUses: number | null;
  eligibilityCriteria: string;
  termsConditions: string;
  lastValidated: string;
  validationSource: 'retailer_api' | 'affiliate_network' | 'manual_verification';
}

interface VoucherValidationStatusProps {
  vouchers: Array<{
    store: string;
    code: string;
    discount: string;
    description: string;
    expiryDate: string;
    minSpend: number;
  }>;
}

export default function VoucherValidationStatus({ vouchers }: VoucherValidationStatusProps) {
  const [validationResults, setValidationResults] = useState<VoucherValidation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const validateVouchers = async () => {
      try {
        const validations = await Promise.all(
          vouchers.map(async (voucher) => {
            try {
              const response = await fetch('/api/validate-voucher', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ store: voucher.store, code: voucher.code })
              });
              const result = await response.json();
              // Ensure validation object has required properties
              if (!result.validation || typeof result.validation !== 'object') {
                return {
                  isValid: false,
                  store: voucher.store,
                  code: voucher.code,
                  discount: voucher.discount || '',
                  description: 'Validation failed',
                  expiryDate: voucher.expiryDate || '',
                  minSpend: voucher.minSpend || 0,
                  maxUses: null,
                  eligibilityCriteria: '',
                  termsConditions: '',
                  lastValidated: new Date().toISOString(),
                  validationSource: 'manual_verification' as const
                };
              }
              return result.validation;
            } catch (error) {
              console.error(`Voucher validation failed for ${voucher.store}:`, error);
              return {
                isValid: false,
                store: voucher.store,
                code: voucher.code,
                discount: voucher.discount || '',
                description: 'Validation error',
                expiryDate: voucher.expiryDate || '',
                minSpend: voucher.minSpend || 0,
                maxUses: null,
                eligibilityCriteria: '',
                termsConditions: '',
                lastValidated: new Date().toISOString(),
                validationSource: 'manual_verification' as const
              };
            }
          })
        );
        setValidationResults(validations.filter(v => v !== null));
      } catch (error) {
        console.error('Voucher validation error:', error);
      } finally {
        setLoading(false);
      }
    };

    if (vouchers.length > 0) {
      validateVouchers();
    } else {
      setLoading(false);
    }
  }, [vouchers]);

  if (loading) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-500" />
            Validating Voucher Codes...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse flex space-x-4">
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const validVouchers = validationResults.filter(v => v && v.isValid === true);

  // Don't render the component if there are no valid vouchers
  if (validVouchers.length === 0) {
    return null;
  }

  return (
    <Card className="mb-6 border-l-4 border-l-green-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-green-500" />
          Active Discount Codes
          <Badge variant="outline" className="ml-2">
            {validVouchers.length} verified
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <h4 className="font-semibold text-green-700 mb-3 flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            Available Discounts ({validVouchers.length})
          </h4>
            <div className="space-y-3">
              {validVouchers.map((voucher, index) => (
                <div key={index} className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <span className="font-medium text-green-800">{voucher.store}</span>
                      <span className="ml-2 text-sm bg-green-100 text-green-700 px-2 py-1 rounded font-mono">
                        {voucher.code}
                      </span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {voucher.discount}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <p className="text-green-700 font-medium">{voucher.description}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                      <div className="bg-white rounded p-2 border border-green-100">
                        <span className="text-xs text-gray-500 uppercase tracking-wide">Eligibility</span>
                        <p className="text-green-800 text-xs mt-1">{voucher.eligibilityCriteria}</p>
                      </div>
                      
                      <div className="bg-white rounded p-2 border border-green-100">
                        <span className="text-xs text-gray-500 uppercase tracking-wide">Expires</span>
                        <p className="text-green-800 text-xs mt-1 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(voucher.expiryDate).toLocaleDateString('en-GB')}
                        </p>
                      </div>
                      
                      {voucher.minSpend > 0 && (
                        <div className="bg-white rounded p-2 border border-green-100">
                          <span className="text-xs text-gray-500 uppercase tracking-wide">Minimum Spend</span>
                          <p className="text-green-800 text-xs mt-1">£{voucher.minSpend}</p>
                        </div>
                      )}
                      
                      {voucher.maxUses && (
                        <div className="bg-white rounded p-2 border border-green-100">
                          <span className="text-xs text-gray-500 uppercase tracking-wide">Usage Limit</span>
                          <p className="text-green-800 text-xs mt-1">{voucher.maxUses} use{voucher.maxUses !== 1 ? 's' : ''} per customer</p>
                        </div>
                      )}
                    </div>
                    
                    {voucher.termsConditions && (
                      <div className="bg-white rounded p-2 border border-green-100 mt-3">
                        <span className="text-xs text-gray-500 uppercase tracking-wide">Terms & Conditions</span>
                        <p className="text-green-800 text-xs mt-1 leading-relaxed">{voucher.termsConditions}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-3 pt-2 border-t border-green-200 flex justify-between items-center text-xs text-green-600">
                    <span className="flex items-center gap-1">
                      <Shield className="h-3 w-3" />
                      Verified Source: {voucher.validationSource.replace('_', ' ')}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Verified: {new Date(voucher.lastValidated).toLocaleDateString('en-GB')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
          <h4 className="font-semibold text-blue-700 mb-2">Validation Process</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Codes verified against retailer databases</li>
            <li>• Manual verification for accuracy</li>
            <li>• Regular updates to ensure validity</li>
            <li>• Complete terms and eligibility criteria included</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}