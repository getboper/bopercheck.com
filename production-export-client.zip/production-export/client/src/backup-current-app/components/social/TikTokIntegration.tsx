import React from 'react';
import { Button } from '@/components/ui/button';
import { trackEngagement, trackViralShare, trackSocialProof } from '@/lib/tiktokPixel';

interface TikTokShareButtonProps {
  url: string;
  text: string;
  className?: string;
}

// Multi-platform viral sharing component
export const ViralShareButtons: React.FC<{ 
  url: string; 
  text: string; 
  itemName?: string;
  className?: string;
}> = ({ url, text, itemName, className = "" }) => {
  const handleShare = (platform: string) => {
    trackViralShare(platform, 'savings_deal', itemName);
    
    const shareText = `${text} ${url}`;
    
    switch (platform) {
      case 'tiktok':
        // Copy content for TikTok
        if (navigator.clipboard) {
          navigator.clipboard.writeText(shareText).then(() => {
            alert('Content copied! Create a TikTok video about your savings!');
          });
        }
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`, '_blank');
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank');
        break;
      case 'telegram':
        window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
        break;
      default:
        if (navigator.share) {
          navigator.share({ title: 'BoperCheck Savings', text, url });
        }
    }
  };

  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      <Button 
        onClick={() => handleShare('tiktok')}
        className="bg-black hover:bg-gray-800 text-white text-xs px-3 py-1"
      >
        📱 TikTok
      </Button>
      <Button 
        onClick={() => handleShare('twitter')}
        className="bg-blue-500 hover:bg-blue-600 text-white text-xs px-3 py-1"
      >
        🐦 Twitter
      </Button>
      <Button 
        onClick={() => handleShare('facebook')}
        className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1"
      >
        📘 Facebook
      </Button>
      <Button 
        onClick={() => handleShare('whatsapp')}
        className="bg-green-500 hover:bg-green-600 text-white text-xs px-3 py-1"
      >
        💬 WhatsApp
      </Button>
      <Button 
        onClick={() => handleShare('telegram')}
        className="bg-blue-400 hover:bg-blue-500 text-white text-xs px-3 py-1"
      >
        ✈️ Telegram
      </Button>
    </div>
  );
};

// TikTok sharing component (legacy)
export const TikTokShareButton: React.FC<TikTokShareButtonProps> = ({ 
  url, 
  text, 
  className = "" 
}) => {
  const handleTikTokShare = () => {
    trackViralShare('tiktok', 'referral', text);

    const shareText = `${text} ${url}`;
    
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareText).then(() => {
        alert('Content copied! Create a TikTok video about your savings!');
      });
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = shareText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert('Content copied! Create a TikTok video about your savings!');
    }
  };

  return (
    <Button 
      onClick={handleTikTokShare}
      className={`bg-black hover:bg-gray-800 text-white ${className}`}
    >
      📱 Share on TikTok
    </Button>
  );
};

// TikTok video embed component (for displaying TikTok content)
interface TikTokEmbedProps {
  videoId: string;
  width?: number;
  height?: number;
}

export const TikTokEmbed: React.FC<TikTokEmbedProps> = ({ 
  videoId, 
  width = 325, 
  height = 580 
}) => {
  return (
    <blockquote 
      className="tiktok-embed" 
      cite={`https://www.tiktok.com/@bopercheck/video/${videoId}`}
      data-video-id={videoId}
      style={{ maxWidth: width, minWidth: 325 }}
    >
      <section>
        <a 
          target="_blank" 
          title="@bopercheck" 
          href="https://www.tiktok.com/@bopercheck"
          rel="noopener noreferrer"
        >
          @bopercheck
        </a>
      </section>
    </blockquote>
  );
};

// Hook to load TikTok embed script
export const useTikTokEmbed = () => {
  React.useEffect(() => {
    if (typeof window !== 'undefined' && !window.document.getElementById('tiktok-embed-script')) {
      const script = document.createElement('script');
      script.id = 'tiktok-embed-script';
      script.async = true;
      script.src = 'https://www.tiktok.com/embed.js';
      document.body.appendChild(script);
    }
  }, []);
};

// Social media follow buttons
export const SocialFollowButtons: React.FC<{ className?: string }> = ({ 
  className = "" 
}) => {
  const handleFollowClick = (platform: string, url: string) => {
    trackSocialProof(`${platform}_follow_click`);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      <Button 
        onClick={() => handleFollowClick('tiktok', 'https://www.tiktok.com/@bopercheck')}
        variant="outline"
        className="border-black text-black hover:bg-black hover:text-white text-xs px-3 py-1"
      >
        📱 Follow on TikTok
      </Button>
      <Button 
        onClick={() => handleFollowClick('twitter', 'https://twitter.com/bopercheck')}
        variant="outline"
        className="border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white text-xs px-3 py-1"
      >
        🐦 Follow on Twitter
      </Button>
      <Button 
        onClick={() => handleFollowClick('instagram', 'https://instagram.com/bopercheck')}
        variant="outline"
        className="border-pink-500 text-pink-500 hover:bg-pink-500 hover:text-white text-xs px-3 py-1"
      >
        📷 Follow on Instagram
      </Button>
    </div>
  );
};

// TikTok follow button component (legacy)
export const TikTokFollowButton: React.FC<{ className?: string }> = ({ 
  className = "" 
}) => {
  const handleFollowClick = () => {
    trackSocialProof('tiktok_follow_click');
    window.open('https://www.tiktok.com/@bopercheck', '_blank', 'noopener,noreferrer');
  };

  return (
    <Button 
      onClick={handleFollowClick}
      variant="outline"
      className={`border-black text-black hover:bg-black hover:text-white ${className}`}
    >
      Follow us on TikTok
    </Button>
  );
};

export default TikTokShareButton;