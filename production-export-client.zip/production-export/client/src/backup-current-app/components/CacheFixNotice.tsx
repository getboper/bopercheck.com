import { useState, useEffect } from "react";
import { AlertTriangle, RefreshCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function CacheFixNotice() {
  const [showNotice, setShowNotice] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Check if this is a fresh load or if there are known cache issues
    const params = new URLSearchParams(window.location.search);
    const isFreshLoad = params.has('nocache') || params.has('fresh') || params.has('v');
    const hasIssues = localStorage.getItem('bopercheck_loading_issues') === 'true';
    const wasDismissed = sessionStorage.getItem('cache_notice_dismissed') === 'true';
    
    // Show notice if there are issues and it hasn't been dismissed
    if ((hasIssues || !isFreshLoad) && !wasDismissed) {
      // Delay showing to avoid flash
      setTimeout(() => setShowNotice(true), 2000);
    }
  }, []);

  const handleDismiss = () => {
    setShowNotice(false);
    setDismissed(true);
    sessionStorage.setItem('cache_notice_dismissed', 'true');
  };

  const handleClearCache = () => {
    window.location.href = '/clear-cache?auto=true';
  };

  if (!showNotice || dismissed) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      <Alert className="border-orange-200 bg-orange-50 shadow-lg">
        <AlertTriangle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-800">
          <div className="flex justify-between items-start mb-2">
            <span className="font-medium text-sm">Having loading issues?</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDismiss}
              className="h-auto p-0 text-orange-600 hover:bg-orange-100"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
          <p className="text-xs mb-3">
            Clear your browser cache if pages aren't loading properly.
          </p>
          <div className="flex gap-2">
            <Button
              onClick={handleClearCache}
              size="sm"
              className="bg-orange-600 hover:bg-orange-700 text-white text-xs"
            >
              <RefreshCw className="h-3 w-3 mr-1" />
              Fix Now
            </Button>
            <Button
              onClick={handleDismiss}
              variant="outline"
              size="sm"
              className="border-orange-300 text-orange-700 hover:bg-orange-100 text-xs"
            >
              Dismiss
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
}