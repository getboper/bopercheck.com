import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  suggestions?: string[];
}

const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hi! I'm your BoperCheck AI assistant. I can help you with price checks, business advertising, and account questions. How can I help you today?",
      sender: 'ai',
      timestamp: new Date(),
      suggestions: [
        "How do I upload a photo for price checking?",
        "What counts as a credit?",
        "How can I get free credits?",
        "How do I upgrade my business plan?",
        "What plan includes homepage features?"
      ]
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const commonResponses = {
    // General User Questions
    "upload photo": "To upload a photo for price checking:\n1. Click 'Check Price' on the homepage\n2. Select 'Upload Image' or drag & drop your photo\n3. Add a description of what you're looking for\n4. Click 'Analyze Price' to get your results!\n\nSupported formats: JPG, PNG, WEBP (max 10MB)",
    
    "credit": "All price searches are completely free forever! Credits are only for premium features:\n• PDF downloads: 1 credit each\n• Voucher generation: 1 credit each\n• Starter Pack: 5 credits for £3.99 (6 months)\n• Value Pack: 10 credits for £6.99 (12 months)\n• Bulk Pack: 25 credits for £16.99 (12 months)\n\nUnlimited price analysis, comparisons, and local business recommendations are always free!",
    
    "free credits": "Get credits for premium features easily:\n🎁 All searches: Completely free forever\n👥 Referrals: You and your friend both get 1 credit for premium features\n📱 Social sharing: Like and share our Facebook page for bonus credits\n\nWant more? Our referral program is the best way to earn ongoing credits for PDF downloads and vouchers!",
    
    // Business Questions
    "upgrade plan": "Ready to grow your business visibility?\n\n📊 Basic Plan (£49/month): 1 category, basic listing\n🚀 Pro Plan (£149/month): 5 categories, priority placement, AI suggestions\n⭐ Featured Partner (£299/month): 10 categories, homepage features, social shoutouts\n\n💰 Save 15% with annual billing! Which plan interests you?",
    
    "homepage features": "Homepage features are included in our Featured Partner Plan (£299/month):\n⭐ Rotating homepage spotlight\n🏆 'Featured Business' badge\n📈 AI marketing prompts\n📱 Monthly social media shoutouts\n🤝 Concierge setup support\n📊 Quarterly performance reports\n\nThis gets you maximum visibility to potential customers!",
    
    "business listing": "Edit your business listing easily:\n1. Log into your business account\n2. Go to 'Business Dashboard'\n3. Click 'Edit Listing'\n4. Update photos, description, categories\n5. Save changes - they go live immediately!\n\nNeed to add more categories? I can help you upgrade your plan for better reach!",
    
    "categories": "Add more categories to reach more customers!\n\n💡 Our AI suggests related categories based on your business type. For example:\n• Decking → Kitchen Fitting, Carpentry, Garden Structures\n• Plumbing → Heating, Bathroom Fitting, Emergency Repairs\n\nIndividual categories: £10/month each\nOr upgrade to Pro (5 categories) or Featured Partner (10 categories) for better value!"
  };

  const getAIResponse = (userMessage: string): { text: string; suggestions?: string[] } => {
    const message = userMessage.toLowerCase();
    
    // Check for keyword matches
    for (const [keyword, response] of Object.entries(commonResponses)) {
      if (message.includes(keyword)) {
        const suggestions = keyword.includes('plan') || keyword.includes('business') ? [
          "Tell me about Pro Plan features",
          "How do I add more categories?",
          "Show me Featured Partner benefits",
          "I want to upgrade my listing"
        ] : [
          "How do I buy more credits?",
          "Tell me about referral program",
          "What file formats work for photos?",
          "How long do credits last?"
        ];
        
        return { text: response, suggestions };
      }
    }
    
    // Smart upsell prompts based on context
    if (message.includes('more') && (message.includes('customer') || message.includes('business'))) {
      return {
        text: "Want to reach more customers? 🚀\n\nBusinesses on our Pro Plan see 58% more engagement! Here's how:\n• Priority placement in search results\n• Up to 5 product categories\n• AI-suggested related categories\n• Enhanced analytics\n\nUpgrade to Pro for £149/month (save 15% annually) and watch your visibility grow!",
        suggestions: [
          "Upgrade to Pro Plan",
          "Add another category for £10/month",
          "Tell me about analytics dashboard",
          "How does priority placement work?"
        ]
      };
    }
    
    if (message.includes('help') || message.includes('support')) {
      return {
        text: "I'm here to help! 😊 I can assist with:\n\n👤 For general users:\n• Price checking process\n• Credit purchases & usage\n• Photo upload issues\n• Getting free credits\n\n🏢 For business advertisers:\n• Plan upgrades & features\n• Listing management\n• Performance analytics\n• Category optimization\n\nWhat specific question do you have?",
        suggestions: [
          "How do I upload a photo?",
          "What counts as a credit?", 
          "How do I upgrade my plan?",
          "How can I get free credits?"
        ]
      };
    }
    
    // Default response with smart CTAs
    return {
      text: "I'd be happy to help! I can answer questions about:\n\n🔍 Price checking & credits\n💼 Business advertising plans\n📱 Account & technical support\n🎁 Free credits & referrals\n\nCould you be more specific about what you need help with?",
      suggestions: [
        "How do I upload a photo?",
        "What counts as a credit?",
        "How do I upgrade my business plan?",
        "How can I get free credits?"
      ]
    };
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse = getAIResponse(inputText);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse.text,
        sender: 'ai',
        timestamp: new Date(),
        suggestions: aiResponse.suggestions
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputText(suggestion);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Toggle Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-green-500 hover:bg-green-600 text-white rounded-full w-14 h-14 shadow-lg"
          size="icon"
        >
          {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
        </Button>
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-40 w-96 max-w-[calc(100vw-3rem)]">
          <Card className="shadow-xl border-2 border-green-200">
            <CardHeader className="bg-green-500 text-white rounded-t-lg py-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Bot className="h-5 w-5" />
                BoperCheck AI Assistant
              </CardTitle>
            </CardHeader>
            
            <CardContent className="p-0">
              {/* Messages */}
              <div className="h-96 overflow-y-auto p-4 space-y-3">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3 rounded-lg ${
                      message.sender === 'user' 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      <div className="flex items-start gap-2">
                        {message.sender === 'ai' && <Bot className="h-4 w-4 mt-0.5 flex-shrink-0" />}
                        <div className="flex-1">
                          <p className="text-sm whitespace-pre-line">{message.text}</p>
                          {message.suggestions && (
                            <div className="mt-3 space-y-1">
                              {message.suggestions.map((suggestion, index) => (
                                <button
                                  key={index}
                                  onClick={() => handleSuggestionClick(suggestion)}
                                  className="block w-full text-left text-xs bg-white text-gray-700 border border-gray-200 rounded px-2 py-1 hover:bg-gray-50 transition-colors"
                                >
                                  {suggestion}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                        {message.sender === 'user' && <User className="h-4 w-4 mt-0.5 flex-shrink-0" />}
                      </div>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 text-gray-800 p-3 rounded-lg max-w-[80%]">
                      <div className="flex items-center gap-2">
                        <Bot className="h-4 w-4" />
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="border-t border-gray-200 p-3">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask me anything..."
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                  />
                  <Button
                    onClick={handleSendMessage}
                    size="icon"
                    className="bg-green-500 hover:bg-green-600"
                    disabled={!inputText.trim()}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
};

export default AIAssistant;