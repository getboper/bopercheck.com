import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Users, TrendingUp, CheckCircle } from "lucide-react";
import { trackSocialProof } from "@/lib/tiktokPixel";

interface LiveActivity {
  id: string;
  user: string;
  action: string;
  savings: number;
  timeAgo: string;
  location: string;
}

const SocialProofWidget: React.FC = () => {
  const [liveActivities, setLiveActivities] = useState<LiveActivity[]>([
    {
      id: '1',
      user: 'Sarah M.',
      action: 'saved on kitchen appliances',
      savings: 234,
      timeAgo: '2 minutes ago',
      location: 'London'
    },
    {
      id: '2',
      user: 'James L.',
      action: 'found better garden tools deal',
      savings: 89,
      timeAgo: '5 minutes ago',
      location: 'Manchester'
    },
    {
      id: '3',
      user: 'Emma T.',
      action: 'discovered electronics discount',
      savings: 156,
      timeAgo: '8 minutes ago',
      location: 'Birmingham'
    }
  ]);

  const [stats] = useState({
    totalUsers: 12847,
    totalSavings: 285690,
    activeNow: 143
  });

  useEffect(() => {
    // Track social proof widget view
    trackSocialProof('widget_view', { location: 'homepage' });

    // Simulate live activity updates
    const interval = setInterval(() => {
      const cities = ['London', 'Manchester', 'Birmingham', 'Liverpool', 'Leeds', 'Sheffield'];
      const actions = [
        'saved on home improvement',
        'found better electronics deal', 
        'discovered furniture discount',
        'saved on garden supplies',
        'found cheaper kitchen items'
      ];
      
      const newActivity: LiveActivity = {
        id: Date.now().toString(),
        user: `User ${Math.floor(Math.random() * 1000)}`,
        action: actions[Math.floor(Math.random() * actions.length)],
        savings: Math.floor(Math.random() * 300) + 50,
        timeAgo: 'just now',
        location: cities[Math.floor(Math.random() * cities.length)]
      };

      setLiveActivities(prev => [newActivity, ...prev.slice(0, 2)]);
    }, 15000); // Update every 15 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      {/* Live Statistics */}
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-4 text-center">
          <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-blue-900">{stats.totalUsers.toLocaleString()}</div>
          <div className="text-xs text-blue-700">Happy Savers</div>
          <div className="text-xs text-blue-600 mt-1">{stats.activeNow} active now</div>
        </CardContent>
      </Card>

      {/* Total Savings */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardContent className="p-4 text-center">
          <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-green-900">£{stats.totalSavings.toLocaleString()}</div>
          <div className="text-xs text-green-700">Total Saved</div>
          <div className="text-xs text-green-600 mt-1">This month</div>
        </CardContent>
      </Card>

      {/* Live Activity Feed */}
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="p-4">
          <div className="text-sm font-semibold text-purple-900 mb-3 flex items-center">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
            Live Activity
          </div>
          <div className="space-y-2">
            {liveActivities.map((activity) => (
              <div key={activity.id} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-3 h-3 text-green-600" />
                  <div>
                    <div className="font-medium text-gray-800">{activity.user}</div>
                    <div className="text-gray-600">{activity.action}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-green-600">£{activity.savings}</div>
                  <div className="text-gray-500">{activity.timeAgo}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SocialProofWidget;