import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Share2, Gift, Users } from "lucide-react";
import { ViralShareButtons } from "@/components/social/TikTokIntegration";
import { trackViralShare, trackSocialProof } from "@/lib/tiktokPixel";

interface ViralCTAProps {
  savings?: number;
  item?: string;
  context?: 'result' | 'home' | 'general';
}

const ViralCTA: React.FC<ViralCTAProps> = ({ 
  savings = 0, 
  item = 'amazing deals',
  context = 'general' 
}) => {
  const handleShareClick = () => {
    trackViralShare('cta_click', 'savings_share', item);
    trackSocialProof('viral_engagement', { context, savings });
  };

  const handleReferralClick = () => {
    trackSocialProof('referral_interest', { context, item });
  };

  const getContextualMessage = () => {
    switch (context) {
      case 'result':
        return {
          title: `🎉 You Just Saved £${savings}!`,
          subtitle: 'Share your success and help friends save money too',
          shareText: `I just saved £${savings} on ${item} with BoperCheck! 💰 Check it out:`
        };
      case 'home':
        return {
          title: '💝 Help Friends Save Money',
          subtitle: 'Share BoperCheck and earn rewards for every friend who joins',
          shareText: 'Discover amazing local deals with BoperCheck! 🛍️ Free price comparisons:'
        };
      default:
        return {
          title: '🚀 Spread the Savings!',
          subtitle: 'Share BoperCheck with friends and family',
          shareText: 'Found the best local deals with BoperCheck! 💯 Try it yourself:'
        };
    }
  };

  const { title, subtitle, shareText } = getContextualMessage();

  return (
    <Card className="bg-gradient-to-r from-purple-50 via-pink-50 to-orange-50 border-purple-200">
      <CardContent className="p-6">
        <div className="text-center mb-4">
          <h3 className="text-lg font-bold text-purple-900 mb-2">
            {title}
          </h3>
          <p className="text-purple-700 text-sm">
            {subtitle}
          </p>
        </div>

        {/* Social Share Buttons */}
        <div className="mb-4">
          <ViralShareButtons 
            url={window.location.href}
            text={shareText}
            itemName={item}
            className="justify-center"
          />
        </div>

        {/* Viral Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="outline"
            onClick={handleReferralClick}
            className="flex-1 border-purple-300 text-purple-700 hover:bg-purple-50"
          >
            <Gift className="w-4 h-4 mr-2" />
            Refer Friends & Earn
          </Button>
          
          <Button
            onClick={handleShareClick}
            className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
          >
            <Users className="w-4 h-4 mr-2" />
            Share Success
          </Button>
        </div>

        {/* Incentive Text */}
        <div className="text-center mt-4">
          <p className="text-xs text-purple-600">
            💎 Get exclusive deals when friends use your link
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ViralCTA;