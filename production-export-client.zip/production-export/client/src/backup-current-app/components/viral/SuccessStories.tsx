import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Share2, MapPin, Verified } from "lucide-react";
import { trackSocialProof } from "@/lib/tiktokPixel";

interface SuccessStory {
  id: string;
  name: string;
  item: string;
  savings: number;
  story: string;
  location: string;
  verified: boolean;
  rating: number;
  category: string;
}

const SuccessStories: React.FC = () => {
  const [stories] = useState<SuccessStory[]>([
    {
      id: '1',
      name: 'Sarah Mitchell',
      item: 'Kitchen Renovation',
      savings: 2340,
      story: 'BoperCheck helped me find local suppliers for my kitchen renovation. I saved over £2,300 compared to the first quotes I received. The platform made it so easy to compare prices and find verified contractors.',
      location: 'London',
      verified: true,
      rating: 5,
      category: 'Home Improvement'
    },
    {
      id: '2',
      name: 'James Thompson',
      item: 'Garden Landscaping',
      savings: 890,
      story: 'Amazing service! Found three different landscaping companies through BoperCheck and ended up saving nearly £900. The quality was excellent and the whole process was transparent.',
      location: 'Manchester',
      verified: true,
      rating: 5,
      category: 'Garden & Outdoor'
    },
    {
      id: '3',
      name: 'Emma Rodriguez',
      item: 'Electronics & Appliances',
      savings: 567,
      story: 'I was looking for a new washing machine and fridge. BoperCheck not only found me the best prices but also helped me discover local retailers I never knew existed. Saved over £500!',
      location: 'Birmingham',
      verified: true,
      rating: 5,
      category: 'Electronics'
    },
    {
      id: '4',
      name: 'Michael Chen',
      item: 'Car Repairs',
      savings: 456,
      story: 'My car needed major repairs and the first garage quoted £1,200. Through BoperCheck, I found a highly rated local mechanic who did the same work for £744. Incredible savings!',
      location: 'Leeds',
      verified: true,
      rating: 5,
      category: 'Automotive'
    }
  ]);

  const handleShareStory = (story: SuccessStory) => {
    // Track story sharing
    trackSocialProof('story_share', { 
      story_id: story.id, 
      savings: story.savings,
      category: story.category
    });

    if (navigator.share) {
      navigator.share({
        title: `I saved £${story.savings} with BoperCheck!`,
        text: story.story,
        url: window.location.href
      });
    } else {
      // Fallback to copying link
      navigator.clipboard.writeText(window.location.href);
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Real Success Stories
        </h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          See how BoperCheck has helped thousands of people save money and find better deals across the UK.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {stories.map((story) => (
          <Card key={story.id} className="hover:shadow-lg transition-shadow duration-300">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {story.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">{story.name}</CardTitle>
                      {story.verified && (
                        <Verified className="w-4 h-4 text-blue-500" />
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-3 h-3" />
                      {story.location}
                    </div>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  £{story.savings} saved
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-semibold text-gray-900">{story.item}</span>
                  <Badge variant="outline" className="text-xs">
                    {story.category}
                  </Badge>
                </div>
                <div className="flex items-center gap-1 mb-3">
                  {renderStars(story.rating)}
                  <span className="text-sm text-gray-600 ml-2">
                    {story.rating}/5 stars
                  </span>
                </div>
              </div>
              
              <p className="text-gray-700 leading-relaxed text-sm">
                "{story.story}"
              </p>
              
              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleShareStory(story)}
                  className="flex items-center gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  Share Story
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center mt-8">
        <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Have Your Own Success Story?
            </h3>
            <p className="text-gray-600 mb-4">
              Share how BoperCheck helped you save money and inspire others!
            </p>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              Share Your Story
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SuccessStories;