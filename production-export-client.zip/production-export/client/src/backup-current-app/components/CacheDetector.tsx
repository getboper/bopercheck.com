import { useEffect } from 'react';

// Component to detect and handle cache issues automatically
export default function CacheDetector() {
  useEffect(() => {
    // Check for cache-related issues on load
    const detectCacheIssues = () => {
      // Check if this is a fresh load
      const params = new URLSearchParams(window.location.search);
      const isFreshLoad = params.has('nocache') || params.has('fresh') || params.has('v');
      
      // If not a fresh load, check for signs of cached errors
      if (!isFreshLoad) {
        // Check for missing assets or errors
        const hasErrors = document.querySelectorAll('[data-error]').length > 0;
        const hasMissingImages = Array.from(document.querySelectorAll('img')).some(img => 
          img.src && !img.complete && img.naturalHeight === 0
        );
        
        if (hasErrors || hasMissingImages) {
          localStorage.setItem('bopercheck_loading_issues', 'true');
        }
      }
      
      // Monitor for runtime errors
      window.addEventListener('error', (event) => {
        if (event.target instanceof HTMLElement) {
          localStorage.setItem('bopercheck_loading_issues', 'true');
        }
      });
      
      // Monitor for unhandled promise rejections
      window.addEventListener('unhandledrejection', () => {
        localStorage.setItem('bopercheck_loading_issues', 'true');
      });
      
      // Monitor fetch failures
      const originalFetch = window.fetch;
      window.fetch = async (...args) => {
        try {
          const response = await originalFetch(...args);
          if (!response.ok && response.status >= 400) {
            localStorage.setItem('bopercheck_loading_issues', 'true');
          }
          return response;
        } catch (error) {
          localStorage.setItem('bopercheck_loading_issues', 'true');
          throw error;
        }
      };
    };
    
    // Run detection after a short delay to allow page to load
    setTimeout(detectCacheIssues, 1000);
    
    // Also run on DOM content loaded
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', detectCacheIssues);
    } else {
      detectCacheIssues();
    }
  }, []);

  // This component doesn't render anything
  return null;
}