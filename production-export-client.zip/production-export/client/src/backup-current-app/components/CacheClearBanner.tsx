import { useState, useEffect } from "react";
import { X, RefreshCw, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function CacheClearBanner() {
  const [showBanner, setShowBanner] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  useEffect(() => {
    // Check if user has encountered loading issues
    const hasLoadingIssues = localStorage.getItem('bopercheck_loading_issues');
    const lastClearTime = localStorage.getItem('bopercheck_cache_cleared');
    const bannerDismissed = sessionStorage.getItem('bopercheck_banner_dismissed');
    const now = Date.now();
    
    // Only show if user hasn't dismissed it this session and there are actual issues
    // Show banner if there were loading issues and cache wasn't cleared recently (within 1 hour)
    if (hasLoadingIssues && !bannerDismissed && (!lastClearTime || now - parseInt(lastClearTime) > 3600000)) {
      // Add delay to avoid showing on every page load
      setTimeout(() => setShowBanner(true), 3000);
    }

    // Also check for common error indicators
    const checkForErrors = () => {
      const hasNetworkError = document.querySelector('[data-error="network"]');
      const hasLoadError = document.querySelector('[data-error="load"]');
      
      if (hasNetworkError || hasLoadError) {
        setShowBanner(true);
        localStorage.setItem('bopercheck_loading_issues', 'true');
      }
    };

    // Check immediately and set up periodic checking
    checkForErrors();
    const interval = setInterval(checkForErrors, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleClearCache = async () => {
    setIsClearing(true);
    
    try {
      // Clear service workers
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const registration of registrations) {
          await registration.unregister();
        }
      }

      // Clear all caches
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
      }

      // Clear storage
      localStorage.clear();
      sessionStorage.clear();

      // Store the clear time before final reload
      localStorage.setItem('bopercheck_cache_cleared', Date.now().toString());
      
      // Force hard reload with cache bypass
      window.location.href = window.location.href + '?nocache=' + Date.now();
      
    } catch (error) {
      console.error('Cache clear failed:', error);
      // Fallback: force reload anyway
      window.location.href = window.location.href + '?clear=' + Date.now();
    }
  };

  const handleDismiss = () => {
    setShowBanner(false);
    localStorage.setItem('bopercheck_cache_cleared', Date.now().toString());
    localStorage.removeItem('bopercheck_loading_issues');
    
    // Also set session flag to prevent reshowing
    sessionStorage.setItem('bopercheck_banner_dismissed', 'true');
    
    // Clear all cache-related flags
    localStorage.removeItem('cache_detected');
    localStorage.removeItem('severe_cache_detected');
    document.cookie = 'cache_error=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
  };

  if (!showBanner) return null;

  return (
    <Card className="fixed top-4 left-4 right-4 z-50 border-orange-200 bg-orange-50 shadow-lg">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-semibold text-orange-800 mb-1">
              Having trouble loading BoperCheck?
            </h3>
            <p className="text-sm text-orange-700 mb-3">
              If pages aren't loading properly, clear your browser cache to fix display issues.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={handleClearCache}
                disabled={isClearing}
                size="sm"
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                {isClearing ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                    Clearing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-4 w-4 mr-1" />
                    Clear Cache & Reload
                  </>
                )}
              </Button>
              <Button
                onClick={handleDismiss}
                variant="outline"
                size="sm"
                className="border-orange-300 text-orange-700 hover:bg-orange-100"
              >
                Dismiss
              </Button>
            </div>
            <p className="text-xs text-orange-600 mt-2">
              Alternative: Try opening BoperCheck.com in an incognito/private window
            </p>
          </div>
          <Button
            onClick={handleDismiss}
            variant="ghost"
            size="sm"
            className="text-orange-600 hover:bg-orange-100 p-1 flex-shrink-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}