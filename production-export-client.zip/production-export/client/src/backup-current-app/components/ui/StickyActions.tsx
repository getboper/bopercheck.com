import React, { useState, useEffect } from 'react';
import { Home, Share2 } from 'lucide-react';
import { Button } from './button';
import { Toast } from './toast';
import { Toaster } from './toaster';
import { useToast } from '@/hooks/use-toast';

const StickyActions = () => {
  const [isInstallable, setIsInstallable] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Listen for the beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', (e) => {
      // Prevent the mini-infobar from appearing on mobile
      e.preventDefault();
      // Stash the event so it can be triggered later
      setDeferredPrompt(e);
      // Update UI to show the install button
      setIsInstallable(true);
    });

    // Listen for app installed event
    window.addEventListener('appinstalled', () => {
      // Hide the install button when the app is installed
      setIsInstallable(false);
      setDeferredPrompt(null);
      // Log install to analytics
      console.log('PWA was installed');
      toast({
        title: "App Installed!",
        description: "BoperCheck has been added to your home screen!",
        duration: 3000
      });
    });
  }, [toast]);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      // If running as standalone, or installation not supported
      const message = window.matchMedia('(display-mode: standalone)').matches
        ? "BoperCheck is already installed on your device!"
        : "Installation not supported in this browser. Try using Chrome or Safari.";
      
      toast({
        title: "Installation Info",
        description: message,
        duration: 5000
      });
      return;
    }

    // Show the install prompt
    deferredPrompt.prompt();
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    // Optionally, send analytics event with outcome of user choice
    console.log(`User ${outcome === 'accepted' ? 'accepted' : 'dismissed'} the install prompt`);
    // We've used the prompt, and can't use it again, so clear it
    setDeferredPrompt(null);
  };

  const handleShareClick = async () => {
    // Always share the homepage URL to prevent sharing authenticated sessions or price check results
    const shareUrl = window.location.origin;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'BoperCheck - Price Comparison Tool',
          text: 'Check out BoperCheck, the smartest way to compare prices and find the best deals!',
          url: shareUrl,
        });
        toast({
          title: "Shared!",
          description: "Thanks for sharing BoperCheck with your friends!",
          duration: 3000
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(shareUrl);
      toast({
        title: "Link Copied!",
        description: "Share the link with your friends!",
        duration: 3000
      });
    }
  };

  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 flex justify-center items-center gap-4 p-4 bg-white dark:bg-gray-900 shadow-lg border-t border-gray-200 dark:border-gray-800 z-50">
        <Button 
          onClick={handleInstallClick} 
          className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-bold"
        >
          <Home className="mr-2 h-5 w-5" />
          Add to Home Screen
        </Button>
        <Button 
          onClick={handleShareClick} 
          className="flex-1 bg-blue-500 hover:bg-blue-600 text-white font-bold"
        >
          <Share2 className="mr-2 h-5 w-5" />
          Share BoperCheck
        </Button>
      </div>
      <Toaster />
    </>
  );
};

export default StickyActions;