import { cn, categoryIcons } from "@/lib/utils";

interface CategoryIconProps {
  category: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const CategoryIcon = ({ category, size = "md", className }: CategoryIconProps) => {
  const icon = categoryIcons[category] || categoryIcons.other;
  
  const sizeClasses = {
    sm: "w-8 h-8 text-lg",
    md: "w-12 h-12 text-xl",
    lg: "w-16 h-16 text-2xl"
  };

  return (
    <div className={cn(
      "rounded-full flex items-center justify-center",
      icon.color,
      sizeClasses[size],
      className
    )}>
      <i className={`fas fa-${icon.icon} text-white`}></i>
    </div>
  );
};

export default CategoryIcon;
