const SEOContent = () => {
  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-4xl mx-auto px-4">
        {/* SEO-rich content section */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-2xl font-bold mb-4 text-gray-800">
              Search for Any Price Instantly
            </h2>
            <p className="text-gray-600 mb-4">
              Looking for "how much is" a specific product? Our AI-powered price search tool 
              instantly compares prices across hundreds of UK retailers to help you find the 
              best deals and save money on every purchase.
            </p>
            <ul className="text-gray-600 space-y-2">
              <li>• Search for any product price in seconds</li>
              <li>• Compare deals from top UK retailers</li>
              <li>• Find discount codes automatically</li>
              <li>• Discover local suppliers and second-hand options</li>
            </ul>
          </div>
          
          <div>
            <h2 className="text-2xl font-bold mb-4 text-gray-800">
              Who Sells It Cheapest?
            </h2>
            <p className="text-gray-600 mb-4">
              Wondering "where can I buy" something for less? BoperCheck searches thousands 
              of retailers to show you exactly who sells your desired product at the lowest 
              price, helping you save money on every purchase.
            </p>
            <ul className="text-gray-600 space-y-2">
              <li>• Real-time price monitoring</li>
              <li>• Installation cost estimates</li>
              <li>• Money-saving recommendations</li>
              <li>• Free price comparison service</li>
            </ul>
          </div>
        </div>
        
        {/* FAQ Section for SEO */}
        <div className="bg-white rounded-lg p-8 shadow-sm">
          <h2 className="text-2xl font-bold mb-6 text-gray-800">
            Frequently Asked Questions
          </h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">
                How do I search for a price on BoperCheck?
              </h3>
              <p className="text-gray-600">
                Simply enter the product name in our search box and click "Check Price Now". 
                Our AI will instantly search across hundreds of retailers to find the best 
                prices and deals available.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">
                How much does it cost to use BoperCheck?
              </h3>
              <p className="text-gray-600">
                BoperCheck is completely free to use. There are no hidden fees or subscription 
                costs. Simply search for any price and start saving money immediately.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">
                Where can I buy products found on BoperCheck?
              </h3>
              <p className="text-gray-600">
                We show you where to buy products from verified UK retailers, including major 
                stores, local suppliers, and trusted online marketplaces. Each result includes 
                direct links to purchase.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">
                How does BoperCheck help me save money?
              </h3>
              <p className="text-gray-600">
                We compare prices across hundreds of retailers, find active discount codes, 
                suggest alternative products, and show installation costs - ensuring you get 
                the best possible deal on every purchase.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SEOContent;