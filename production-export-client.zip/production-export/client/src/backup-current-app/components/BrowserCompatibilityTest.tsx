import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, AlertTriangle, Monitor, Smartphone } from "lucide-react";

interface TestResult {
  name: string;
  status: 'pass' | 'fail' | 'warning';
  details: string;
}

export default function BrowserCompatibilityTest() {
  const [results, setResults] = useState<TestResult[]>([]);
  const [isTestingActive, setIsTestingActive] = useState(false);

  const runCompatibilityTests = async () => {
    setIsTestingActive(true);
    const testResults: TestResult[] = [];

    // Test 1: Service Worker Support
    try {
      if ('serviceWorker' in navigator) {
        testResults.push({
          name: 'Service Worker Support',
          status: 'pass',
          details: 'Service Workers are supported and can be cleared'
        });
      } else {
        testResults.push({
          name: 'Service Worker Support',
          status: 'warning',
          details: 'Service Workers not supported - fallback cache clearing will be used'
        });
      }
    } catch (error) {
      testResults.push({
        name: 'Service Worker Support',
        status: 'fail',
        details: 'Error checking Service Worker support'
      });
    }

    // Test 2: Cache API Support
    try {
      if ('caches' in window) {
        const testCache = await caches.open('compatibility-test');
        await caches.delete('compatibility-test');
        testResults.push({
          name: 'Cache API Support',
          status: 'pass',
          details: 'Cache API is fully supported'
        });
      } else {
        testResults.push({
          name: 'Cache API Support',
          status: 'warning',
          details: 'Cache API not supported - localStorage clearing only'
        });
      }
    } catch (error) {
      testResults.push({
        name: 'Cache API Support',
        status: 'fail',
        details: 'Cache API test failed'
      });
    }

    // Test 3: Local Storage Support
    try {
      localStorage.setItem('test-cache-clear', 'test');
      const retrieved = localStorage.getItem('test-cache-clear');
      localStorage.removeItem('test-cache-clear');
      
      if (retrieved === 'test') {
        testResults.push({
          name: 'Local Storage Support',
          status: 'pass',
          details: 'localStorage read/write/delete working correctly'
        });
      } else {
        testResults.push({
          name: 'Local Storage Support',
          status: 'fail',
          details: 'localStorage test failed'
        });
      }
    } catch (error) {
      testResults.push({
        name: 'Local Storage Support',
        status: 'fail',
        details: 'localStorage not available (private browsing mode?)'
      });
    }

    // Test 4: Session Storage Support
    try {
      sessionStorage.setItem('test-session', 'test');
      const retrieved = sessionStorage.getItem('test-session');
      sessionStorage.removeItem('test-session');
      
      if (retrieved === 'test') {
        testResults.push({
          name: 'Session Storage Support',
          status: 'pass',
          details: 'sessionStorage working correctly'
        });
      } else {
        testResults.push({
          name: 'Session Storage Support',
          status: 'fail',
          details: 'sessionStorage test failed'
        });
      }
    } catch (error) {
      testResults.push({
        name: 'Session Storage Support',
        status: 'warning',
        details: 'sessionStorage not available'
      });
    }

    // Test 5: Fetch API Support
    try {
      if (typeof fetch === 'function') {
        testResults.push({
          name: 'Fetch API Support',
          status: 'pass',
          details: 'Fetch API available for cache-busting requests'
        });
      } else {
        testResults.push({
          name: 'Fetch API Support',
          status: 'warning',
          details: 'Fetch API not available - using XMLHttpRequest fallback'
        });
      }
    } catch (error) {
      testResults.push({
        name: 'Fetch API Support',
        status: 'fail',
        details: 'Error checking Fetch API support'
      });
    }

    // Test 6: Device Type Detection
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const isTablet = /iPad|Android(?!.*Mobile)/i.test(navigator.userAgent);
    const deviceType = isMobile ? 'Mobile' : isTablet ? 'Tablet' : 'Desktop';
    
    testResults.push({
      name: 'Device Type Detection',
      status: 'pass',
      details: `Detected as ${deviceType} device`
    });

    // Test 7: Viewport Size Check
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    if (viewportWidth < 768) {
      testResults.push({
        name: 'Viewport Compatibility',
        status: 'pass',
        details: `Mobile viewport detected (${viewportWidth}x${viewportHeight})`
      });
    } else if (viewportWidth < 1024) {
      testResults.push({
        name: 'Viewport Compatibility',
        status: 'pass',
        details: `Tablet viewport detected (${viewportWidth}x${viewportHeight})`
      });
    } else {
      testResults.push({
        name: 'Viewport Compatibility',
        status: 'pass',
        details: `Desktop viewport detected (${viewportWidth}x${viewportHeight})`
      });
    }

    // Test 8: Network Status
    try {
      const isOnline = navigator.onLine;
      testResults.push({
        name: 'Network Status',
        status: isOnline ? 'pass' : 'warning',
        details: isOnline ? 'Device is online' : 'Device appears to be offline'
      });
    } catch (error) {
      testResults.push({
        name: 'Network Status',
        status: 'warning',
        details: 'Unable to determine network status'
      });
    }

    // Test 9: Performance API
    try {
      if ('performance' in window && 'now' in performance) {
        testResults.push({
          name: 'Performance Monitoring',
          status: 'pass',
          details: 'Performance API available for cache timing analysis'
        });
      } else {
        testResults.push({
          name: 'Performance Monitoring',
          status: 'warning',
          details: 'Performance API not available'
        });
      }
    } catch (error) {
      testResults.push({
        name: 'Performance Monitoring',
        status: 'fail',
        details: 'Performance API test failed'
      });
    }

    // Test 10: IndexedDB Support (for complete clearing)
    try {
      if ('indexedDB' in window) {
        testResults.push({
          name: 'IndexedDB Support',
          status: 'pass',
          details: 'IndexedDB available for comprehensive cache clearing'
        });
      } else {
        testResults.push({
          name: 'IndexedDB Support',
          status: 'warning',
          details: 'IndexedDB not supported - basic cache clearing only'
        });
      }
    } catch (error) {
      testResults.push({
        name: 'IndexedDB Support',
        status: 'fail',
        details: 'IndexedDB test failed'
      });
    }

    setResults(testResults);
    setIsTestingActive(false);
  };

  useEffect(() => {
    // Run tests automatically on component mount
    runCompatibilityTests();
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'fail':
        return <XCircle className="h-4 w-4 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass':
        return 'bg-green-100 text-green-800';
      case 'fail':
        return 'bg-red-100 text-red-800';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const passCount = results.filter(r => r.status === 'pass').length;
  const warningCount = results.filter(r => r.status === 'warning').length;
  const failCount = results.filter(r => r.status === 'fail').length;

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Monitor className="h-5 w-5" />
          Browser Compatibility Test
        </CardTitle>
        <div className="flex gap-2">
          <Badge variant="outline" className="bg-green-50">
            {passCount} Passed
          </Badge>
          <Badge variant="outline" className="bg-yellow-50">
            {warningCount} Warnings
          </Badge>
          <Badge variant="outline" className="bg-red-50">
            {failCount} Failed
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Button 
              onClick={runCompatibilityTests} 
              disabled={isTestingActive}
              variant="outline"
            >
              {isTestingActive ? 'Testing...' : 'Rerun Tests'}
            </Button>
          </div>

          <div className="grid gap-3">
            {results.map((result, index) => (
              <div 
                key={index}
                className="flex items-center justify-between p-3 border rounded-lg"
              >
                <div className="flex items-center gap-3">
                  {getStatusIcon(result.status)}
                  <span className="font-medium">{result.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600 max-w-md text-right">
                    {result.details}
                  </span>
                  <Badge className={getStatusColor(result.status)}>
                    {result.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>

          {results.length > 0 && (
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Compatibility Summary</h3>
              <p className="text-sm text-gray-600">
                {failCount === 0 && warningCount === 0 
                  ? "All tests passed! Your browser fully supports BoperCheck's cache clearing features."
                  : failCount > 0
                  ? "Some critical features are not available. Cache clearing may be limited on this browser."
                  : "Most features are available. Some advanced cache clearing features may not work, but basic functionality is supported."
                }
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}