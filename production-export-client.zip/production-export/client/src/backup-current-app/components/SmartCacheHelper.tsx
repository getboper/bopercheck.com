import { useState, useEffect } from "react";
import { RefreshCw, CheckCircle, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { apiRequest } from "@/lib/queryClient";

export default function SmartCacheHelper() {
  const [cacheIssues, setCacheIssues] = useState(false);
  const [isFixing, setIsFixing] = useState(false);
  const [showHelper, setShowHelper] = useState(false);
  const [lastCheck, setLastCheck] = useState(0);

  useEffect(() => {
    // Only check for cache issues if there are actual error indicators
    const checkForIssues = () => {
      const now = Date.now();
      
      // Avoid checking too frequently (max once per 30 seconds)
      if (now - lastCheck < 30000) return;
      
      const indicators = [
        // Check for error indicators in the DOM
        document.querySelector('[data-error="loading"]'),
        document.querySelector('[data-error="network"]'),
        // Check for repeated failed requests in console
        window.performance?.getEntriesByType?.('navigation')?.[0]?.duration > 10000,
        // Check if localStorage has error flags
        localStorage.getItem('bopercheck_loading_errors') === 'true'
      ];
      
      const hasIssues = indicators.some(Boolean);
      
      if (hasIssues && !cacheIssues) {
        setCacheIssues(true);
        // Delay showing helper to avoid immediate popup
        setTimeout(() => setShowHelper(true), 5000);
      }
      
      setLastCheck(now);
    };

    // Check on mount and periodically
    checkForIssues();
    const interval = setInterval(checkForIssues, 60000); // Check every minute
    
    return () => clearInterval(interval);
  }, [cacheIssues, lastCheck]);

  const handleAutoFix = async () => {
    setIsFixing(true);
    try {
      const response = await fetch("/api/auto-fix-cache", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const result = await response.json();
      
      if (result.success) {
        // Clear issue indicators
        localStorage.removeItem('bopercheck_loading_errors');
        localStorage.setItem('bopercheck_cache_cleared', Date.now().toString());
        setCacheIssues(false);
        setShowHelper(false);
        
        // Redirect to fresh page
        setTimeout(() => {
          window.location.href = result.redirectTo || '/?fresh=1';
        }, 1000);
      }
    } catch (error) {
      console.error('Auto-fix failed:', error);
      // Fallback to manual cache clearing
      window.location.href = '/clear-cache';
    } finally {
      setIsFixing(false);
    }
  };

  const handleDismiss = () => {
    setShowHelper(false);
    sessionStorage.setItem('cache_helper_dismissed', 'true');
  };

  // Only show if there are issues and user hasn't dismissed
  if (!showHelper || !cacheIssues || sessionStorage.getItem('cache_helper_dismissed')) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      <Alert className="border-orange-200 bg-orange-50">
        <AlertTriangle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-sm">
          <div className="mb-3">
            <strong>Loading Issues Detected</strong>
            <br />
            We can fix this automatically to improve your experience.
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              onClick={handleAutoFix}
              disabled={isFixing}
              className="bg-orange-600 hover:bg-orange-700 text-white"
            >
              {isFixing ? (
                <>
                  <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                  Fixing...
                </>
              ) : (
                <>
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Auto-Fix
                </>
              )}
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              onClick={handleDismiss}
              className="text-gray-600"
            >
              Dismiss
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
}