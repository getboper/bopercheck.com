import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { MapPin } from "lucide-react";

interface LocationDialogProps {
  open: boolean;
  onClose: () => void;
  onSaveLocation: (location: { city: string; postalCode?: string }) => void;
}

export function LocationDialog({ open, onClose, onSaveLocation }: LocationDialogProps) {
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (city.trim()) {
      onSaveLocation({
        city: city.trim(),
        postalCode: postalCode.trim() || undefined
      });
      onClose();
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-green-500" />
            Location Information
          </DialogTitle>
          <DialogDescription>
            Help us show you the most accurate prices and local suppliers by providing your location.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="city">City or Town <span className="text-red-500">*</span></Label>
            <Input
              id="city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="e.g. London, Manchester, Edinburgh"
              required
              className="w-full"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="postalCode">Postal Code (optional)</Label>
            <Input
              id="postalCode"
              value={postalCode}
              onChange={(e) => setPostalCode(e.target.value)}
              placeholder="e.g. SW1A 1AA"
              className="w-full"
            />
            <p className="text-xs text-muted-foreground">
              Adding your postal code helps us find the nearest suppliers
            </p>
          </div>
          
          <DialogFooter className="pt-4">
            <Button 
              variant="outline" 
              type="button" 
              onClick={onClose}
              className="w-full sm:w-auto"
            >
              Skip for Now
            </Button>
            <Button 
              type="submit" 
              className="w-full sm:w-auto bg-green-500 hover:bg-green-600"
            >
              Save Location
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}