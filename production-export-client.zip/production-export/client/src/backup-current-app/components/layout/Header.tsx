import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header className={`sticky top-0 z-50 bg-background border-b border-border boper-shadow transition-all duration-300 ${isScrolled ? 'py-2' : 'py-3'}`}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2 flex-shrink-0">
          <div className="boper-gradient w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xl">B</div>
          <span className="boper-logo">BoperCheck</span>
        </Link>
        
        <nav className="hidden md:flex items-center space-x-3 lg:space-x-6 flex-1 justify-center">
          <Link href="/how-it-works" className="nav-link text-sm lg:text-base whitespace-nowrap">
            How It Works
          </Link>
          <Link href="/pricing" className="nav-link text-sm lg:text-base whitespace-nowrap">
            Pricing
          </Link>
          <Link href="/faq" className="nav-link text-sm lg:text-base whitespace-nowrap">
            FAQ
          </Link>
          <Link href="/referrals" className="nav-link text-sm lg:text-base whitespace-nowrap">
            Rewards
          </Link>
          <Link href="/success-stories" className="nav-link text-sm lg:text-base whitespace-nowrap">
            Stories
          </Link>
          <Link href="/business" className="nav-link text-sm lg:text-base whitespace-nowrap">
            Business
          </Link>
          <Link href="/owner" className="nav-link text-xs font-normal text-gray-400 hover:text-gray-600 whitespace-nowrap opacity-30 hover:opacity-60 transition-opacity">
            •
          </Link>
        </nav>
        
        <div className="hidden md:flex items-center space-x-3 flex-shrink-0">
          {user ? (
            <>
              <Link href="/dashboard" className="nav-link text-sm lg:text-base">
                Dashboard
              </Link>
              <Button variant="outline" onClick={handleLogout} className="text-sm lg:text-base px-3 lg:px-4">
                Log Out
              </Button>
            </>
          ) : (
            <>
              <Link href="/login" className="nav-link text-sm lg:text-base">
                Log In
              </Link>
              <Link href="/signup">
                <Button className="btn-primary text-sm lg:text-base px-3 lg:px-4">Sign Up</Button>
              </Link>
            </>
          )}
        </div>
        
        {/* Mobile menu */}
        <Sheet>
          <SheetTrigger asChild className="md:hidden flex-shrink-0">
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right">
            <nav className="flex flex-col space-y-4 mt-10">
              <Link href="/how-it-works" className="text-muted-foreground hover:text-primary transition p-2">
                How It Works
              </Link>
              <Link href="/pricing" className="text-muted-foreground hover:text-primary transition p-2">
                Pricing
              </Link>
              <Link href="/faq" className="text-muted-foreground hover:text-primary transition p-2">
                FAQ
              </Link>
              <Link href="/referrals" className="text-muted-foreground hover:text-primary transition p-2">
                Rewards
              </Link>
              <Link href="/business" className="text-muted-foreground hover:text-primary transition p-2">
                Business
              </Link>
              <Link href="/owner" className="text-gray-400 hover:text-gray-600 transition p-2 text-xs opacity-40">
                •
              </Link>
              
              <div className="pt-4 border-t">
                {user ? (
                  <>
                    <Link href="/dashboard" className="block w-full mb-2">
                      <Button variant="outline" className="w-full">Dashboard</Button>
                    </Link>
                    <Button variant="default" className="w-full" onClick={handleLogout}>
                      Log Out
                    </Button>
                  </>
                ) : (
                  <>
                    <Link href="/login" className="block w-full mb-2">
                      <Button variant="outline" className="w-full">Log In</Button>
                    </Link>
                    <Link href="/signup" className="block w-full">
                      <Button className="w-full">Sign Up</Button>
                    </Link>
                  </>
                )}
              </div>
            </nav>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
};

export default Header;
