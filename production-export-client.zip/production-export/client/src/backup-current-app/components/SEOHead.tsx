import { Helmet } from 'react-helmet';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: string;
  schemaData?: any;
}

export function SEOHead({
  title = "BoperCheck - AI Price Comparison & Voucher Discovery",
  description = "Get instant AI-powered price analysis and comparison across UK retailers. Find the best deals, installation costs, and verified discount codes with Claude AI.",
  keywords = "price comparison, UK retailers, discount vouchers, AI price analysis, best deals, shopping comparison, voucher codes",
  image = "/og-image.jpg",
  url = "https://bopercheck.replit.app",
  type = "website",
  schemaData
}: SEOHeadProps) {
  const fullTitle = title.includes('BoperCheck') ? title : `${title} | BoperCheck`;
  const fullUrl = url.startsWith('http') ? url : `https://bopercheck.replit.app${url}`;
  const fullImage = image.startsWith('http') ? image : `https://bopercheck.replit.app${image}`;

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      <meta name="author" content="BoperCheck" />
      <meta name="robots" content="index, follow" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link rel="canonical" href={fullUrl} />

      {/* Open Graph / Facebook */}
      <meta property="og:type" content={type} />
      <meta property="og:url" content={fullUrl} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={fullImage} />
      <meta property="og:site_name" content="BoperCheck" />
      <meta property="og:locale" content="en_GB" />

      {/* Twitter */}
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={fullUrl} />
      <meta property="twitter:title" content={fullTitle} />
      <meta property="twitter:description" content={description} />
      <meta property="twitter:image" content={fullImage} />

      {/* Additional Meta */}
      <meta name="theme-color" content="#10b981" />
      <meta name="msapplication-TileColor" content="#10b981" />
      
      {/* Structured Data */}
      {schemaData && (
        <script type="application/ld+json">
          {JSON.stringify(schemaData)}
        </script>
      )}
    </Helmet>
  );
}

// Pre-defined SEO configurations for different pages
export const seoConfigs = {
  home: {
    title: "BoperCheck - AI Price Comparison & Voucher Discovery",
    description: "Get instant AI-powered price analysis and comparison across UK retailers. Find the best deals, installation costs, and verified discount codes with Claude AI.",
    keywords: "price comparison, UK retailers, discount vouchers, AI price analysis, best deals, shopping comparison, voucher codes, Claude AI",
    schemaData: {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "BoperCheck",
      "url": "https://bopercheck.replit.app",
      "description": "AI-powered price comparison and voucher discovery platform for UK retailers",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://bopercheck.replit.app/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }
  },
  
  search: {
    title: "Search Results - Price Comparison",
    description: "Compare prices across UK retailers with AI-powered analysis. Find the best deals, installation costs, and discount vouchers for your search.",
    keywords: "search results, price comparison, UK retailers, best deals, AI analysis"
  },
  
  advertiserSignup: {
    title: "Advertise Your Business - BoperCheck",
    description: "Reach thousands of price-conscious UK shoppers. Join BoperCheck's advertising platform and showcase your products to customers actively comparing prices.",
    keywords: "business advertising, UK retailers, price comparison advertising, merchant signup, business promotion",
    schemaData: {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "BoperCheck Advertising",
      "description": "Advertising platform for UK retailers to reach price-conscious customers",
      "provider": {
        "@type": "Organization",
        "name": "BoperCheck"
      }
    }
  },
  
  voucherPot: {
    title: "Voucher Savings Pot - Collect & Redeem Rewards",
    description: "Collect vouchers from your searches and unlock milestone rewards. Earn £20, £50, £100+ vouchers by using BoperCheck's AI price comparison.",
    keywords: "voucher pot, discount codes, rewards, savings, milestone rewards, UK vouchers"
  },
  
  adminDashboard: {
    title: "Admin Dashboard - BoperCheck Management",
    description: "Real-time monitoring and management dashboard for BoperCheck platform operations, user analytics, and system health.",
    keywords: "admin dashboard, platform management, analytics, system monitoring"
  }
};