import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Share2, Copy, Facebook, Twitter, MessageCircle, Mail, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ShareToolsProps {
  searchQuery?: string;
  savingsAmount?: string;
  showIncentive?: boolean;
}

export default function ShareTools({ searchQuery, savingsAmount, showIncentive = true }: ShareToolsProps) {
  const [isSharing, setIsSharing] = useState(false);
  const { toast } = useToast();

  const getShareText = () => {
    if (searchQuery && savingsAmount) {
      return `I just saved ${savingsAmount} on ${searchQuery} using BoperCheck! 💰 Check it out: `;
    }
    return "Found amazing deals with BoperCheck - AI-powered price comparison! 🔍💰 ";
  };

  const shareUrl = "https://bopercheck.com";
  const shareText = getShareText();

  const handleShare = async (platform: string) => {
    setIsSharing(true);
    
    try {
      let shareTargetUrl = "";
      
      switch (platform) {
        case "native":
          if (navigator.share) {
            await navigator.share({
              title: "BoperCheck - AI Price Comparison",
              text: shareText,
              url: shareUrl
            });
          } else {
            await navigator.clipboard.writeText(shareText + shareUrl);
            toast({
              title: "Copied to clipboard!",
              description: "Share link copied successfully"
            });
          }
          break;
          
        case "whatsapp":
          shareTargetUrl = `https://wa.me/?text=${encodeURIComponent(shareText + shareUrl)}`;
          window.open(shareTargetUrl, '_blank');
          break;
          
        case "facebook":
          shareTargetUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
          window.open(shareTargetUrl, '_blank');
          break;
          
        case "twitter":
          shareTargetUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
          window.open(shareTargetUrl, '_blank');
          break;
          
        case "email":
          shareTargetUrl = `mailto:?subject=${encodeURIComponent("Check out BoperCheck!")}&body=${encodeURIComponent(shareText + shareUrl)}`;
          window.location.href = shareTargetUrl;
          break;
          
        case "copy":
          await navigator.clipboard.writeText(shareText + shareUrl);
          toast({
            title: "Copied to clipboard!",
            description: "Share link copied successfully"
          });
          break;
      }

      // Track sharing for referral system
      if (platform !== "copy") {
        try {
          await fetch('/api/track-share', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              platform,
              searchQuery,
              savingsAmount,
              timestamp: new Date().toISOString()
            })
          });
        } catch (error) {
          console.log('Share tracking failed:', error);
        }
      }

    } catch (error) {
      console.error('Sharing failed:', error);
      toast({
        title: "Sharing failed",
        description: "Please try again or copy the link manually",
        variant: "destructive"
      });
    }
    
    setIsSharing(false);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Share2 className="h-5 w-5" />
          Share Your Savings
          {showIncentive && (
            <span className="ml-2 text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">
              Earn Credits!
            </span>
          )}
        </CardTitle>
        {showIncentive && (
          <p className="text-sm text-gray-600">
            Share BoperCheck and earn free credits when friends use your link
          </p>
        )}
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <Button
            onClick={() => handleShare("native")}
            disabled={isSharing}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Share2 className="h-4 w-4" />
            Share
          </Button>
          
          <Button
            onClick={() => handleShare("whatsapp")}
            disabled={isSharing}
            variant="outline"
            className="flex items-center gap-2 text-green-600 border-green-200 hover:bg-green-50"
          >
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </Button>
          
          <Button
            onClick={() => handleShare("facebook")}
            disabled={isSharing}
            variant="outline"
            className="flex items-center gap-2 text-blue-600 border-blue-200 hover:bg-blue-50"
          >
            <Facebook className="h-4 w-4" />
            Facebook
          </Button>
          
          <Button
            onClick={() => handleShare("twitter")}
            disabled={isSharing}
            variant="outline"
            className="flex items-center gap-2 text-blue-400 border-blue-200 hover:bg-blue-50"
          >
            <Twitter className="h-4 w-4" />
            Twitter
          </Button>
          
          <Button
            onClick={() => handleShare("email")}
            disabled={isSharing}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Mail className="h-4 w-4" />
            Email
          </Button>
          
          <Button
            onClick={() => handleShare("copy")}
            disabled={isSharing}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Copy className="h-4 w-4" />
            Copy Link
          </Button>
        </div>

        {showIncentive && (
          <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-center gap-2 text-yellow-800">
              <Star className="h-4 w-4" />
              <span className="font-medium">Referral Rewards</span>
            </div>
            <p className="text-sm text-yellow-700 mt-1">
              Earn 1 free credit for each friend who uses BoperCheck through your share link
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}