import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Building, Store, ArrowRight, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface BusinessSignupCTAProps {
  category?: string;
  itemType?: string;
}

export function BusinessSignupCTA({ category, itemType }: BusinessSignupCTAProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    businessName: "",
    contactName: "",
    email: "",
    phone: "",
    website: "",
    businessType: "",
    message: ""
  });

  // Create compelling message based on the search
  const getCompellingMessage = () => {
    const searchTerm = itemType || category || "this product";
    return `Your next customer just searched for '${searchTerm}'. Want them to see you next time?`;
  };
  
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Send business signup data to backend
      const response = await fetch('/api/business/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          interestedCategory: category,
          searchedItem: itemType,
          source: 'price_check_cta'
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit business information');
      }

      // Show success state
      setSubmitted(true);
      
      // Show toast notification
      toast({
        title: "Information received!",
        description: "Thank you for your interest. We'll be in touch soon.",
      });

    } catch (error) {
      console.error('Business signup error:', error);
      toast({
        title: "Error",
        description: "Failed to submit information. Please try again.",
        variant: "destructive"
      });
      return;
    }
    
    // Reset form after 3 seconds and close dialog
    setTimeout(() => {
      setFormData({
        businessName: "",
        contactName: "",
        email: "",
        phone: "",
        website: "",
        businessType: "",
        message: ""
      });
      setSubmitted(false);
      setDialogOpen(false);
    }, 3000);
  };

  return (
    <div className="mt-8 bg-gradient-to-br from-green-200 via-green-100 to-blue-100 rounded-xl p-6 border-2 border-green-300 shadow-md hover:shadow-lg transition-all">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="bg-green-500 rounded-full p-3 text-white shadow-sm">
            <Store size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-xl font-bold text-gray-800">{getCompellingMessage()}</h3>
              <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full uppercase font-bold tracking-wide animate-pulse">
                Hot Lead
              </span>
            </div>
            <p className="text-gray-700 mt-1 font-medium">
              We show your business exactly when users are actively searching — no guesswork, no random targeting.
            </p>
            <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
              <span>📊 3x higher conversion than traditional ad platforms</span>
              <span>🎯 76 people searched for this in your area this week</span>
            </div>
            <p className="text-sm text-gray-600 mt-1">
              Be seen by users searching for your service right now in your area
            </p>
          </div>
        </div>
        
        <Button 
          onClick={() => setLocation("/business")}
          className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-6 py-3 rounded-lg flex items-center shadow-md hover:shadow-lg transform hover:scale-105 transition-all"
        >
          Advertise Now While They're Searching <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl">
              <Building className="text-green-500" />
              Business Partnership Program
            </DialogTitle>
            <DialogDescription>
              Join our network of trusted suppliers and get your business featured in price check results
            </DialogDescription>
          </DialogHeader>
          
          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="businessName">Business Name <span className="text-red-500">*</span></Label>
                  <Input
                    id="businessName"
                    name="businessName"
                    value={formData.businessName}
                    onChange={handleChange}
                    placeholder="Your company name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="contactName">Contact Name <span className="text-red-500">*</span></Label>
                  <Input
                    id="contactName"
                    name="contactName"
                    value={formData.contactName}
                    onChange={handleChange}
                    placeholder="Your full name"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address <span className="text-red-500">*</span></Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="you@example.com"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="e.g. 07700 900000"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    name="website"
                    type="url"
                    value={formData.website}
                    onChange={handleChange}
                    placeholder="https://your-website.com"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="businessType">Business Type <span className="text-red-500">*</span></Label>
                  <Input
                    id="businessType"
                    name="businessType"
                    value={formData.businessType}
                    onChange={handleChange}
                    placeholder="e.g. Retailer, Service Provider"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="message">Additional Information</Label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Tell us more about your business and what products or services you offer..."
                  rows={4}
                />
              </div>
              
              <div className="pt-4 space-y-4">
                <h4 className="font-semibold">Benefits of Partnership:</h4>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Featured placement in price check results</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Targeted exposure to customers actively looking for your products</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Detailed analytics on customer engagement</span>
                  </li>
                </ul>
              </div>
              
              <DialogFooter className="pt-4">
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-green-500 hover:bg-green-600"
                >
                  Submit Interest
                </Button>
              </DialogFooter>
            </form>
          ) : (
            <div className="py-12 text-center space-y-4">
              <div className="mx-auto bg-green-100 text-green-700 rounded-full w-16 h-16 flex items-center justify-center">
                <CheckCircle size={32} />
              </div>
              <h3 className="text-xl font-bold">Thank You!</h3>
              <p className="text-gray-600">
                We've received your information and will be in touch soon about partnership opportunities.
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}