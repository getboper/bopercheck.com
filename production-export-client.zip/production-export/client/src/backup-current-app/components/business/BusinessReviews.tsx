import { useState, useEffect } from "react";
import { Star, StarHalf, Shield, User } from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { generateStars } from "@/lib/utils";

interface BusinessReviewsProps {
  businessId: number;
}

// Type for a single review
interface Review {
  id: number;
  username: string;
  rating: number;
  comment?: string;
  createdAt: string;
  verified: boolean;
}

// Type for rating summary
interface RatingSummary {
  averageRating: number;
  totalRatings: number;
  ratingDistribution: Record<number, number>;
  reviewHighlights: string[];
}

export default function BusinessReviews({ businessId }: BusinessReviewsProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [summary, setSummary] = useState<RatingSummary>({
    averageRating: 0,
    totalRatings: 0,
    ratingDistribution: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 },
    reviewHighlights: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [addReviewOpen, setAddReviewOpen] = useState(false);
  const [userReview, setUserReview] = useState({ rating: 5, comment: "" });
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  // Fetch reviews and summary
  useEffect(() => {
    async function fetchReviews() {
      try {
        setLoading(true);
        
        // Get reviews
        const reviewsResponse = await apiRequest("GET", `/api/business-ratings/${businessId}`);
        const reviewsData = await reviewsResponse.json();
        setReviews(reviewsData);
        
        // Get rating summary
        const summaryResponse = await apiRequest("GET", `/api/business-ratings/${businessId}/summary`);
        const summaryData = await summaryResponse.json();
        setSummary(summaryData);
        
        setError(null);
      } catch (err) {
        console.error("Error fetching reviews:", err);
        setError("Unable to load reviews. Please try again later.");
      } finally {
        setLoading(false);
      }
    }
    
    fetchReviews();
  }, [businessId]);
  
  // Submit a new review
  const submitReview = async () => {
    if (userReview.rating < 1 || userReview.rating > 5) {
      toast({
        title: "Invalid rating",
        description: "Please select a rating between 1 and 5 stars",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setSubmitting(true);
      
      const response = await apiRequest("POST", "/api/business-ratings", {
        businessUserId: businessId,
        rating: userReview.rating,
        comment: userReview.comment.trim() || undefined,
      });
      
      if (!response.ok) {
        throw new Error("Failed to submit review");
      }
      
      const newReview = await response.json();
      
      // Update local state
      setReviews(prev => [newReview, ...prev]);
      
      // Update summary (simplified - in production you would re-fetch)
      setSummary(prev => ({
        ...prev,
        totalRatings: prev.totalRatings + 1,
        averageRating: (prev.averageRating * prev.totalRatings + userReview.rating) / (prev.totalRatings + 1)
      }));
      
      // Reset form
      setUserReview({ rating: 5, comment: "" });
      setAddReviewOpen(false);
      
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
    } catch (err) {
      console.error("Error submitting review:", err);
      toast({
        title: "Error",
        description: "Failed to submit your review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  // Rating bar component for distribution display
  const RatingBar = ({ percentage, count, stars }: { percentage: number, count: number, stars: number }) => (
    <div className="flex items-center mb-1">
      <div className="w-24 flex items-center justify-end">
        <span className="text-sm font-medium mr-2">{stars} stars</span>
      </div>
      <div className="flex-1 h-4 bg-gray-100 rounded-full overflow-hidden">
        <div 
          className="h-full bg-yellow-400 rounded-full" 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      <div className="w-14 text-right">
        <span className="text-sm text-gray-500 ml-2">{count}</span>
      </div>
    </div>
  );
  
  // Helper to format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', { 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric' 
    });
  };
  
  if (loading) {
    return (
      <div className="p-8 text-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
        <p>Loading reviews...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-8 text-center bg-red-50 rounded-lg border border-red-100">
        <p className="text-red-600">{error}</p>
      </div>
    );
  }
  
  return (
    <div className="mt-12 mb-16 max-w-5xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-2">Customer Reviews</h2>
        <p className="text-gray-600">See what others are saying about this business</p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8">
        {/* Rating Summary */}
        <Card className="relative h-min">
          <CardHeader className="pb-2">
            <CardTitle>Rating Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center mb-6">
              <div className="text-5xl font-bold mr-4">{summary.averageRating.toFixed(1)}</div>
              <div>
                <div className="flex">
                  {Array.from({length: 5}).map((_, i) => {
                    const stars = generateStars(summary.averageRating);
                    if (i < stars.full) {
                      return <Star key={i} className="h-6 w-6 text-yellow-400 fill-yellow-400" />;
                    } else if (i < stars.full + stars.half) {
                      return <StarHalf key={i} className="h-6 w-6 text-yellow-400 fill-yellow-400" />;
                    } else {
                      return <Star key={i} className="h-6 w-6 text-gray-200" />;
                    }
                  })}
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Based on {summary.totalRatings} {summary.totalRatings === 1 ? "review" : "reviews"}
                </p>
              </div>
            </div>
            
            <div className="mb-8">
              {[5, 4, 3, 2, 1].map(stars => {
                const count = summary.ratingDistribution[stars] || 0;
                const percentage = summary.totalRatings > 0 
                  ? (count / summary.totalRatings) * 100 
                  : 0;
                  
                return (
                  <RatingBar 
                    key={stars} 
                    stars={stars} 
                    count={count}
                    percentage={percentage}
                  />
                );
              })}
            </div>
            
            {summary.reviewHighlights.length > 0 && (
              <div>
                <h4 className="font-semibold mb-2">Review Highlights</h4>
                <ul className="space-y-2">
                  {summary.reviewHighlights.map((highlight, index) => (
                    <li key={index} className="bg-gray-50 p-3 rounded-lg italic text-sm">
                      "{highlight}"
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="mt-6">
              <Button 
                onClick={() => setAddReviewOpen(true)}
                className="w-full"
              >
                Write a Review
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Reviews List */}
        <div className="space-y-4">
          {reviews.length === 0 ? (
            <div className="bg-gray-50 p-8 rounded-lg text-center">
              <p className="text-gray-600 mb-4">No reviews yet</p>
              <p className="text-gray-500 text-sm mb-6">Be the first to share your experience!</p>
              <Button 
                onClick={() => setAddReviewOpen(true)}
                variant="outline"
              >
                Write a Review
              </Button>
            </div>
          ) : (
            reviews.map(review => (
              <Card key={review.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="p-4 bg-gray-50 border-b flex items-center justify-between">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-3">
                        <div className="bg-primary text-primary-foreground rounded-full flex items-center justify-center h-full w-full text-sm font-medium">
                          {review.username ? review.username.charAt(0).toUpperCase() : <User className="h-5 w-5" />}
                        </div>
                      </Avatar>
                      <div>
                        <div className="font-medium">{review.username || "Anonymous"}</div>
                        <div className="text-xs text-gray-500">{formatDate(review.createdAt)}</div>
                      </div>
                    </div>
                    {review.verified && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        <Shield className="w-3 h-3 mr-1" /> Verified
                      </Badge>
                    )}
                  </div>
                  
                  <div className="p-4">
                    <div className="flex mb-2">
                      {Array.from({length: 5}).map((_, i) => (
                        <Star key={i} 
                          className={`h-4 w-4 mr-0.5 ${
                            i < review.rating 
                              ? "text-yellow-400 fill-yellow-400" 
                              : "text-gray-200"
                          }`} 
                        />
                      ))}
                    </div>
                    
                    {review.comment && (
                      <p className="text-gray-700">{review.comment}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
      
      {/* Add Review Dialog */}
      <Dialog open={addReviewOpen} onOpenChange={setAddReviewOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Write a Review</DialogTitle>
            <DialogDescription>
              Share your experience with this business to help others make informed decisions.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="flex justify-center mb-6">
              {[1, 2, 3, 4, 5].map(value => (
                <Star 
                  key={value}
                  className={`w-10 h-10 cursor-pointer transition-colors ${
                    value <= userReview.rating 
                      ? "text-yellow-400 fill-yellow-400" 
                      : "text-gray-200"
                  }`}
                  onClick={() => setUserReview(prev => ({ ...prev, rating: value }))}
                />
              ))}
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">
                  Your Review
                </label>
                <Textarea
                  placeholder="Share details about your experience with this business..."
                  value={userReview.comment}
                  onChange={(e) => setUserReview(prev => ({ ...prev, comment: e.target.value }))}
                  rows={5}
                />
              </div>
              
              {!user && (
                <div className="bg-yellow-50 p-3 rounded-lg text-sm text-yellow-800 border border-yellow-200">
                  <p className="flex items-start">
                    <Shield className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                    You're submitting this review as a guest. Sign in to get verified review status and track your reviews.
                  </p>
                </div>
              )}
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddReviewOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submitReview} disabled={submitting}>
              {submitting ? "Submitting..." : "Submit Review"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}