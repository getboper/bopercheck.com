import { useState } from "react";
import { Star, StarHalf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { generateStars } from "@/lib/utils";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

interface BusinessRatingSummaryProps {
  businessId: number;
  averageRating: number;
  totalRatings: number;
  reviewHighlights?: string[];
}

interface BusinessRatingDetailProps {
  businessId: number;
  ratings: Array<{
    id: number;
    rating: number;
    comment?: string;
    username?: string;
    createdAt: string;
    verified: boolean;
  }>;
}

interface AddRatingProps {
  businessId: number;
  onRatingAdded: () => void;
}

export function BusinessRatingSummary({ 
  businessId, 
  averageRating, 
  totalRatings,
  reviewHighlights = []
}: BusinessRatingSummaryProps) {
  const stars = generateStars(averageRating);
  
  return (
    <div className="flex flex-col p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
      <div className="flex items-center mb-2">
        <div className="flex mr-2">
          {[...Array(stars.full)].map((_, i) => (
            <Star key={`full-${i}`} className="text-yellow-400 fill-yellow-400 w-5 h-5" />
          ))}
          {[...Array(stars.half)].map((_, i) => (
            <StarHalf key={`half-${i}`} className="text-yellow-400 fill-yellow-400 w-5 h-5" />
          ))}
          {[...Array(stars.empty)].map((_, i) => (
            <Star key={`empty-${i}`} className="text-gray-300 w-5 h-5" />
          ))}
        </div>
        <span className="text-lg font-bold">{averageRating.toFixed(1)}</span>
        <span className="text-gray-500 text-sm ml-2">({totalRatings} {totalRatings === 1 ? 'review' : 'reviews'})</span>
      </div>
      
      {reviewHighlights.length > 0 && (
        <div className="mt-2">
          <p className="text-sm text-gray-500 mb-1">What customers are saying:</p>
          <ul className="text-sm">
            {reviewHighlights.map((highlight, index) => (
              <li key={index} className="mb-1 italic">"...{highlight}..."</li>
            ))}
          </ul>
        </div>
      )}
      
      <div className="mt-4">
        <AddRating businessId={businessId} onRatingAdded={() => window.location.reload()} />
      </div>
    </div>
  );
}

export function BusinessRatingDetail({ businessId, ratings }: BusinessRatingDetailProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold">Customer Reviews</h3>
      
      {ratings.length === 0 ? (
        <p className="text-gray-500">No reviews yet. Be the first to review!</p>
      ) : (
        <div className="space-y-4">
          {ratings.map((rating) => (
            <Card key={rating.id} className="p-4">
              <div className="flex items-start gap-4">
                <Avatar className="h-10 w-10">
                  <div className="bg-primary text-primary-foreground rounded-full flex items-center justify-center h-full w-full text-sm font-medium">
                    {rating.username ? rating.username.charAt(0).toUpperCase() : "?"}
                  </div>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{rating.username || "Anonymous"}</p>
                      <div className="flex mt-1">
                        {[...Array(Math.floor(rating.rating))].map((_, i) => (
                          <Star key={`full-${i}`} className="text-yellow-400 fill-yellow-400 w-4 h-4" />
                        ))}
                        {rating.rating % 1 !== 0 && (
                          <StarHalf className="text-yellow-400 fill-yellow-400 w-4 h-4" />
                        )}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      {new Date(rating.createdAt).toLocaleDateString()}
                      {rating.verified && (
                        <span className="ml-2 bg-green-100 text-green-800 px-1.5 py-0.5 rounded-full text-xs">
                          Verified
                        </span>
                      )}
                    </div>
                  </div>
                  {rating.comment && <p className="mt-2 text-sm">{rating.comment}</p>}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
      
      <AddRating businessId={businessId} onRatingAdded={() => window.location.reload()} />
    </div>
  );
}

export function AddRating({ businessId, onRatingAdded }: AddRatingProps) {
  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState<string>("");
  const [hoveredRating, setHoveredRating] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [open, setOpen] = useState<boolean>(false);
  const { toast } = useToast();
  const { user } = useAuth();
  
  const handleRatingSubmit = async () => {
    if (rating < 1 || rating > 5) {
      toast({
        title: "Invalid rating",
        description: "Please provide a rating between 1 and 5 stars",
        variant: "destructive",
      });
      return;
    }
    
    setSubmitting(true);
    
    try {
      await apiRequest("POST", "/api/business-ratings", {
        businessUserId: businessId,
        rating,
        comment: comment.trim() || undefined,
      });
      
      toast({
        title: "Thank you for your feedback!",
        description: "Your review has been submitted successfully.",
      });
      
      setOpen(false);
      setComment("");
      setRating(5);
      onRatingAdded();
    } catch (error) {
      toast({
        title: "Failed to submit review",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">Write a Review</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Rate Your Experience</DialogTitle>
          <DialogDescription>
            Share your feedback to help others in their buying decisions.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <div className="flex justify-center mb-4">
            {[1, 2, 3, 4, 5].map((value) => (
              <Star
                key={value}
                className={`w-8 h-8 cursor-pointer ${
                  (hoveredRating !== null ? hoveredRating >= value : rating >= value)
                    ? "text-yellow-400 fill-yellow-400"
                    : "text-gray-300"
                }`}
                onMouseEnter={() => setHoveredRating(value)}
                onMouseLeave={() => setHoveredRating(null)}
                onClick={() => setRating(value)}
              />
            ))}
          </div>
          
          <Textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Share your experience with this business (optional)"
            className="min-h-[100px]"
          />
          
          {!user && (
            <p className="text-sm text-amber-600 mt-2">
              Note: You are posting as a guest. Sign in to get verified review status.
            </p>
          )}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleRatingSubmit} 
            disabled={submitting}
          >
            {submitting ? "Submitting..." : "Submit Review"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}