import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  Users, 
  Mail, 
  TrendingUp, 
  Star, 
  MessageSquare, 
  UserPlus,
  Eye,
  Filter,
  Download,
  Send
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Influencer {
  id: string;
  tiktokHandle: string;
  displayName: string;
  followerCount: number;
  engagementRate?: string;
  email?: string;
  instagramHandle?: string;
  bio?: string;
  location?: string;
  partnershipStatus: string;
  contactAttempts: number;
  lastContactDate?: string;
  featuredOnApp: boolean;
}

interface Campaign {
  id: string;
  name: string;
  description?: string;
  targetFollowerMin: number;
  totalContacts: number;
  responses: number;
  partnerships: number;
  status: string;
}

const InfluencerDashboard: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [followerFilter, setFollowerFilter] = useState('10000');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedInfluencers, setSelectedInfluencers] = useState<string[]>([]);
  const [outreachMessage, setOutreachMessage] = useState('');
  const [outreachSubject, setOutreachSubject] = useState('Partnership Opportunity with BoperCheck');
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualInfluencer, setManualInfluencer] = useState({
    tiktokHandle: '',
    displayName: '',
    followerCount: 10000,
    email: '',
    instagramHandle: '',
    bio: '',
    location: '',
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch influencers (using sample data for demonstration)
  const { data: influencers, isLoading: loadingInfluencers } = useQuery({
    queryKey: ['/api/influencers/samples'],
  });

  // Fetch campaigns
  const { data: campaigns, isLoading: loadingCampaigns } = useQuery({
    queryKey: ['/api/campaigns'],
  });

  // Search influencers mutation
  const searchMutation = useMutation({
    mutationFn: async (params: { query: string; minFollowers: number; categories: string[] }) => {
      return await apiRequest('/api/influencers/search', {
        method: 'POST',
        body: JSON.stringify(params),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/influencers'] });
      toast({
        title: "Search Complete",
        description: "New influencers have been added to your database.",
      });
    },
    onError: (error) => {
      toast({
        title: "Search Failed",
        description: "Please add PERPLEXITY_API_KEY to your environment variables to enable automated search.",
        variant: "destructive",
      });
    },
  });

  // Manual add influencer mutation
  const addManualMutation = useMutation({
    mutationFn: async (influencerData: any) => {
      return await apiRequest('/api/influencers/manual', {
        method: 'POST',
        body: JSON.stringify(influencerData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/influencers'] });
      setShowManualForm(false);
      setManualInfluencer({
        tiktokHandle: '',
        displayName: '',
        followerCount: 10000,
        email: '',
        instagramHandle: '',
        bio: '',
        location: '',
      });
      toast({
        title: "Influencer Added",
        description: "Influencer has been added to your database.",
      });
    },
    onError: () => {
      toast({
        title: "Add Failed",
        description: "Failed to add influencer. Please check the details.",
        variant: "destructive",
      });
    },
  });

  // Send outreach mutation
  const outreachMutation = useMutation({
    mutationFn: async (params: { influencerIds: string[]; subject: string; message: string }) => {
      return await apiRequest('/api/influencers/outreach', {
        method: 'POST',
        body: JSON.stringify(params),
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/influencers'] });
      setSelectedInfluencers([]);
      toast({
        title: "Outreach Complete",
        description: `Sent ${data.sent} messages successfully.`,
      });
    },
    onError: () => {
      toast({
        title: "Outreach Failed",
        description: "Failed to send messages. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Invalid Search",
        description: "Please enter search keywords.",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    const categories = selectedCategory === 'all' ? ['money saving', 'budgeting', 'frugal living', 'financial tips'] : [selectedCategory];
    
    searchMutation.mutate({
      query: searchQuery,
      minFollowers: parseInt(followerFilter),
      categories,
    });
    
    setIsSearching(false);
  };

  const handleManualAdd = () => {
    if (!manualInfluencer.tiktokHandle || !manualInfluencer.displayName) {
      toast({
        title: "Invalid Data",
        description: "Please fill in required fields.",
        variant: "destructive",
      });
      return;
    }

    addManualMutation.mutate(manualInfluencer);
  };

  const handleInfluencerSelect = (id: string) => {
    setSelectedInfluencers(prev => 
      prev.includes(id) 
        ? prev.filter(i => i !== id)
        : [...prev, id]
    );
  };

  const handleSendOutreach = () => {
    if (selectedInfluencers.length === 0) {
      toast({
        title: "No Selection",
        description: "Please select at least one influencer.",
        variant: "destructive",
      });
      return;
    }

    outreachMutation.mutate({
      influencerIds: selectedInfluencers,
      subject: outreachSubject,
      message: outreachMessage,
    });
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      not_contacted: 'bg-gray-100 text-gray-800',
      contacted: 'bg-blue-100 text-blue-800',
      responded: 'bg-green-100 text-green-800',
      partnered: 'bg-purple-100 text-purple-800',
      declined: 'bg-red-100 text-red-800',
    };

    return (
      <Badge className={variants[status] || 'bg-gray-100 text-gray-800'}>
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  const formatFollowerCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  // Set default outreach message
  useEffect(() => {
    if (!outreachMessage) {
      setOutreachMessage(`Hi {{influencerName}},

I hope this email finds you well! I'm reaching out from BoperCheck, an AI-powered price comparison platform that's helping thousands of UK consumers save money on their purchases.

I've been following your fantastic content on TikTok (@{{tiktokHandle}}) and I'm impressed by your practical money-saving tips and the engaged community you've built with {{followerCount}} followers. Your authentic approach to helping people with their finances aligns perfectly with our mission.

We'd love to feature you as one of our highlighted money-saving experts on the BoperCheck platform. Here's what we're offering:

🌟 Featured Profile: Your own dedicated section on our app showcasing your best money-saving tips
💰 Revenue Share: Earn commission on every user who saves money using your featured recommendations  
📱 Cross-Platform Promotion: We'll promote your content across our social channels to drive followers to your TikTok
🎯 Exclusive Content: Early access to our price alerts and deals to share with your audience
📊 Analytics Dashboard: Track how much money you're helping people save through our platform

The partnership is completely free to join, and we handle all the technical aspects. You simply continue creating the amazing content you already do, and we amplify your impact while helping you monetize your expertise.

Would you be interested in a quick 15-minute call this week to discuss how we can work together? I'd love to show you exactly how the platform works and answer any questions you might have.

Looking forward to potentially working together to help more people save money!

Best regards,
Partnership Team
BoperCheck`);
    }
  }, [outreachMessage]);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">TikTok Influencer Outreach</h1>
          <p className="text-gray-600">Connect with money-saving influencers and grow partnerships for BoperCheck</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-blue-500" />
                <div>
                  <p className="text-sm text-gray-600">Total Influencers</p>
                  <p className="text-2xl font-bold">{influencers?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-8 h-8 text-green-500" />
                <div>
                  <p className="text-sm text-gray-600">Contacted</p>
                  <p className="text-2xl font-bold">
                    {influencers?.filter((i: Influencer) => i.partnershipStatus !== 'not_contacted').length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Star className="w-8 h-8 text-purple-500" />
                <div>
                  <p className="text-sm text-gray-600">Partners</p>
                  <p className="text-2xl font-bold">
                    {influencers?.filter((i: Influencer) => i.partnershipStatus === 'partnered').length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <TrendingUp className="w-8 h-8 text-orange-500" />
                <div>
                  <p className="text-sm text-gray-600">Response Rate</p>
                  <p className="text-2xl font-bold">
                    {influencers?.length > 0 
                      ? Math.round((influencers.filter((i: Influencer) => i.partnershipStatus === 'responded' || i.partnershipStatus === 'partnered').length / Math.max(1, influencers.filter((i: Influencer) => i.partnershipStatus !== 'not_contacted').length)) * 100) || 0
                      : 0}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4">
          <Card className="flex-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Find Influencers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  placeholder="money saving tips, budgeting..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Select value={followerFilter} onValueChange={setFollowerFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Min Followers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10000">10K+</SelectItem>
                    <SelectItem value="50000">50K+</SelectItem>
                    <SelectItem value="100000">100K+</SelectItem>
                    <SelectItem value="500000">500K+</SelectItem>
                  </SelectContent>
                </Select>
                <Button 
                  onClick={handleSearch} 
                  disabled={isSearching || searchMutation.isPending}
                >
                  {isSearching || searchMutation.isPending ? 'Searching...' : 'Search TikTok'}
                </Button>
              </div>
              <p className="text-sm text-gray-500">
                Automated search requires PERPLEXITY_API_KEY environment variable
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5" />
                Add Manually
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Dialog open={showManualForm} onOpenChange={setShowManualForm}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full">
                    Add Influencer Manually
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add Influencer Manually</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">TikTok Handle *</label>
                        <Input
                          placeholder="username (without @)"
                          value={manualInfluencer.tiktokHandle}
                          onChange={(e) => setManualInfluencer(prev => ({ ...prev, tiktokHandle: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Display Name *</label>
                        <Input
                          placeholder="Display name"
                          value={manualInfluencer.displayName}
                          onChange={(e) => setManualInfluencer(prev => ({ ...prev, displayName: e.target.value }))}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Follower Count</label>
                        <Input
                          type="number"
                          value={manualInfluencer.followerCount}
                          onChange={(e) => setManualInfluencer(prev => ({ ...prev, followerCount: parseInt(e.target.value) || 0 }))}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Email</label>
                        <Input
                          type="email"
                          placeholder="contact@email.com"
                          value={manualInfluencer.email}
                          onChange={(e) => setManualInfluencer(prev => ({ ...prev, email: e.target.value }))}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Instagram Handle</label>
                        <Input
                          placeholder="instagram_username"
                          value={manualInfluencer.instagramHandle}
                          onChange={(e) => setManualInfluencer(prev => ({ ...prev, instagramHandle: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Location</label>
                        <Input
                          placeholder="London, UK"
                          value={manualInfluencer.location}
                          onChange={(e) => setManualInfluencer(prev => ({ ...prev, location: e.target.value }))}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Bio</label>
                      <Textarea
                        placeholder="Brief description of their content..."
                        value={manualInfluencer.bio}
                        onChange={(e) => setManualInfluencer(prev => ({ ...prev, bio: e.target.value }))}
                        rows={3}
                      />
                    </div>
                    
                    <Button 
                      onClick={handleManualAdd}
                      disabled={addManualMutation.isPending}
                      className="w-full"
                    >
                      {addManualMutation.isPending ? 'Adding...' : 'Add Influencer'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Influencer List */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Influencer Database</CardTitle>
              <div className="flex gap-2">
                {selectedInfluencers.length > 0 && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline">
                        <Send className="w-4 h-4 mr-2" />
                        Send Outreach ({selectedInfluencers.length})
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Send Partnership Outreach</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Subject</label>
                          <Input
                            value={outreachSubject}
                            onChange={(e) => setOutreachSubject(e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Message</label>
                          <Textarea
                            value={outreachMessage}
                            onChange={(e) => setOutreachMessage(e.target.value)}
                            rows={15}
                            className="text-sm"
                          />
                        </div>
                        <div className="text-xs text-gray-500">
                          Variables: {'{'}influencerName{'}'}, {'{'}tiktokHandle{'}'}, {'{'}followerCount{'}'}
                        </div>
                        <Button 
                          onClick={handleSendOutreach}
                          disabled={outreachMutation.isPending}
                          className="w-full"
                        >
                          {outreachMutation.isPending ? 'Sending...' : 'Send Outreach Messages'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loadingInfluencers ? (
              <div className="text-center py-8">Loading influencers...</div>
            ) : influencers?.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No influencers found. Start by searching for new influencers or adding them manually.
              </div>
            ) : (
              <div className="space-y-4">
                {influencers?.map((influencer: Influencer) => (
                  <div 
                    key={influencer.id}
                    className={`border rounded-lg p-4 hover:shadow-md transition-shadow ${
                      selectedInfluencers.includes(influencer.id) ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <input
                          type="checkbox"
                          checked={selectedInfluencers.includes(influencer.id)}
                          onChange={() => handleInfluencerSelect(influencer.id)}
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-lg">@{influencer.tiktokHandle}</h3>
                            {getStatusBadge(influencer.partnershipStatus)}
                            {influencer.featuredOnApp && (
                              <Badge className="bg-yellow-100 text-yellow-800">Featured</Badge>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-3">
                            <div>
                              <span className="font-medium">Followers:</span> {formatFollowerCount(influencer.followerCount)}
                            </div>
                            {influencer.engagementRate && (
                              <div>
                                <span className="font-medium">Engagement:</span> {influencer.engagementRate}
                              </div>
                            )}
                            {influencer.location && (
                              <div>
                                <span className="font-medium">Location:</span> {influencer.location}
                              </div>
                            )}
                            <div>
                              <span className="font-medium">Contacted:</span> {influencer.contactAttempts} times
                            </div>
                          </div>
                          
                          {influencer.bio && (
                            <p className="text-sm text-gray-700 mb-3 line-clamp-2">{influencer.bio}</p>
                          )}
                          
                          <div className="flex gap-2">
                            {influencer.email && (
                              <Badge variant="outline" className="text-xs">
                                <Mail className="w-3 h-3 mr-1" />
                                Email Available
                              </Badge>
                            )}
                            {influencer.instagramHandle && (
                              <Badge variant="outline" className="text-xs">
                                <Users className="w-3 h-3 mr-1" />
                                Instagram: @{influencer.instagramHandle}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InfluencerDashboard;