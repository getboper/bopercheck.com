import { useQuery } from "@tanstack/react-query";
import { Star, ThumbsUp, Shield } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface Review {
  id: number;
  user: string;
  rating: number;
  comment: string;
  searchItem: string;
  verified: boolean;
  helpfulVotes: number;
  date: string;
}

interface ReviewStats {
  totalReviews: number;
  averageRating: number;
  fiveStars: number;
  fourStars: number;
  threeStars: number;
  twoStars: number;
  oneStars: number;
}

const ReviewsSection = () => {
  const { data, isLoading } = useQuery({
    queryKey: ["/api/reviews"],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="bg-gray-50 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64 mx-auto mb-8"></div>
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                  <div className="h-16 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const reviews: Review[] = (data as any)?.reviews || [];
  const stats: ReviewStats = (data as any)?.stats || {
    totalReviews: 0,
    averageRating: 0,
    fiveStars: 0,
    fourStars: 0,
    threeStars: 0,
    twoStars: 0,
    oneStars: 0
  };

  if (reviews.length === 0) {
    return null; // Don't show section if no reviews
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            What Our Users Say
          </h2>
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="flex items-center gap-2">
              <div className="flex">
                {renderStars(Math.round(stats.averageRating))}
              </div>
              <span className="text-2xl font-bold text-gray-900">
                {stats.averageRating.toFixed(1)}
              </span>
            </div>
            <div className="text-gray-600">
              Based on {stats.totalReviews.toLocaleString()} reviews
            </div>
          </div>
          
          {/* Rating breakdown */}
          <div className="max-w-md mx-auto">
            {[5, 4, 3, 2, 1].map((star) => {
              const percentage = stats[`${['', '', '', '', 'one', 'two', 'three', 'four', 'five'][star]}Stars` as keyof ReviewStats] as number;
              return (
                <div key={star} className="flex items-center gap-2 mb-1">
                  <span className="text-sm text-gray-600 w-8">{star}★</span>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-yellow-400 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600 w-8">{percentage}%</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Reviews */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.slice(0, 6).map((review) => (
            <Card key={review.id} className="bg-white shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-gray-900">{review.user}</span>
                      {review.verified && (
                        <Shield className="h-4 w-4 text-blue-500" />
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {renderStars(review.rating)}
                      </div>
                      <span className="text-sm text-gray-500">{review.date}</span>
                    </div>
                  </div>
                </div>
                
                <p className="text-gray-700 mb-3 text-sm leading-relaxed">
                  "{review.comment}"
                </p>
                
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span className="bg-gray-100 px-2 py-1 rounded">
                    Search: {review.searchItem}
                  </span>
                  {review.helpfulVotes > 0 && (
                    <div className="flex items-center gap-1">
                      <ThumbsUp className="h-3 w-3" />
                      <span>{review.helpfulVotes}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-600">
            Join thousands of satisfied users who save money with BoperCheck every day!
          </p>
        </div>
      </div>
    </div>
  );
};

export default ReviewsSection;