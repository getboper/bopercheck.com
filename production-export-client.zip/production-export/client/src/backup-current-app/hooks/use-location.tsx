import { useState, useEffect } from 'react';

interface LocationData {
  city: string;
  region: string;
  country: string;
  postalCode?: string;
  latitude?: number;
  longitude?: number;
  loading: boolean;
  error: string | null;
}

interface UseLocationReturn extends LocationData {
  setManualLocation: (location: Partial<LocationData>) => void;
  requestingLocation: boolean;
}

/**
 * Custom hook to get user's location information
 * Attempts to get location through browser geolocation API first,
 * then falls back to IP-based geolocation if browser geolocation fails
 */
export function useLocation(): UseLocationReturn {
  const [locationData, setLocationData] = useState<LocationData>({
    city: '',
    region: '',
    country: '',
    loading: true,
    error: null
  });
  const [requestingLocation, setRequestingLocation] = useState<boolean>(false);

  // Function to set location manually (for when automatic detection fails)
  const setManualLocation = (location: Partial<LocationData>) => {
    setLocationData(prev => ({
      ...prev,
      ...location,
      loading: false,
      error: null
    }));
    // Save manual location to localStorage
    localStorage.setItem('userLocation', JSON.stringify({
      ...location,
      manuallySet: true
    }));
  };

  const clearLocationCache = () => {
    localStorage.removeItem('userLocation');
    setLocationData({
      city: '',
      region: '',
      country: '',
      loading: true,
      error: null
    });
    // Restart location detection
    window.location.reload();
  };

  useEffect(() => {
    // Check if we already have a saved location
    const savedLocation = localStorage.getItem('userLocation');
    if (savedLocation) {
      try {
        const parsed = JSON.parse(savedLocation);
        // If location was manually set, use it immediately
        if (parsed.manuallySet) {
          setLocationData({
            city: parsed.city || '',
            region: parsed.region || '',
            country: parsed.country || '',
            postalCode: parsed.postalCode,
            latitude: parsed.latitude,
            longitude: parsed.longitude,
            loading: false,
            error: null
          });
          return; // Exit early if we have a manual location
        }
      } catch (e) {
        // If parsing fails, continue with detection
        console.error('Failed to parse saved location', e);
      }
    }

    // Function to get location from IP address
    const getLocationFromIP = async () => {
      try {
        // Use a free IP geolocation API
        const response = await fetch('https://ipapi.co/json/');
        const data = await response.json();
        
        if (data.error) {
          throw new Error(data.reason || 'Failed to detect location');
        }
        
        // Validate the location data to ensure accuracy
        const locationData = {
          city: data.city || '',
          region: data.region || '',
          country: data.country_name || '',
          postalCode: data.postal || undefined,
          latitude: data.latitude,
          longitude: data.longitude,
          loading: false,
          error: null
        };
        
        // Only use IP location if it seems reasonable
        if (locationData.city && locationData.country) {
          setLocationData(locationData);
          
          // Save the detected location to localStorage with timestamp
          localStorage.setItem('userLocation', JSON.stringify({
            ...locationData,
            detectedAt: Date.now(),
            manuallySet: false
          }));
        } else {
          throw new Error('Incomplete location data received');
        }
      } catch (error) {
        console.error('IP Geolocation error:', error);
        setLocationData(prev => ({
          ...prev,
          loading: false,
          error: 'Could not automatically detect your location. Please enter it manually.'
        }));
      }
    };

    // Function to get browser geolocation
    const getBrowserGeolocation = () => {
      setRequestingLocation(true);
      
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          // We have coordinates, now reverse geocode to get city/region
          try {
            // Use a free reverse geocoding API
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${position.coords.latitude}&lon=${position.coords.longitude}`
            );
            const data = await response.json();
            
            if (data.error) {
              throw new Error(data.error);
            }
            
            const address = data.address || {};
            
            setLocationData({
              city: address.city || address.town || address.village || '',
              region: address.state || address.county || '',
              country: address.country || '',
              postalCode: address.postcode,
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              loading: false,
              error: null
            });
            
            // Save the detected location to localStorage
            localStorage.setItem('userLocation', JSON.stringify({
              city: address.city || address.town || address.village || '',
              region: address.state || address.county || '',
              country: address.country || '',
              postalCode: address.postcode,
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              manuallySet: false
            }));
          } catch (error) {
            console.error('Reverse geocoding error:', error);
            // Fall back to IP geolocation if reverse geocoding fails
            getLocationFromIP();
          } finally {
            setRequestingLocation(false);
          }
        },
        (error) => {
          console.error('Browser geolocation error:', error);
          // Fall back to IP geolocation if browser geolocation fails
          getLocationFromIP();
          setRequestingLocation(false);
        },
        { enableHighAccuracy: false, timeout: 5000, maximumAge: 24 * 60 * 60 * 1000 } // 24 hour cache
      );
    };

    // Try to get location via browser API first
    if (navigator.geolocation) {
      getBrowserGeolocation();
    } else {
      // Fall back to IP geolocation if browser geolocation is not supported
      getLocationFromIP();
    }
  }, []);

  return {
    ...locationData,
    setManualLocation,
    requestingLocation
  };
}