import { useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { trackPageView } from '../lib/analytics';
import { trackFirebasePageView } from '../lib/firebaseAnalytics';

export const useAnalytics = () => {
  const [location] = useLocation();
  const prevLocationRef = useRef<string>(location);
  
  useEffect(() => {
    if (location !== prevLocationRef.current) {
      // Track in both Google Analytics and Firebase Analytics
      trackPageView(location, document.title);
      trackFirebasePageView(location, document.title);
      prevLocationRef.current = location;
    }
  }, [location]);
};